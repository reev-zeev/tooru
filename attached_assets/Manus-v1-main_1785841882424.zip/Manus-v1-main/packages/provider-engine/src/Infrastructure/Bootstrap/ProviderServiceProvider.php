<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Infrastructure\Bootstrap;

use Wasl\MatchingEngine\Application\Ports\ProviderGateway;
use Wasl\MatchingEngine\Domain\Strategies\FirstAvailableStrategy;
use Wasl\MatchingEngine\Domain\Strategies\MatchingStrategy;
use Wasl\ProviderEngine\Application\Queries\ProviderQueryService;
use Wasl\ProviderEngine\Domain\Repositories\ProviderRepository;
use Wasl\ProviderEngine\Domain\StateMachine\ProviderStateMachine;
use Wasl\ProviderEngine\Infrastructure\Adapters\MatchingProviderGateway;
use Wasl\ProviderEngine\Infrastructure\Persistence\InMemoryProviderQueryService;
use Wasl\ProviderEngine\Infrastructure\Persistence\InMemoryProviderRepository;
use Wasl\SharedKernel\Bootstrap\ServiceProvider;
use Wasl\SharedKernel\DependencyInjection\Container;

final class ProviderServiceProvider implements ServiceProvider
{
    public function register(Container $container): void
    {
        $container->singleton(
            ProviderStateMachine::class,
            fn() => new ProviderStateMachine()
        );

        $container->singleton(
            ProviderRepository::class,
            fn() => new InMemoryProviderRepository()
        );

        $container->singleton(
            ProviderQueryService::class,
            fn(Container $c) => new InMemoryProviderQueryService(
                $c->get(ProviderRepository::class)
            )
        );

        $container->singleton(
            ProviderGateway::class,
            fn(Container $c) => new MatchingProviderGateway(
                $c->get(ProviderQueryService::class)
            )
        );

        $container->singleton(
            MatchingStrategy::class,
            fn() => new FirstAvailableStrategy()
        );
    }

    public function boot(Container $container): void
    {
        // Reserved for future event subscribers.
    }
}
