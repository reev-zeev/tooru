<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Commands;

use Wasl\SharedKernel\Contracts\Commands\Command;
use Wasl\SharedKernel\ValueObjects\Timestamp;
use Wasl\SharedKernel\ValueObjects\UUID;
use Wasl\SessionEngine\ValueObjects\CustomerId;
use Wasl\SessionEngine\ValueObjects\ServiceType;

final readonly class CreateSessionCommand implements Command
{
    private UUID $commandId;

    private Timestamp $occurredAt;

    public function __construct(
        private CustomerId $customerId,
        private ServiceType $serviceType,
    ) {
        $this->commandId = UUID::generate();
        $this->occurredAt = Timestamp::now();
    }

    public function commandId(): UUID
    {
        return $this->commandId;
    }

    public function occurredAt(): Timestamp
    {
        return $this->occurredAt;
    }

    public function commandName(): string
    {
        return 'session.create';
    }

    public function version(): int
    {
        return 1;
    }

    public function payload(): array
    {
        return [
            'customer_id' => (string) $this->customerId,
            'service_type' => (string) $this->serviceType,
        ];
    }

    public function customerId(): CustomerId
    {
        return $this->customerId;
    }

    public function serviceType(): ServiceType
    {
        return $this->serviceType;
    }
}
