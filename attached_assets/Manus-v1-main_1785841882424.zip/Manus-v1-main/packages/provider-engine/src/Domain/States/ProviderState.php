<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Domain\States;

enum ProviderState: string
{
    case Offline = 'offline';
    case Available = 'available';
    case Busy = 'busy';
    case Suspended = 'suspended';

    public function isAvailable(): bool
    {
        return $this === self::Available;
    }

    public function canTransitionTo(self $next): bool
    {
        return match ($this) {
            self::Offline => in_array($next, [
                self::Available,
                self::Suspended,
            ], true),

            self::Available => in_array($next, [
                self::Busy,
                self::Offline,
                self::Suspended,
            ], true),

            self::Busy => in_array($next, [
                self::Available,
                self::Offline,
                self::Suspended,
            ], true),

            self::Suspended => false,
        };
    }
}
