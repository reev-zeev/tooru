<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Application\Queries;

final class ProviderView
{
    public function __construct(
        public readonly string $id,
        public readonly float $rating,
        public readonly float $distance,
        public readonly bool $available,
    ) {
    }
}

interface ProviderQueryService
{
    /**
     * @return list<ProviderView>
     */
    public function availableProviders(): array;
}
