<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Support;

use Countable;
use IteratorAggregate;
use ArrayIterator;
use Traversable;

abstract class DomainCollection implements IteratorAggregate, Countable
{
    /**
     * @var array<int,mixed>
     */
    protected array $items = [];

    final public function __construct(array $items = [])
    {
        foreach ($items as $item) {
            $this->add($item);
        }
    }

    abstract protected function accepts(mixed $item): bool;

    final public function add(mixed $item): void
    {
        if (!$this->accepts($item)) {
            throw new \InvalidArgumentException(
                'Invalid collection item.'
            );
        }

        $this->items[] = $item;
    }

    final public function all(): array
    {
        return $this->items;
    }

    final public function first(): mixed
    {
        return $this->items[0] ?? null;
    }

    final public function last(): mixed
    {
        if ($this->items === []) {
            return null;
        }

        return $this->items[array_key_last($this->items)];
    }

    final public function isEmpty(): bool
    {
        return $this->items === [];
    }

    final public function count(): int
    {
        return count($this->items);
    }

    final public function getIterator(): Traversable
    {
        return new ArrayIterator($this->items);
    }
}
