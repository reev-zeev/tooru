<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\DomainPolicies;

interface Policy
{
    public function name(): string;

    public function appliesTo(mixed $context): bool;

    public function execute(mixed $context): mixed;
}
