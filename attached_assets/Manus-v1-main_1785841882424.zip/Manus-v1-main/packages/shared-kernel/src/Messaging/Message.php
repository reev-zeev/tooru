<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Messaging;

interface Message
{
    public function name(): string;

    public function payload(): array;

    public function version(): int;
}
