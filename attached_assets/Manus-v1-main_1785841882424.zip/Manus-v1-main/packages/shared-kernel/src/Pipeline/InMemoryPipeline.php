<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Pipeline;

final class InMemoryPipeline implements Pipeline
{
    private mixed $payload;

    /**
     * @var callable[]
     */
    private array $pipes = [];

    public function send(mixed $payload): self
    {
        $this->payload = $payload;

        return $this;
    }

    public function through(array $pipes): self
    {
        $this->pipes = $pipes;

        return $this;
    }

    public function then(callable $destination): mixed
    {
        $pipeline = array_reduce(
            array_reverse($this->pipes),
            fn ($next, $pipe) => fn ($payload) => $pipe($payload, $next),
            $destination
        );

        return $pipeline($this->payload);
    }
}
