<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Application;

abstract class AbstractApplicationService implements ApplicationService
{
}
