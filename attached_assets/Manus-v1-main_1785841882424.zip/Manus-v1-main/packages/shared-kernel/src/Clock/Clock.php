<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Clock;

use Wasl\SharedKernel\ValueObjects\Timestamp;

interface Clock
{
    public function now(): Timestamp;
}
