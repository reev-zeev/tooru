# Wasl Platform Coding Standards

Version: 1.0.0
Status: DRAFT

=========================================================
MISSION
=========================================================

These standards are mandatory.

No code may be merged unless it follows this document.

=========================================================
GENERAL PRINCIPLES
=========================================================

Readable over Clever

Explicit over Implicit

Composition over Inheritance

Interfaces over Implementations

Immutable by Default

Small Classes

Single Responsibility

Fail Fast

Keep It Simple

No Magic

=========================================================
ARCHITECTURE RULES
=========================================================

No Business Logic in Controllers

No Business Logic in Bots

No Business Logic in API Layer

No Database Access from UI

No Direct Engine Communication

Only Events and Commands between Engines

Shared Kernel is the only shared dependency

=========================================================
NAMING
=========================================================

Classes

PascalCase

Methods

camelCase

Variables

camelCase

Constants

UPPER_SNAKE_CASE

Interfaces

Prefix with "I" is forbidden

Events

Past Tense

Example

OrderCreated

Commands

Imperative

Example

CreateOrder

=========================================================
CLASS RULES
=========================================================

One Class

One Responsibility

Constructor Injection

No Static Business Methods

Dependencies through Interfaces

=========================================================
METHOD RULES
=========================================================

Maximum 40 Lines

Maximum 5 Parameters

Return Early

Single Responsibility

No Hidden Side Effects

=========================================================
DOMAIN RULES
=========================================================

Entities own behavior.

Value Objects are immutable.

Aggregates enforce invariants.

Repositories expose interfaces only.

Factories create Aggregates.

=========================================================
EVENT RULES
=========================================================

Events are immutable.

Events describe facts.

Events never contain business logic.

Events are versioned.

=========================================================
COMMAND RULES
=========================================================

Commands express intent.

Commands validate input.

Commands never contain business logic.

=========================================================
ERROR HANDLING
=========================================================

Never swallow exceptions.

Never expose stack traces.

Always log unexpected failures.

Always return standardized errors.

=========================================================
DATABASE
=========================================================

Soft Delete Only.

UUID Primary Keys.

Foreign Keys Required.

Indexes Required.

Transactions Required.

=========================================================
TESTING
=========================================================

Every Feature

Unit Test

Every Engine

Integration Test

Every API

Contract Test

Critical Flows

E2E Test

=========================================================
DOCUMENTATION
=========================================================

Every Engine

README

Every Public Class

PHPDoc

Every ADR

Recorded

Every Breaking Change

Documented

=========================================================
GIT
=========================================================

Small Commits

Conventional Commits

No Direct Push to Main

Pull Requests Required

Code Review Required

=========================================================
REVIEW CHECKLIST
=========================================================

Architecture Respected

Tests Passing

Standards Followed

Performance Considered

Security Reviewed

Documentation Updated

