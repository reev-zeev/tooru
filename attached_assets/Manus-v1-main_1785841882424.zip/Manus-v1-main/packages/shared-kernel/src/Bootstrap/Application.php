<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Bootstrap;

use Wasl\SharedKernel\DependencyInjection\Container;

final class Application
{
    /**
     * @var ServiceProvider[]
     */
    private array $providers = [];

    public function __construct(
        private readonly Container $container,
    ) {
    }

    public function register(ServiceProvider $provider): void
    {
        $provider->register($this->container);

        $this->providers[] = $provider;
    }

    public function boot(): void
    {
        foreach ($this->providers as $provider) {
            $provider->boot($this->container);
        }
    }

    public function container(): Container
    {
        return $this->container;
    }
}
