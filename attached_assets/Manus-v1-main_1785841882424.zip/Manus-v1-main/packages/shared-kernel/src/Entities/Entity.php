<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Entities;

use Wasl\SharedKernel\ValueObjects\Identifier;

abstract class Entity
{
    public function __construct(
        protected Identifier $id
    ) {
    }

    final public function id(): Identifier
    {
        return $this->id;
    }

    final public function equals(self $other): bool
    {
        return static::class === $other::class
            && $this->id->equals($other->id());
    }
}
