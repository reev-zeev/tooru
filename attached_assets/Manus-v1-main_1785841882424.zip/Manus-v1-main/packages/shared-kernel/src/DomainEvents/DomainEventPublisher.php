<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\DomainEvents;

use Wasl\SharedKernel\Contracts\Events\DomainEvent;

interface DomainEventPublisher
{
    public function publish(DomainEvent ...$events): void;
}
