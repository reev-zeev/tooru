# Wasl Platform Permissions Matrix

Version: 1.0.0
Status: DRAFT

=========================================================
ACCESS MODEL
=========================================================

Authentication

↓

Role

↓

Permission

↓

Policy

↓

Resource

↓

Action

=========================================================
SYSTEM ROLES
=========================================================

Super Admin

Platform Admin

Operations Manager

Support Manager

Support Agent

Finance Manager

Finance Agent

Dispatcher

Auditor

Developer

Monitoring

Customer

Provider

Guest

=========================================================
PERMISSION TYPES
=========================================================

View

Create

Update

Delete

Execute

Approve

Suspend

Restore

Assign

Export

Import

Configure

=========================================================
CUSTOMER
=========================================================

Create Order

Cancel Order

View Own Orders

Edit Profile

Manage Favorite Locations

Create Booking

Manage Recurring Booking

Open Chat

Rate Provider

View Payments

=========================================================
PROVIDER
=========================================================

Go Online

Go Offline

Accept Order

Reject Order

Update Location

Start Service

Complete Service

Cancel Service

Open Chat

Rate Customer

View Earnings

View Statistics

=========================================================
SUPPORT
=========================================================

View Sessions

View Customers

View Providers

View Chats

Resolve Ticket

Refund Request

Manual Reassignment

View Timeline

View Audit

=========================================================
FINANCE
=========================================================

View Payments

Refund Payments

Adjust Payments

Export Reports

View Revenue

Manage Pricing

=========================================================
DISPATCHER
=========================================================

View Active Sessions

Force Dispatch

Cancel Dispatch

Reassign Provider

View Queue

=========================================================
ADMIN
=========================================================

Manage Customers

Manage Providers

Manage Vehicles

Manage Pricing

Manage Settings

Manage Feature Flags

Manage Roles

Manage Permissions

Manage Policies

Manage Scheduler

Manage Notifications

Manage Dispatch

View Analytics

View Audit Logs

=========================================================
SUPER ADMIN
=========================================================

Full Access

No Restrictions

=========================================================
DEVELOPER
=========================================================

View Logs

View Monitoring

View Metrics

View Health Checks

No Business Data Modification

=========================================================
MONITORING
=========================================================

View Dashboards

View Alerts

View Metrics

View Queue

View Health

=========================================================
PERMISSION RULES
=========================================================

Default Deny.

Least Privilege.

Role Based Access Control (RBAC).

Policies override permissions.

Every privileged action is audited.

Every permission change is audited.

No direct database access.

No hidden permissions.

Permissions are versioned.

