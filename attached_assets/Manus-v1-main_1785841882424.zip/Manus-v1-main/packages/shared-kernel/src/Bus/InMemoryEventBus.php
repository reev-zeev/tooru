<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Bus;

use Wasl\SharedKernel\Contracts\Events\DomainEvent;

final class InMemoryEventBus implements EventBus
{
    /**
     * @var array<string,list<callable>>
     */
    private array $listeners = [];

    public function subscribe(string $eventClass, callable $listener): void
    {
        $this->listeners[$eventClass] ??= [];
        $this->listeners[$eventClass][] = $listener;
    }

    public function publish(DomainEvent ...$events): void
    {
        foreach ($events as $event) {
            foreach ($this->listeners[$event::class] ?? [] as $listener) {
                $listener($event);
            }
        }
    }
}
