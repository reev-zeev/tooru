# Wasl Platform State Machines

Version: 1.0.0
Status: DRAFT

=========================================================
STATE MACHINE PRINCIPLES
=========================================================

Every Aggregate has exactly one State Machine.

No Aggregate may change state directly.

All transitions are validated.

Illegal transitions are rejected.

Every transition generates an Event.

Every transition is audited.

Finished states are immutable.

=========================================================
SERVICE SESSION
=========================================================

Created

↓

Searching

↓

Matched

↓

ProviderAccepted

↓

ProviderEnRoute

↓

ProviderArrived

↓

InService

↓

Completed

↓

Archived

Cancellation is allowed only before Archived.

Completed cannot return to InService.

Archived is terminal.

=========================================================
PROVIDER
=========================================================

Offline

↓

Online

↓

Available

↓

Busy

↓

Available

↓

Offline

Alternative States

Reserved

Suspended

Disconnected

Recovery

Disconnected

↓

Recovering

↓

Previous State

=========================================================
CUSTOMER
=========================================================

Registered

Verified

Active

Blocked

Deleted

=========================================================
BOOKING
=========================================================

Created

↓

Confirmed

↓

Scheduled

↓

Dispatching

↓

Running

↓

Completed

or

Cancelled

=========================================================
PAYMENT
=========================================================

Pending

↓

Authorized

↓

Captured

↓

Completed

Refund Path

Captured

↓

Refunded

Failure Path

Pending

↓

Failed

=========================================================
CHAT
=========================================================

Opened

↓

Active

↓

Closed

Archived

=========================================================
NOTIFICATION
=========================================================

Queued

↓

Sending

↓

Delivered

Failure

Queued

↓

Failed

↓

Retry

↓

Delivered

Dead Letter Queue

=========================================================
SUPPORT TICKET
=========================================================

Open

↓

Assigned

↓

Investigating

↓

Resolved

↓

Closed

=========================================================
VEHICLE
=========================================================

Registered

Verified

Available

Maintenance

Retired

=========================================================
RULES
=========================================================

Every state machine is deterministic.

Every transition has preconditions.

Every transition emits events.

Every transition is reversible only if explicitly defined.

No hidden transitions.

No direct database state manipulation.

State Machines are the only authority for lifecycle management.

