<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Health;

final readonly class HealthStatus
{
    public function __construct(
        private bool $healthy,
        private string $message = 'OK',
        private array $meta = [],
    ) {
    }

    public static function healthy(array $meta = []): self
    {
        return new self(
            healthy: true,
            message: 'OK',
            meta: $meta,
        );
    }

    public static function unhealthy(
        string $message,
        array $meta = []
    ): self {
        return new self(
            healthy: false,
            message: $message,
            meta: $meta,
        );
    }

    public function isHealthy(): bool
    {
        return $this->healthy;
    }

    public function message(): string
    {
        return $this->message;
    }

    public function meta(): array
    {
        return $this->meta;
    }
}
