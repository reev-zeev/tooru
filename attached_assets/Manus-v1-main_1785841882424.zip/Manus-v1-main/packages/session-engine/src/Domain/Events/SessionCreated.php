<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\Events;

use DateTimeImmutable;
use Wasl\SharedKernel\Contracts\Events\DomainEvent;
use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class SessionCreated implements DomainEvent
{
    private DateTimeImmutable $occurredAt;

    public function __construct(
        private UUID $sessionId,
    ) {
        $this->occurredAt = new DateTimeImmutable();
    }

    public function eventId(): UUID
    {
        return UUID::generate();
    }

    public function aggregateId(): UUID
    {
        return $this->sessionId;
    }

    public function eventName(): string
    {
        return 'session.created';
    }

    public function occurredAt(): DateTimeImmutable
    {
        return $this->occurredAt;
    }

    public function payload(): array
    {
        return [
            'session_id' => $this->sessionId->toString(),
        ];
    }
}
