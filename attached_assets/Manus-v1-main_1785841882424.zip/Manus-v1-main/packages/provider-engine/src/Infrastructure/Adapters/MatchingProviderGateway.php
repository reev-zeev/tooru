<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Infrastructure\Adapters;

use Wasl\MatchingEngine\Application\Ports\ProviderCandidate;
use Wasl\MatchingEngine\Application\Ports\ProviderGateway;
use Wasl\ProviderEngine\Application\Queries\ProviderQueryService;

final readonly class MatchingProviderGateway implements ProviderGateway
{
    public function __construct(
        private ProviderQueryService $queryService,
    ) {
    }

    public function availableProviders(): array
    {
        $result = [];

        foreach ($this->queryService->availableProviders() as $provider) {
            if (!$provider->available) {
                continue;
            }

            $result[] = new ProviderCandidate(
                id: $provider->id,
                rating: $provider->rating,
                distance: $provider->distance,
            );
        }

        return $result;
    }
}
