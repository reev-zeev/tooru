<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Entities;

use Wasl\SharedKernel\Contracts\Events\DomainEvent;

abstract class AggregateRoot extends Entity
{
    /**
     * @var DomainEvent[]
     */
    private array $recordedEvents = [];

    final protected function record(DomainEvent $event): void
    {
        $this->recordedEvents[] = $event;
    }

    /**
     * @return DomainEvent[]
     */
    final public function releaseEvents(): array
    {
        $events = $this->recordedEvents;

        $this->recordedEvents = [];

        return $events;
    }

    /**
     * @return DomainEvent[]
     */
    final public function recordedEvents(): array
    {
        return $this->recordedEvents;
    }

    final public function hasEvents(): bool
    {
        return $this->recordedEvents !== [];
    }

    final protected function clearEvents(): void
    {
        $this->recordedEvents = [];
    }
}
