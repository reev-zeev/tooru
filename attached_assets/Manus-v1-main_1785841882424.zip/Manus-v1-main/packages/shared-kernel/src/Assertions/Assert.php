<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Assertions;

use Wasl\SharedKernel\Exceptions\ValidationException;

final class Assert
{
    public static function true(bool $condition, string $message): void
    {
        if (!$condition) {
            throw new ValidationException($message);
        }
    }

    public static function false(bool $condition, string $message): void
    {
        self::true(!$condition, $message);
    }

    public static function notEmpty(string $value, string $message): void
    {
        self::true(trim($value) !== '', $message);
    }

    public static function maxLength(string $value, int $length, string $message): void
    {
        self::true(
            mb_strlen($value) <= $length,
            $message
        );
    }

    public static function minLength(string $value, int $length, string $message): void
    {
        self::true(
            mb_strlen($value) >= $length,
            $message
        );
    }

    public static function positive(int|float $value, string $message): void
    {
        self::true($value > 0, $message);
    }

    public static function nonNegative(int|float $value, string $message): void
    {
        self::true($value >= 0, $message);
    }

    public static function instanceOf(mixed $value, string $class, string $message): void
    {
        self::true($value instanceof $class, $message);
    }

    public static function notNull(mixed $value, string $message): void
    {
        self::true($value !== null, $message);
    }
}
