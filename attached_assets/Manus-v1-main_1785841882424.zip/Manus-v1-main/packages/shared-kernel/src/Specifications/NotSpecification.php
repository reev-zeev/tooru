<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Specifications;

final readonly class NotSpecification extends AbstractSpecification
{
    public function __construct(
        private Specification $specification,
    ) {
    }

    public function isSatisfiedBy(mixed $candidate): bool
    {
        return !$this->specification->isSatisfiedBy($candidate);
    }
}
