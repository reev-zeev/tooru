"""
🚖 ملف التشغيل الرئيسي - يشغل البوتين معاً
"""
import os, asyncio, asyncpg
from dotenv import load_dotenv
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "")
if not DATABASE_URL:
    raise RuntimeError("❌ DATABASE_URL غير موجود")

async def init_db():
    pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=10)
    async with pool.acquire() as conn:
        # إنشاء الجداول الأساسية
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                tg_id BIGINT PRIMARY KEY, full_name TEXT, username TEXT
            );
            CREATE TABLE IF NOT EXISTS drivers (
                tg_id BIGINT PRIMARY KEY, full_name TEXT, phone TEXT,
                city TEXT, work_area TEXT, preferred_areas TEXT,
                car_model TEXT, plate_number TEXT, privacy TEXT DEFAULT 'open',
                subscription TEXT DEFAULT 'free', subscription_until TIMESTAMPTZ,
                verified BOOLEAN DEFAULT FALSE,
                rating_avg FLOAT DEFAULT 5.0, rating_count INT DEFAULT 0,
                last_lat DOUBLE PRECISION, last_lon DOUBLE PRECISION,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS rides (
                id SERIAL PRIMARY KEY, customer_id BIGINT, driver_id BIGINT,
                city TEXT, pickup_area TEXT, dest_area TEXT,
                price TEXT, status TEXT DEFAULT 'waiting',
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS ride_offers (
                id SERIAL PRIMARY KEY, ride_id INT, driver_id BIGINT,
                counter_price TEXT, status TEXT DEFAULT 'pending'
            );
            CREATE TABLE IF NOT EXISTS ratings (
                id SERIAL PRIMARY KEY, ride_id INT, rater_id BIGINT,
                ratee_id BIGINT, stars INT
            );
            CREATE TABLE IF NOT EXISTS favorites (
                customer_id BIGINT, driver_id BIGINT,
                UNIQUE(customer_id, driver_id)
            );
            CREATE TABLE IF NOT EXISTS groups_config (
                id SERIAL PRIMARY KEY, city TEXT, type TEXT, chat_id BIGINT
            );
        """)
        # إضافة عمود is_available إذا لم يكن موجوداً (لـ PostgreSQL 9.6+)
        await conn.execute("""
            ALTER TABLE drivers ADD COLUMN IF NOT EXISTS is_available BOOLEAN DEFAULT TRUE
        """)
    print("✅ جميع الجداول جاهزة (بما فيها عمود is_available).")
    return pool

async def main():
    pool = await init_db()
    
    # استيراد البوتين
    from passenger_bot.main import dp as passenger_dp, bot as passenger_bot
    from driver_bot.main import dp as driver_dp, bot as driver_bot
    
    # تمرير pool للبوتين
    import passenger_bot.main as pm
    import driver_bot.main as dm
    pm.pool = pool
    dm.pool = pool
    
    print("🚀 بوت الراكب يعمل الآن...")
    print("🚀 بوت السائق يعمل الآن...")
    
    # تشغيل البوتين معاً
    await asyncio.gather(
        passenger_dp.start_polling(passenger_bot),
        driver_dp.start_polling(driver_bot)
    )

if __name__ == "__main__":
    asyncio.run(main())
