<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Support;

final class LazyValue
{
    private bool $resolved = false;

    private mixed $value = null;

    public function __construct(
        private readonly \Closure $resolver
    ) {
    }

    public function get(): mixed
    {
        if (!$this->resolved) {
            $this->value = ($this->resolver)();
            $this->resolved = true;
        }

        return $this->value;
    }
}
