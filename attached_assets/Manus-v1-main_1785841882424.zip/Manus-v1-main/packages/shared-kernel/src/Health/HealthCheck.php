<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Health;

interface HealthCheck
{
    public function name(): string;

    public function check(): HealthStatus;
}
