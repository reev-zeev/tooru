<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\DomainServices;

/**
 * Marker interface for all Domain Services.
 *
 * Domain Services contain business rules that do not naturally
 * belong to a single Aggregate or Value Object.
 */
interface DomainService
{
}
