<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Validation;

use InvalidArgumentException;

final class Assertion
{
    public static function true(
        bool $condition,
        string $message = 'Assertion failed.'
    ): void {
        if (!$condition) {
            throw new InvalidArgumentException($message);
        }
    }

    public static function false(
        bool $condition,
        string $message = 'Assertion failed.'
    ): void {
        if ($condition) {
            throw new InvalidArgumentException($message);
        }
    }

    public static function notEmpty(
        string $value,
        string $message = 'Value cannot be empty.'
    ): void {
        if (trim($value) === '') {
            throw new InvalidArgumentException($message);
        }
    }

    public static function positive(
        int|float $value,
        string $message = 'Value must be positive.'
    ): void {
        if ($value <= 0) {
            throw new InvalidArgumentException($message);
        }
    }

    public static function nonNegative(
        int|float $value,
        string $message = 'Value cannot be negative.'
    ): void {
        if ($value < 0) {
            throw new InvalidArgumentException($message);
        }
    }

    public static function maxLength(
        string $value,
        int $length,
        string $message = 'Maximum length exceeded.'
    ): void {
        if (mb_strlen($value) > $length) {
            throw new InvalidArgumentException($message);
        }
    }

    public static function minLength(
        string $value,
        int $length,
        string $message = 'Minimum length not reached.'
    ): void {
        if (mb_strlen($value) < $length) {
            throw new InvalidArgumentException($message);
        }
    }

    public static function uuid(
        string $value,
        string $message = 'Invalid UUID.'
    ): void {
        if (!preg_match(
            '/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',
            $value
        )) {
            throw new InvalidArgumentException($message);
        }
    }
}
