<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Bootstrap;

use Wasl\SharedKernel\DependencyInjection\Container;

interface ServiceProvider
{
    public function register(Container $container): void;

    public function boot(Container $container): void;
}
