<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Locking;

final class InMemoryLockManager implements LockManager
{
    /**
     * @var array<string,int>
     */
    private array $locks = [];

    public function acquire(string $key, int $ttl = 30): bool
    {
        $now = time();

        if (isset($this->locks[$key]) && $this->locks[$key] > $now) {
            return false;
        }

        $this->locks[$key] = $now + $ttl;

        return true;
    }

    public function release(string $key): void
    {
        unset($this->locks[$key]);
    }

    public function isLocked(string $key): bool
    {
        return isset($this->locks[$key])
            && $this->locks[$key] > time();
    }
}
