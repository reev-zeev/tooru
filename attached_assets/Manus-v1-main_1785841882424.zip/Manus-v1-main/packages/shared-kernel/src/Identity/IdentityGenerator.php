<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Identity;

use Wasl\SharedKernel\ValueObjects\UUID;

interface IdentityGenerator
{
    public function generate(): UUID;
}
