<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Domain\Aggregates;

use Wasl\MatchingEngine\Domain\Events\MatchingStarted;

use Wasl\MatchingEngine\Domain\StateMachine\MatchingStateMachine;
use Wasl\MatchingEngine\Domain\States\MatchingState;
use Wasl\SharedKernel\Aggregate\AggregateRoot;
use Wasl\SharedKernel\ValueObjects\UUID;

final class MatchingProcess extends AggregateRoot
{
    private MatchingState $state;

    private function __construct(
        private readonly UUID $id,
        private readonly UUID $sessionId,
        private readonly MatchingStateMachine $stateMachine,
    ) {
        parent::__construct();

        $this->state = MatchingState::Created;
    }

    public static function create(
        UUID $id,
        UUID $sessionId,
        MatchingStateMachine $stateMachine,
    ): self {
        return new self(
            $id,
            $sessionId,
            $stateMachine,
        );
    }

    public function id(): UUID
    {
        return $this->id;
    }

    public function sessionId(): UUID
    {
        return $this->sessionId;
    }

    public function state(): MatchingState
    {
        return $this->state;
    }

    public function startSearching(): void
    {
        $this->transition(MatchingState::Searching);

        $this->recordEvent(
            new MatchingStarted(
                $this->id,
                $this->sessionId,
            )
        );
    }

    public function candidateFound(): void
    {
        $this->transition(MatchingState::CandidateFound);
    }

    public function sendOffer(): void
    {
        $this->transition(MatchingState::OfferSent);
    }

    public function providerAccepted(): void
    {
        $this->transition(MatchingState::ProviderAccepted);
    }

    public function providerRejected(): void
    {
        $this->transition(MatchingState::ProviderRejected);
    }

    public function exhausted(): void
    {
        $this->transition(MatchingState::Exhausted);
    }

    public function complete(): void
    {
        $this->transition(MatchingState::Completed);
    }

    public function cancel(): void
    {
        $this->transition(MatchingState::Cancelled);
    }

    private function transition(MatchingState $next): void
    {
        $this->state = $this->stateMachine->transition(
            $this->state,
            $next,
        );
    }
}
