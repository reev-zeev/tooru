<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Messaging;

interface MessageHandler
{
    public function __invoke(Message $message): mixed;
}
