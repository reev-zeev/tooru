<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Application\Support;

use Wasl\SessionEngine\Domain\Aggregates\ServiceSession;
use Wasl\SessionEngine\Domain\Repositories\ServiceSessionRepository;
use Wasl\SharedKernel\Application\AggregatePersistenceManager;
use Wasl\SharedKernel\Exceptions\NotFoundException;
use Wasl\SharedKernel\ValueObjects\UUID;

abstract readonly class SessionCommandHandler
{
    public function __construct(
        protected ServiceSessionRepository $repository,
        protected AggregatePersistenceManager $persistence,
    ) {
    }

    protected function session(UUID $id): ServiceSession
    {
        $session = $this->repository->findById($id);

        if ($session === null) {
            throw new NotFoundException('Session not found.');
        }

        return $session;
    }

    protected function persist(ServiceSession $session): void
    {
        $this->persistence->save(
            $session,
            fn (ServiceSession $aggregate) => $this->repository->save($aggregate),
        );
    }
}
