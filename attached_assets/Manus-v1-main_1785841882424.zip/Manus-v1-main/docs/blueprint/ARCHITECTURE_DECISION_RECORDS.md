# Wasl Platform Architecture Decision Records (ADR)

Version: 1.0.0
Status: LIVING DOCUMENT

=========================================================
ADR-000
=========================================================

Title

Platform First

Status

Accepted

Decision

The system is a Platform.

Applications are only clients.

Reason

Future scalability.

=========================================================
ADR-001
=========================================================

Title

Monorepo

Status

Accepted

Decision

Entire platform lives in one repository.

Reason

Shared Kernel.

Unified CI.

Atomic changes.

=========================================================
ADR-002
=========================================================

Title

Modular Monolith First

Status

Accepted

Decision

API starts as Modular Monolith.

Migration to Microservices remains optional.

Reason

Lower complexity.

=========================================================
ADR-003
=========================================================

Title

Database Is Source Of Truth

Status

Accepted

Decision

Redis is cache only.

Reason

Reliability.

=========================================================
ADR-004
=========================================================

Title

Event Driven Architecture

Status

Accepted

Decision

Engines communicate only through Events.

Reason

Loose coupling.

=========================================================
ADR-005
=========================================================

Title

Commands Modify State

Status

Accepted

Decision

Events never modify state.

Commands execute changes.

Reason

CQRS Principles.

=========================================================
ADR-006
=========================================================

Title

Service Session Is Aggregate Root

Status

Accepted

Decision

ServiceSession owns lifecycle.

Reason

Single source of business truth.

=========================================================
ADR-007
=========================================================

Title

State Machines Everywhere

Status

Accepted

Decision

Every Aggregate has one State Machine.

Reason

Prevent invalid transitions.

=========================================================
ADR-008
=========================================================

Title

Value Objects First

Status

Accepted

Decision

Primitive values are forbidden where domain meaning exists.

Reason

Type safety.

=========================================================
ADR-009
=========================================================

Title

Soft Delete Only

Status

Accepted

Decision

Business entities are never physically deleted.

Reason

Auditability.

=========================================================
ADR-010
=========================================================

Title

Idempotency Required

Status

Accepted

Decision

Every write request requires Idempotency Key.

Reason

Prevent duplicates.

=========================================================
ADR-011
=========================================================

Title

UTC Everywhere

Status

Accepted

Decision

All timestamps stored as UTC.

Reason

Consistency.

=========================================================
ADR-012
=========================================================

Title

Shared Kernel Stability

Status

Accepted

Decision

Breaking Shared Kernel requires architecture review.

Reason

Protect Engines.

=========================================================
ADR-013
=========================================================

Title

No Business Logic Outside Engines

Status

Accepted

Decision

Bots, API, Controllers and UI contain zero business logic.

Reason

Maintainability.

=========================================================
ADR-014
=========================================================

Title

Everything Observable

Status

Accepted

Decision

Every command, event and transition is logged.

Reason

Debugging.

=========================================================
ADR-015
=========================================================

Title

Fail Safe Defaults

Status

Accepted

Decision

Failures default to safe behaviour.

Reason

Protect data integrity.

