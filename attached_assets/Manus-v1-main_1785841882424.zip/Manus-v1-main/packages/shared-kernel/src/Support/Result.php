<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Support;

final readonly class Result
{
    private function __construct(
        private bool $success,
        private mixed $value = null,
        private ?string $error = null,
    ) {
    }

    public static function ok(mixed $value = null): self
    {
        return new self(
            success: true,
            value: $value,
        );
    }

    public static function fail(string $error): self
    {
        return new self(
            success: false,
            error: $error,
        );
    }

    public function isSuccess(): bool
    {
        return $this->success;
    }

    public function isFailure(): bool
    {
        return !$this->success;
    }

    public function value(): mixed
    {
        return $this->value;
    }

    public function error(): ?string
    {
        return $this->error;
    }
}
