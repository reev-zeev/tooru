<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Domain\Aggregates;

use Wasl\ProviderEngine\Domain\Events\ProviderAvailabilityChanged;
use Wasl\ProviderEngine\Domain\Events\ProviderRegistered;

use Wasl\ProviderEngine\Domain\StateMachine\ProviderStateMachine;
use Wasl\ProviderEngine\Domain\States\ProviderState;
use Wasl\SharedKernel\Aggregate\AggregateRoot;
use Wasl\SharedKernel\ValueObjects\UUID;

final class Provider extends AggregateRoot
{
    private ProviderState $state;

    private function __construct(
        private readonly UUID $id,
        private readonly ProviderStateMachine $stateMachine,
    ) {
        parent::__construct();

        $this->state = ProviderState::Offline;
    }

    public static function register(
        UUID $id,
        ProviderStateMachine $stateMachine,
    ): self {
        $provider = new self($id, $stateMachine);

        $provider->recordEvent(
            new ProviderRegistered(
                $provider->id()
            )
        );

        return $provider;
    }

    public function id(): UUID
    {
        return $this->id;
    }

    public function state(): ProviderState
    {
        return $this->state;
    }

    public function goOnline(): void
    {
        $this->transition(ProviderState::Available);
    }

    public function assign(): void
    {
        $this->transition(ProviderState::Busy);
    }

    public function release(): void
    {
        $this->transition(ProviderState::Available);
    }

    public function goOffline(): void
    {
        $this->transition(ProviderState::Offline);
    }

    public function suspend(): void
    {
        $this->transition(ProviderState::Suspended);
    }

    private function transition(ProviderState $next): void
    {
        $this->state = $this->stateMachine->transition(
            $this->state,
            $next,
        );

        $this->recordEvent(
            new ProviderAvailabilityChanged(
                $this->id,
                $this->state,
            )
        );
    }
}
