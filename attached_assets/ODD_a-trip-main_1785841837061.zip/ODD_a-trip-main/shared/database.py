import asyncpg
import os

DATABASE_URL = os.getenv("DATABASE_URL", "")

pool: asyncpg.Pool = None

async def create_pool():
    global pool
    if not DATABASE_URL:
        raise RuntimeError("❌ DATABASE_URL غير موجود. تأكد من إضافة PostgreSQL لخدمتك في Railway.")
    pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=5)
    async with pool.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                tg_id BIGINT PRIMARY KEY,
                full_name TEXT,
                username TEXT,
                phone TEXT,
                role TEXT DEFAULT 'user',
                is_vip BOOLEAN DEFAULT FALSE,
                vip_until TIMESTAMPTZ,
                rating_avg FLOAT DEFAULT 5.0,
                rating_count INT DEFAULT 0,
                last_lat DOUBLE PRECISION,
                last_lon DOUBLE PRECISION,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS drivers (
                tg_id BIGINT PRIMARY KEY REFERENCES users(tg_id),
                city TEXT,
                work_area TEXT,
                preferred_areas TEXT,
                car_model TEXT,
                plate_number TEXT,
                phone TEXT,
                privacy TEXT DEFAULT 'open',
                subscription TEXT DEFAULT 'free',
                subscription_until TIMESTAMPTZ,
                verified BOOLEAN DEFAULT FALSE,
                rating_avg FLOAT DEFAULT 5.0,
                rating_count INT DEFAULT 0,
                accept_count INT DEFAULT 0,
                cancel_count INT DEFAULT 0,
                last_lat DOUBLE PRECISION,
                last_lon DOUBLE PRECISION,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS rides (
                id SERIAL PRIMARY KEY,
                customer_id BIGINT,
                driver_id BIGINT,
                city TEXT,
                pickup_area TEXT,
                pickup_lat DOUBLE PRECISION,
                pickup_lon DOUBLE PRECISION,
                dest_area TEXT,
                dest_lat DOUBLE PRECISION,
                dest_lon DOUBLE PRECISION,
                price TEXT,
                payment_method TEXT,
                status TEXT DEFAULT 'waiting',
                created_at TIMESTAMPTZ DEFAULT NOW(),
                accepted_at TIMESTAMPTZ,
                completed_at TIMESTAMPTZ,
                cancelled_at TIMESTAMPTZ
            );
            CREATE TABLE IF NOT EXISTS ride_offers (
                id SERIAL PRIMARY KEY,
                ride_id INT REFERENCES rides(id),
                driver_id BIGINT,
                counter_price TEXT,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS ratings (
                id SERIAL PRIMARY KEY,
                ride_id INT REFERENCES rides(id),
                rater_id BIGINT,
                ratee_id BIGINT,
                stars INT CHECK (stars BETWEEN 1 AND 5),
                created_at TIMESTAMPTZ DEFAULT NOW(),
                UNIQUE(ride_id, rater_id)
            );
            CREATE TABLE IF NOT EXISTS favorites (
                customer_id BIGINT,
                driver_id BIGINT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                UNIQUE(customer_id, driver_id)
            );
            CREATE TABLE IF NOT EXISTS groups_config (
                id SERIAL PRIMARY KEY,
                city TEXT,
                type TEXT,
                chat_id BIGINT
            );
            CREATE TABLE IF NOT EXISTS emergency_alerts (
                id SERIAL PRIMARY KEY,
                ride_id INT,
                user_id BIGINT,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
        """)
    print("✅ تم إنشاء/تأكيد جميع جداول قاعدة البيانات.")

async def close_pool():
    if pool:
        await pool.close()
