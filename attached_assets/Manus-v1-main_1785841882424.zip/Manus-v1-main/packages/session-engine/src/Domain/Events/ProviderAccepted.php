<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\Events;

use DateTimeImmutable;
use Wasl\SharedKernel\Contracts\Events\DomainEvent;
use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class ProviderAccepted implements DomainEvent
{
    public function __construct(
        private UUID $sessionId,
        private UUID $eventId = new UUID(),
        private ?DateTimeImmutable $occurredAt = null,
    ) {
    }

    public function eventId(): UUID
    {
        return $this->eventId;
    }

    public function aggregateId(): UUID
    {
        return $this->sessionId;
    }

    public function eventName(): string
    {
        return 'session.provider_accepted';
    }

    public function occurredAt(): DateTimeImmutable
    {
        return $this->occurredAt ?? new DateTimeImmutable();
    }

    public function payload(): array
    {
        return [
            'session_id' => $this->sessionId->toString(),
        ];
    }
}
