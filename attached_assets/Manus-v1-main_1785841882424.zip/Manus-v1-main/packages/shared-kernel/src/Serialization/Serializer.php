<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Serialization;

interface Serializer
{
    public function serialize(mixed $value): string;

    public function deserialize(string $payload, string $class): mixed;
}
