<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Exceptions;

final class InfrastructureException extends DomainException
{
}
