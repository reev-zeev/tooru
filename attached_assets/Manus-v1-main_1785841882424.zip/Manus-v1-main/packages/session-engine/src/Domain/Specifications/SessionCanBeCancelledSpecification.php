<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\Specifications;

use Wasl\SessionEngine\Domain\Aggregates\ServiceSession;
use Wasl\SharedKernel\Specifications\AbstractSpecification;

final class SessionCanBeCancelledSpecification extends AbstractSpecification
{
    public function isSatisfiedBy(mixed $candidate): bool
    {
        if (!$candidate instanceof ServiceSession) {
            return false;
        }

        return !$candidate->state()->isFinal();
    }
}
