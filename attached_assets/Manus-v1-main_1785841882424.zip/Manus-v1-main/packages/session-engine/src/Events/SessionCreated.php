<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Events;

use Wasl\SharedKernel\Contracts\Events\DomainEvent;
use Wasl\SessionEngine\ValueObjects\SessionId;

final readonly class SessionCreated implements DomainEvent
{
    public function __construct(
        private SessionId $sessionId
    ) {
    }

    public function eventId()
    {
        return \Wasl\SharedKernel\ValueObjects\UUID::generate();
    }

    public function occurredAt()
    {
        return \Wasl\SharedKernel\ValueObjects\Timestamp::now();
    }

    public function eventName(): string
    {
        return 'session.created';
    }

    public function version(): int
    {
        return 1;
    }

    public function aggregateId()
    {
        return $this->sessionId;
    }

    public function payload(): array
    {
        return [
            'session_id' => (string) $this->sessionId,
        ];
    }
}
