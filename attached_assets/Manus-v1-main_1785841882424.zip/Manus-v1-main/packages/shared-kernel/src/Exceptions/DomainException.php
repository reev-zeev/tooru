<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Exceptions;

use RuntimeException;

class DomainException extends RuntimeException
{
}
