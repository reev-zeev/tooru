<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\Factories;

use Wasl\SessionEngine\Domain\Aggregates\ServiceSession;
use Wasl\SessionEngine\Domain\StateMachine\SessionStateMachine;
use Wasl\SharedKernel\Identity\IdentityGenerator;

final readonly class ServiceSessionFactory
{
    public function __construct(
        private IdentityGenerator $identityGenerator,
        private SessionStateMachine $stateMachine,
    ) {
    }

    public function create(): ServiceSession
    {
        return ServiceSession::create(
            id: $this->identityGenerator->generate(),
            stateMachine: $this->stateMachine,
        );
    }
}
