<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Application\CommandHandlers;

use Wasl\MatchingEngine\Application\Commands\StartMatchingCommand;
use Wasl\MatchingEngine\Application\Ports\ProviderGateway;
use Wasl\MatchingEngine\Domain\Aggregates\MatchingProcess;
use Wasl\MatchingEngine\Domain\Repositories\MatchingRepository;
use Wasl\MatchingEngine\Domain\StateMachine\MatchingStateMachine;
use Wasl\MatchingEngine\Domain\Strategies\MatchingStrategy;
use Wasl\SharedKernel\Application\AggregatePersistenceManager;
use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class StartMatchingHandler
{
    public function __construct(
        private MatchingRepository $repository,
        private MatchingStateMachine $stateMachine,
        private MatchingStrategy $strategy,
        private ProviderGateway $providerGateway,
        private AggregatePersistenceManager $persistence,
    ) {
    }

    public function handle(StartMatchingCommand $command): MatchingProcess
    {
        $matching = MatchingProcess::create(
            UUID::generate(),
            $command->sessionId,
            $this->stateMachine,
        );

        $matching->startSearching();

        $providers = $this->providerGateway->availableProviders();

        $selected = $this->strategy->select(
            array_map(
                static fn ($provider) => [
                    'id' => $provider->id,
                    'rating' => $provider->rating,
                    'distance' => $provider->distance,
                ],
                $providers
            )
        );

        if ($selected !== null) {
            $matching->candidateFound();
            $matching->sendOffer();
        } else {
            $matching->exhausted();
        }

        $this->persistence->save(
            $matching,
            fn (MatchingProcess $aggregate) => $this->repository->save($aggregate),
        );

        return $matching;
    }
}
