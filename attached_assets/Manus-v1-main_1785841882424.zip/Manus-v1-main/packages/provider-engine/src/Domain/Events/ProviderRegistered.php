<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Domain\Events;

use DateTimeImmutable;
use Wasl\SharedKernel\Contracts\Events\DomainEvent;
use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class ProviderRegistered implements DomainEvent
{
    public function __construct(
        private UUID $providerId,
        private ?DateTimeImmutable $occurredAt = null,
    ) {
    }

    public function eventId(): UUID
    {
        return UUID::generate();
    }

    public function aggregateId(): UUID
    {
        return $this->providerId;
    }

    public function eventName(): string
    {
        return 'provider.registered';
    }

    public function occurredAt(): DateTimeImmutable
    {
        return $this->occurredAt ?? new DateTimeImmutable();
    }

    public function payload(): array
    {
        return [
            'provider_id' => $this->providerId->toString(),
        ];
    }
}
