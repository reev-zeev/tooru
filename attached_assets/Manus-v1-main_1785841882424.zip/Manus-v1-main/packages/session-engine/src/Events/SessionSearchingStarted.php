<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Events;

final class SessionSearchingStarted extends AbstractSessionEvent
{
    public function eventName(): string
    {
        return 'session.searching.started';
    }
}
