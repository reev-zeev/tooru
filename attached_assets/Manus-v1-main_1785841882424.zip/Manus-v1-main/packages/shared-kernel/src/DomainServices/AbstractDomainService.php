<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\DomainServices;

abstract class AbstractDomainService implements DomainService
{
}
