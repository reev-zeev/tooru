<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\StateMachine;

use Wasl\SharedKernel\Exceptions\DomainException;
use Wasl\SharedKernel\StateMachine\Contracts\Guard;
use Wasl\SharedKernel\StateMachine\Contracts\State;
use Wasl\SharedKernel\StateMachine\Contracts\Transition;

final class StateMachine
{
    /**
     * @param Guard[] $guards
     */
    public function transition(
        State $current,
        Transition $transition,
        array $guards = []
    ): string {
        if ($current->isFinal()) {
            throw new DomainException(
                'Cannot transition from a final state.'
            );
        }

        if ($current->name() !== $transition->from()) {
            throw new DomainException(
                'Invalid state transition.'
            );
        }

        foreach ($guards as $guard) {
            if (!$guard->allows($current, $transition)) {
                throw new DomainException(
                    'Transition blocked by guard.'
                );
            }
        }

        return $transition->to();
    }
}
