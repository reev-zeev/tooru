<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Messaging;

interface MessageBus
{
    public function dispatch(Message $message): mixed;
}
