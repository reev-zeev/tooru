<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Projection;

use DateTimeImmutable;
use Wasl\SessionEngine\Domain\Events\ProviderAccepted;
use Wasl\SessionEngine\Domain\Events\ProviderMatched;
use Wasl\SessionEngine\Domain\Events\SessionCompleted;
use Wasl\SessionEngine\Domain\Events\SessionCreated;

final class SessionProjection
{
    /**
     * @var array<string, SessionView>
     */
    private array $views = [];

    public function onSessionCreated(SessionCreated $event): void
    {
        $this->views[$event->aggregateId()->toString()] = new SessionView(
            id: $event->aggregateId()->toString(),
            state: 'created',
            updatedAt: (new DateTimeImmutable())->format(DATE_ATOM),
        );
    }

    public function onProviderMatched(ProviderMatched $event): void
    {
        $this->update($event->aggregateId()->toString(), 'matched');
    }

    public function onProviderAccepted(ProviderAccepted $event): void
    {
        $this->update($event->aggregateId()->toString(), 'provider_accepted');
    }

    public function onSessionCompleted(SessionCompleted $event): void
    {
        $this->update($event->aggregateId()->toString(), 'completed');
    }

    public function find(string $id): ?SessionView
    {
        return $this->views[$id] ?? null;
    }

    private function update(string $id, string $state): void
    {
        if (!isset($this->views[$id])) {
            return;
        }

        $this->views[$id] = new SessionView(
            id: $id,
            state: $state,
            updatedAt: (new DateTimeImmutable())->format(DATE_ATOM),
        );
    }
}
