<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Support;

use LogicException;

final readonly class Optional
{
    private function __construct(
        private mixed $value
    ) {
    }

    public static function of(mixed $value): self
    {
        if ($value === null) {
            throw new LogicException('Optional cannot contain null.');
        }

        return new self($value);
    }

    public static function ofNullable(mixed $value): self
    {
        return new self($value);
    }

    public function isPresent(): bool
    {
        return $this->value !== null;
    }

    public function isEmpty(): bool
    {
        return $this->value === null;
    }

    public function get(): mixed
    {
        if ($this->isEmpty()) {
            throw new LogicException('Optional is empty.');
        }

        return $this->value;
    }

    public function orElse(mixed $default): mixed
    {
        return $this->value ?? $default;
    }

    public function orNull(): mixed
    {
        return $this->value;
    }
}
