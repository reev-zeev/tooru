<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Bus;

use RuntimeException;

final class InMemoryQueryBus implements QueryBus
{
    /**
     * @var array<string, callable>
     */
    private array $handlers = [];

    public function register(string $queryClass, callable $handler): void
    {
        $this->handlers[$queryClass] = $handler;
    }

    public function ask(object $query): mixed
    {
        $handler = $this->handlers[$query::class] ?? null;

        if ($handler === null) {
            throw new RuntimeException(
                sprintf('No handler registered for query [%s].', $query::class)
            );
        }

        return $handler($query);
    }
}
