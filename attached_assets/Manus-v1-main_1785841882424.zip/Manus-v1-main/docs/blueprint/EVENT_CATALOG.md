# Wasl Platform Event Catalog

Version: 1.0.0
Status: DRAFT

========================================
CANONICAL EVENT MODEL
========================================

Every event MUST contain:

- event_id
- event_name
- event_version
- aggregate_id
- aggregate_type
- session_id
- correlation_id
- causation_id
- producer
- occurred_at (UTC)
- payload
- metadata

========================================
CUSTOMER EVENTS
========================================

CustomerRegistered

CustomerUpdated

CustomerBlocked

CustomerUnblocked

CustomerRequestedService

CustomerCancelledRequest

CustomerUpdatedPickup

CustomerUpdatedDestination

CustomerSentMessage

CustomerRatedProvider

CustomerNoShow

CustomerDeletedAccount

========================================
PROVIDER EVENTS
========================================

ProviderRegistered

ProviderVerified

ProviderOnline

ProviderOffline

ProviderBusy

ProviderAvailable

ProviderAcceptedOrder

ProviderRejectedOrder

ProviderArrived

ProviderStartedService

ProviderCompletedService

ProviderCancelledService

ProviderLocationUpdated

ProviderSentMessage

ProviderRatedCustomer

ProviderNoResponse

ProviderDisconnected

ProviderSuspended

========================================
ORDER EVENTS
========================================

OrderCreated

OrderValidated

OrderSearching

OrderMatched

OrderExpired

OrderCancelled

OrderReassigned

OrderArchived

========================================
SESSION EVENTS
========================================

SessionCreated

SessionStarted

SessionRecovered

SessionPaused

SessionResumed

SessionCompleted

SessionCancelled

SessionArchived

SessionTimeout

========================================
DISPATCH EVENTS
========================================

DispatchStarted

DispatchCandidatesSelected

DispatchOfferSent

DispatchOfferExpired

DispatchAccepted

DispatchRejected

DispatchRetryStarted

DispatchFallbackActivated

========================================
BOOKING EVENTS
========================================

BookingCreated

BookingConfirmed

BookingReminderSent

BookingStarted

BookingCancelled

BookingCompleted

RecurringBookingGenerated

========================================
PAYMENT EVENTS
========================================

PaymentCreated

PaymentAuthorized

PaymentCaptured

PaymentFailed

PaymentRefunded

PaymentAdjusted

========================================
CHAT EVENTS
========================================

ChatOpened

ChatMessageSent

ChatMessageDelivered

ChatMessageRead

ChatClosed

========================================
NOTIFICATION EVENTS
========================================

NotificationQueued

NotificationSent

NotificationDelivered

NotificationFailed

NotificationRetried

========================================
POLICY EVENTS
========================================

PolicyTriggered

PenaltyApplied

RewardGranted

FraudDetected

AccountFlagged

ReliabilityUpdated

========================================
SYSTEM EVENTS
========================================

HeartbeatReceived

HealthCheckPassed

HealthCheckFailed

CacheMiss

CacheRecovered

QueueOverflow

QueueRecovered

DatabaseRecovered

RedisRecovered

WebSocketDisconnected

WebSocketRecovered

SystemStarted

SystemStopped

========================================
AUDIT EVENTS
========================================

AuditRecorded

AdminActionExecuted

PermissionGranted

PermissionRevoked

========================================
EVENT RULES
========================================

Events are immutable.

Events are append-only.

Events never updated.

Events never deleted.

Events always versioned.

Events always timestamped in UTC.

Events are idempotent.

Events are backward compatible.

Every business action produces at least one event.

Every event belongs to exactly one Aggregate.

