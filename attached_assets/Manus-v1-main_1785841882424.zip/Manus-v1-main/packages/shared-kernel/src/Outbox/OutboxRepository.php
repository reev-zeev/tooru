<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Outbox;

interface OutboxRepository
{
    public function add(OutboxMessage $message): void;

    /**
     * @return OutboxMessage[]
     */
    public function pending(): array;

    public function save(OutboxMessage $message): void;
}
