<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Money;

use InvalidArgumentException;

final readonly class Money
{
    public function __construct(
        private int $amount,
        private Currency $currency
    ) {
    }

    public static function zero(Currency $currency): self
    {
        return new self(0, $currency);
    }

    public function amount(): int
    {
        return $this->amount;
    }

    public function currency(): Currency
    {
        return $this->currency;
    }

    public function add(self $money): self
    {
        $this->assertSameCurrency($money);

        return new self(
            $this->amount + $money->amount(),
            $this->currency
        );
    }

    public function subtract(self $money): self
    {
        $this->assertSameCurrency($money);

        return new self(
            $this->amount - $money->amount(),
            $this->currency
        );
    }

    public function multiply(int $factor): self
    {
        return new self(
            $this->amount * $factor,
            $this->currency
        );
    }

    public function equals(self $other): bool
    {
        return $this->amount === $other->amount()
            && $this->currency->equals($other->currency());
    }

    private function assertSameCurrency(self $money): void
    {
        if (!$this->currency->equals($money->currency())) {
            throw new InvalidArgumentException('Currency mismatch.');
        }
    }

    public function __toString(): string
    {
        return number_format($this->amount / 100, 2, '.', '') . ' ' . $this->currency;
    }
}
