<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Transactions;

final class InMemoryTransactionManager implements TransactionManager
{
    private bool $active = false;

    public function begin(): void
    {
        $this->active = true;
    }

    public function commit(): void
    {
        $this->active = false;
    }

    public function rollback(): void
    {
        $this->active = false;
    }

    public function transactional(callable $callback): mixed
    {
        $this->begin();

        try {
            $result = $callback();

            $this->commit();

            return $result;
        } catch (\Throwable $e) {
            $this->rollback();

            throw $e;
        }
    }
}
