<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Repositories;

use Wasl\SessionEngine\Contracts\SessionRepository;
use Wasl\SessionEngine\Session\ServiceSession;
use Wasl\SessionEngine\ValueObjects\SessionId;

final class InMemorySessionRepository implements SessionRepository
{
    /**
     * @var array<string, ServiceSession>
     */
    private array $sessions = [];

    public function save(ServiceSession $session): void
    {
        $this->sessions[(string)$session->id()] = $session;
    }

    public function find(SessionId $id): ?ServiceSession
    {
        return $this->sessions[(string)$id] ?? null;
    }
}
