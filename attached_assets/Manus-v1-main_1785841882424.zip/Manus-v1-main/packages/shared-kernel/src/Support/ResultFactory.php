<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Support;

final class ResultFactory
{
    public static function ok(mixed $value = null): Result
    {
        return Result::success($value);
    }

    public static function fail(string $message): Result
    {
        return Result::failure($message);
    }
}
