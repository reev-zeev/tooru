<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Support;

final readonly class Pagination
{
    public function __construct(
        private int $page,
        private int $perPage
    ) {
    }

    public function page(): int
    {
        return $this->page;
    }

    public function perPage(): int
    {
        return $this->perPage;
    }

    public function offset(): int
    {
        return ($this->page - 1) * $this->perPage;
    }
}
