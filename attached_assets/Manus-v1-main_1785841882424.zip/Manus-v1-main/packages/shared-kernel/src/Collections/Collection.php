<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Collections;

use ArrayIterator;
use Countable;
use IteratorAggregate;
use Traversable;

abstract class Collection implements IteratorAggregate, Countable
{
    protected array $items = [];

    final public function __construct(array $items = [])
    {
        $this->items = array_values($items);
    }

    final public function all(): array
    {
        return $this->items;
    }

    final public function isEmpty(): bool
    {
        return $this->items === [];
    }

    final public function count(): int
    {
        return count($this->items);
    }

    final public function getIterator(): Traversable
    {
        return new ArrayIterator($this->items);
    }
}
