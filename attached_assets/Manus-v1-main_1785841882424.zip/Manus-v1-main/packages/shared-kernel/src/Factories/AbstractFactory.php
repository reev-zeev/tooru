<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Factories;

abstract class AbstractFactory implements Factory
{
}
