<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Contracts;

use Wasl\SessionEngine\Session\ServiceSession;

interface SessionUnitOfWork
{
    public function register(ServiceSession $session): void;

    public function commit(): void;

    public function rollback(): void;
}
