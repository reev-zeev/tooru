import os, sys, asyncio, asyncpg
from pathlib import Path
from datetime import datetime, timezone, timedelta
from aiogram import Bot, Dispatcher, Router, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (Message, CallbackQuery, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton)
from dotenv import load_dotenv
load_dotenv()

# --- إعدادات ---
BOT_TOKEN = os.getenv("DRIVER_BOT_TOKEN", "")
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]
APP_NAME = os.getenv("APP_NAME", "حجازي")
WISE_LINK = os.getenv("WISE_PAYMENT_LINK", "https://wise.com")
MANAGEMENT_GROUP_ID = os.getenv("MANAGEMENT_GROUP_ID", "")

if not BOT_TOKEN:
    raise RuntimeError("❌ DRIVER_BOT_TOKEN غير موجود")

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=MemoryStorage())
router = Router()
dp.include_router(router)

pool = None

class DriverReg(StatesGroup):
    name = State(); phone = State(); city = State(); work_area = State()
    preferred = State(); car_model = State(); plate = State(); privacy = State()

async def is_subscribed(tg_id):
    async with pool.acquire() as conn:
        drv = await conn.fetchrow("SELECT subscription, subscription_until FROM drivers WHERE tg_id=$1", tg_id)
    if not drv: return False
    if drv["subscription"] == "subscribed" and drv["subscription_until"] and drv["subscription_until"] > datetime.now(timezone.utc):
        return True
    return False

async def is_available(tg_id):
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT is_available FROM drivers WHERE tg_id=$1", tg_id)
    return row["is_available"] if row else False

async def set_availability(tg_id, status: bool):
    async with pool.acquire() as conn:
        await conn.execute("UPDATE drivers SET is_available=$1 WHERE tg_id=$2", status, tg_id)

async def is_member_of_group(user_id, group_id):
    try:
        member = await bot.get_chat_member(group_id, user_id)
        return member.status in ['member', 'administrator', 'creator']
    except: return False

def main_menu(is_sub=False, available=False):
    status_text = "✅ مشترك" if is_sub else "❌ غير مشترك"
    kb = [[KeyboardButton(text="🚗 تسجيل/تحديث بياناتي")]]
    if is_sub:
        avail_btn = "🔴 غير متاح" if available else "🟢 متاح"
        kb.append([KeyboardButton(text=avail_btn)])
    kb.append([KeyboardButton(text="💳 اشتراك"), KeyboardButton(text="📍 تحديث موقعي")])
    kb.append([KeyboardButton(text="ℹ️ تعليمات الاشتراك")])
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)

# --- أمر البداية ---
@router.message(Command("start"))
async def start(msg: Message, state: FSMContext):
    await state.clear()
    async with pool.acquire() as conn:
        await conn.execute("INSERT INTO users (tg_id, full_name, username) VALUES ($1,$2,$3) ON CONFLICT (tg_id) DO UPDATE SET full_name=$2, username=$3",
            msg.from_user.id, msg.from_user.full_name, msg.from_user.username)
    is_sub = await is_subscribed(msg.from_user.id)
    available = await is_available(msg.from_user.id)
    await msg.answer(f"🚗 أهلاً بك في {APP_NAME} للسائقين!\nحالة اشتراكك: {'✅ مشترك' if is_sub else '❌ غير مشترك'}", reply_markup=main_menu(is_sub, available))

@router.message(Command("id"))
async def get_chat_id(msg: Message):
    await msg.reply(f"Chat ID: <code>{msg.chat.id}</code>")

# --- زر التبديل: متاح / غير متاح ---
@router.message(F.text.in_(["🟢 متاح", "🔴 غير متاح"]))
async def toggle_availability(msg: Message):
    is_sub = await is_subscribed(msg.from_user.id)
    if not is_sub:
        return await msg.answer("❌ هذه الميزة متاحة للمشتركين فقط.")
    current = await is_available(msg.from_user.id)
    new_status = not current
    await set_availability(msg.from_user.id, new_status)
    if new_status:
        await msg.answer("🟢 أنت الآن <b>متاح</b> لاستقبال الطلبات. استخدم '📍 تحديث موقعي' ليتمكن الزبائن من العثور عليك.", reply_markup=main_menu(True, True))
    else:
        await msg.answer("🔴 أنت الآن <b>غير متاح</b>. لن تصلك أي طلبات جديدة حتى تعود متاحاً.", reply_markup=main_menu(True, False))

# --- تسجيل السائق (مضغوط) ---
@router.message(F.text == "🚗 تسجيل/تحديث بياناتي")
async def reg_start(msg: Message, state: FSMContext):
    await state.set_state(DriverReg.name)
    await msg.answer("👤 اسمك الكامل:")

@router.message(DriverReg.name)
async def reg_name(msg: Message, state: FSMContext):
    await state.update_data(name=msg.text); await state.set_state(DriverReg.phone)
    await msg.answer("📱 رقم جوالك:")

@router.message(DriverReg.phone)
async def reg_phone(msg: Message, state: FSMContext):
    await state.update_data(phone=msg.text); await state.set_state(DriverReg.city)
    await msg.answer("🏙️ مدينتك الرئيسية (مثلاً: جدة):")

@router.message(DriverReg.city)
async def reg_city(msg: Message, state: FSMContext):
    await state.update_data(city=msg.text); await state.set_state(DriverReg.work_area)
    await msg.answer("🗺️ نطاق عملك (مثلاً: شمال جدة):")

@router.message(DriverReg.work_area)
async def reg_area(msg: Message, state: FSMContext):
    await state.update_data(work_area=msg.text); await state.set_state(DriverReg.preferred)
    await msg.answer("❤️ مناطقك المفضلة مفصولة بفواصل (مثلاً: السلامة, الروضة):")

@router.message(DriverReg.preferred)
async def reg_pref(msg: Message, state: FSMContext):
    await state.update_data(preferred=msg.text); await state.set_state(DriverReg.car_model)
    await msg.answer("🚘 موديل السيارة (مثلاً: كامري 2020):")

@router.message(DriverReg.car_model)
async def reg_car(msg: Message, state: FSMContext):
    await state.update_data(car_model=msg.text); await state.set_state(DriverReg.plate)
    await msg.answer("🔢 رقم اللوحة:")

@router.message(DriverReg.plate)
async def reg_plate(msg: Message, state: FSMContext):
    await state.update_data(plate=msg.text); await state.set_state(DriverReg.privacy)
    await msg.answer("🔒 اختر إعداد الخصوصية:", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔓 رقم ظاهر", callback_data="priv_open"), InlineKeyboardButton(text="🔐 خصوصية تامة", callback_data="priv_hidden")]
    ]))

@router.callback_query(DriverReg.privacy)
async def reg_privacy(cb: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    privacy = "open" if cb.data == "priv_open" else "hidden"
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO drivers (tg_id, phone, city, work_area, preferred_areas, car_model, plate_number, privacy)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
            ON CONFLICT (tg_id) DO UPDATE SET phone=$2, city=$3, work_area=$4, preferred_areas=$5, car_model=$6, plate_number=$7, privacy=$8
        """, cb.from_user.id, data['phone'], data['city'], data['work_area'], data['preferred'], data['car_model'], data['plate'], privacy)
        # تحديث الاسم في جدول users وليس drivers
        await conn.execute("UPDATE users SET full_name=$1 WHERE tg_id=$2", data['name'], cb.from_user.id)
    await state.clear()
    await cb.message.answer("✅ تم تسجيل/تحديث بياناتك بنجاح! للإستفادة الكاملة، اشترك الآن.", reply_markup=main_menu(False))
    await cb.answer()

# --- الاشتراك ---
@router.message(F.text == "💳 اشتراك")
async def sub_info(msg: Message):
    text = (
        f"💰 <b>اشتراك السائق</b>\n\n"
        f"🎯 السعر: <b>50 ريال شهرياً</b>\n"
        f"⚡ المميزات:\n- وصول فوري للطلبات القريبة\n- أولوية على السائقين المجانيين\n- إحصائيات متقدمة\n- زر متاح/غير متاح\n\n"
        f"📌 <b>للدفع عبر Wise:</b>\n{WISE_LINK}\n\n"
        f"بعد الدفع، اضغط زر 'تقديم طلب اشتراك' أدناه للانضمام."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📩 تقديم طلب اشتراك", callback_data="request_sub")]
    ])
    await msg.answer(text, reply_markup=markup)

@router.callback_query(F.data == "request_sub")
async def request_sub(cb: CallbackQuery):
    user = cb.from_user
    async with pool.acquire() as conn:
        # ✅ تم الإصلاح: جلب full_name من users بدلاً من drivers
        drv = await conn.fetchrow("""
            SELECT u.full_name, d.phone 
            FROM drivers d 
            JOIN users u ON u.tg_id = d.tg_id 
            WHERE d.tg_id=$1
        """, user.id)
        if not drv:
            await cb.answer("❌ سجل بياناتك أولاً.", show_alert=True)
            return
    management_group = os.getenv("MANAGEMENT_GROUP_ID")
    if management_group:
        try:
            markup = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="✅ تفعيل", callback_data=f"approve_sub:{user.id}"),
                 InlineKeyboardButton(text="❌ رفض", callback_data=f"reject_sub:{user.id}")]
            ])
            await bot.send_message(
                management_group,
                f"📩 <b>طلب اشتراك جديد</b>\n\n"
                f"👤 الاسم: {drv['full_name']}\n"
                f"📱 الجوال: {drv['phone']}\n"
                f"🆔 المعرف: <code>{user.id}</code>\n\n"
                f"للتفعيل، استخدم الأمر:\n<code>/activate {user.id}</code>",
                reply_markup=markup
            )
        except Exception as e:
            print(f"فشل إرسال إشعار للإدارة: {e}")
    await cb.answer("✅ تم تقديم طلب اشتراكك. ستتم مراجعته.")
    await cb.message.answer("✅ تم تقديم طلبك للإدارة. سيتم تفعيل اشتراكك بعد التأكد من الدفع.")

@router.callback_query(F.data.startswith("approve_sub:"))
async def approve_sub_callback(cb: CallbackQuery):
    user_id = cb.from_user.id
    management_group = os.getenv("MANAGEMENT_GROUP_ID")
    if not management_group or not await is_member_of_group(user_id, management_group):
        await cb.answer("❌ غير مصرح لك.", show_alert=True)
        return
    target = int(cb.data.split(":")[1])
    until = datetime.now(timezone.utc) + timedelta(days=30)
    async with pool.acquire() as conn:
        await conn.execute("UPDATE drivers SET subscription='subscribed', subscription_until=$1 WHERE tg_id=$2", until, target)
    await cb.message.edit_text(cb.message.text + f"\n\n✅ <b>تم التفعيل بواسطة {cb.from_user.full_name}</b>")
    await bot.send_message(target, "🎉 مبروك! تم تفعيل اشتراكك كـ 'سائق واصل'. استخدم '📍 تحديث موقعي' باستمرار لتصلك الطلبات!")
    await cb.answer("✅ تم التفعيل.")

@router.callback_query(F.data.startswith("reject_sub:"))
async def reject_sub_callback(cb: CallbackQuery):
    user_id = cb.from_user.id
    management_group = os.getenv("MANAGEMENT_GROUP_ID")
    if not management_group or not await is_member_of_group(user_id, management_group):
        await cb.answer("❌ غير مصرح لك.", show_alert=True)
        return
    target = int(cb.data.split(":")[1])
    await cb.message.edit_text(cb.message.text + f"\n\n❌ <b>تم الرفض بواسطة {cb.from_user.full_name}</b>")
    await bot.send_message(target, "❌ نعتذر، تم رفض طلب اشتراكك. تأكد من إتمام الدفع بشكل صحيح.")
    await cb.answer("تم الرفض.")

@router.message(Command("activate"))
async def activate_sub(msg: Message):
    user_id = msg.from_user.id
    management_group = os.getenv("MANAGEMENT_GROUP_ID", "")
    is_allowed = (user_id in ADMIN_IDS)
    if not is_allowed and management_group:
        is_allowed = await is_member_of_group(user_id, management_group)
    if not is_allowed: return
    parts = msg.text.split()
    if len(parts) < 2: return await msg.reply("الاستخدام: /activate <tg_id>")
    target = int(parts[1])
    until = datetime.now(timezone.utc) + timedelta(days=30)
    async with pool.acquire() as conn:
        # ✅ تم الإصلاح: جلب full_name من users بدلاً من drivers
        drv = await conn.fetchrow("""
            SELECT u.full_name 
            FROM drivers d 
            JOIN users u ON u.tg_id = d.tg_id 
            WHERE d.tg_id=$1
        """, target)
        await conn.execute("UPDATE drivers SET subscription='subscribed', subscription_until=$1 WHERE tg_id=$2", until, target)
    driver_name = drv["full_name"] if drv else f"سائق {target}"
    activator_name = msg.from_user.full_name
    await msg.reply(f"✅ تم تفعيل اشتراك {driver_name} ({target}) حتى {until.strftime('%Y-%m-%d')}.")
    await bot.send_message(target, "🎉 مبروك! تم تفعيل اشتراكك كـ 'سائق واصل'. استخدم '📍 تحديث موقعي' باستمرار لتصلك الطلبات!")
    if str(msg.chat.id) != management_group and management_group:
        await bot.send_message(management_group, f"📢 {driver_name} ({target}) تم تفعيله بواسطة {activator_name}.")

@router.message(F.text == "ℹ️ تعليمات الاشتراك")
async def sub_help(msg: Message):
    await msg.answer(
        "📖 <b>كيف تستفيد من اشتراكك؟</b>\n\n"
        "1. <b>حدّث موقعك:</b> استخدم زر '📍 تحديث موقعي' باستمرار.\n"
        "2. <b>حدد مناطقك المفضلة:</b> لتصلك طلبات الأحياء القريبة منك.\n"
        "3. <b>ضبط التواجد:</b> استخدم زر '🟢 متاح' / '🔴 غير متاح'.\n"
        "4. <b>قيم عالي:</b> كلما ارتفع تقييمك زادت فرص وصول الطلبات إليك."
    )

# --- تحديث الموقع ---
@router.message(F.text == "📍 تحديث موقعي")
async def update_loc(msg: Message):
    await msg.answer("📍 أرسل موقعك الحالي:", reply_markup=ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="📍 إرسال الموقع", request_location=True)]], resize_keyboard=True
    ))

@router.message(F.location)
async def handle_location(msg: Message):
    async with pool.acquire() as conn:
        await conn.execute("UPDATE drivers SET last_lat=$1, last_lon=$2 WHERE tg_id=$3", msg.location.latitude, msg.location.longitude, msg.from_user.id)
    is_sub = await is_subscribed(msg.from_user.id)
    available = await is_available(msg.from_user.id)
    await msg.answer("✅ تم تحديث موقعك بنجاح.", reply_markup=main_menu(is_sub, available))

@router.message(Command("verify"))
async def verify_driver(msg: Message):
    if msg.from_user.id not in ADMIN_IDS: return
    parts = msg.text.split()
    if len(parts) < 2: return await msg.reply("الاستخدام: /verify <tg_id>")
    target = int(parts[1])
    async with pool.acquire() as conn:
        await conn.execute("UPDATE drivers SET verified=TRUE WHERE tg_id=$1", target)
    await msg.reply(f"✅ تم تفعيل السائق {target}.")
    await bot.send_message(target, "🎉 تم تفعيل حسابك كسائق. يمكنك الآن استقبال الطلبات!")

print("✅ وحدة بوت السائق جاهزة.")
