<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Tests\Integration;

use PHPUnit\Framework\TestCase;
use Wasl\SessionEngine\Domain\Aggregates\ServiceSession;
use Wasl\SessionEngine\Domain\StateMachine\SessionStateMachine;
use Wasl\SessionEngine\Infrastructure\Persistence\InMemorySessionRepository;
use Wasl\SharedKernel\Exceptions\ConcurrencyException;
use Wasl\SharedKernel\ValueObjects\UUID;

final class OptimisticConcurrencyTest extends TestCase
{
    public function test_repository_rejects_stale_aggregate(): void
    {
        $repository = new InMemorySessionRepository();

        $session = ServiceSession::create(
            UUID::generate(),
            new SessionStateMachine(),
        );

        $repository->save($session);

        $session->startSearching();

        $repository->save($session);

        $this->expectException(ConcurrencyException::class);

        // محاولة حفظ نفس النسخة مرة أخرى بدون إصدار أحدث
        $repository->save($session);
    }

    public function test_version_increments_after_state_transition(): void
    {
        $session = ServiceSession::create(
            UUID::generate(),
            new SessionStateMachine(),
        );

        $initialVersion = $session->version()->value();

        $session->startSearching();

        self::assertGreaterThan(
            $initialVersion,
            $session->version()->value()
        );
    }
}
