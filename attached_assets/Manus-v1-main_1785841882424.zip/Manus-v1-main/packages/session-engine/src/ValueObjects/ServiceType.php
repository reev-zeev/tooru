<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\ValueObjects;

use InvalidArgumentException;

final readonly class ServiceType
{
    public const TAXI = 'taxi';
    public const DELIVERY = 'delivery';

    public function __construct(
        private string $value
    ) {
        if (!in_array($value, [
            self::TAXI,
            self::DELIVERY,
        ], true)) {
            throw new InvalidArgumentException('Invalid service type.');
        }
    }

    public function value(): string
    {
        return $this->value;
    }

    public function __toString(): string
    {
        return $this->value;
    }
}
