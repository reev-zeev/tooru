import os, sys, asyncio, asyncpg, math
from pathlib import Path
from datetime import datetime, timezone
from aiogram import Bot, Dispatcher, Router, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (Message, CallbackQuery, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton)
from dotenv import load_dotenv
load_dotenv()

# --- الإعدادات الأساسية ---
BOT_TOKEN = os.getenv("PASSENGER_BOT_TOKEN", "")
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]
APP_NAME = os.getenv("APP_NAME", "حجازي")

if not BOT_TOKEN:
    raise RuntimeError("❌ BOT_TOKEN غير موجود")

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=MemoryStorage())
router = Router()
dp.include_router(router)

DATABASE_URL = os.getenv("DATABASE_URL", "")
pool: asyncpg.Pool = None

async def create_pool():
    global pool
    if not DATABASE_URL:
        raise RuntimeError("❌ DATABASE_URL غير موجود")
    pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=5)
    async with pool.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                tg_id BIGINT PRIMARY KEY, full_name TEXT, username TEXT,
                phone TEXT, role TEXT DEFAULT 'user',
                is_vip BOOLEAN DEFAULT FALSE, vip_until TIMESTAMPTZ,
                rating_avg FLOAT DEFAULT 5.0, rating_count INT DEFAULT 0,
                last_lat DOUBLE PRECISION, last_lon DOUBLE PRECISION,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS drivers (
                tg_id BIGINT PRIMARY KEY REFERENCES users(tg_id),
                city TEXT, work_area TEXT, preferred_areas TEXT,
                car_model TEXT, plate_number TEXT, phone TEXT,
                privacy TEXT DEFAULT 'open',
                subscription TEXT DEFAULT 'free', subscription_until TIMESTAMPTZ,
                verified BOOLEAN DEFAULT FALSE,
                is_available BOOLEAN DEFAULT TRUE,
                rating_avg FLOAT DEFAULT 5.0, rating_count INT DEFAULT 0,
                accept_count INT DEFAULT 0, cancel_count INT DEFAULT 0,
                last_lat DOUBLE PRECISION, last_lon DOUBLE PRECISION,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS rides (
                id SERIAL PRIMARY KEY, customer_id BIGINT, driver_id BIGINT,
                city TEXT, pickup_area TEXT, pickup_lat DOUBLE PRECISION,
                pickup_lon DOUBLE PRECISION, dest_area TEXT,
                dest_lat DOUBLE PRECISION, dest_lon DOUBLE PRECISION,
                price TEXT, payment_method TEXT,
                status TEXT DEFAULT 'waiting',
                created_at TIMESTAMPTZ DEFAULT NOW(),
                accepted_at TIMESTAMPTZ, completed_at TIMESTAMPTZ,
                cancelled_at TIMESTAMPTZ
            );
            CREATE TABLE IF NOT EXISTS ride_offers (
                id SERIAL PRIMARY KEY, ride_id INT REFERENCES rides(id),
                driver_id BIGINT, counter_price TEXT,
                status TEXT DEFAULT 'pending', created_at TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS ratings (
                id SERIAL PRIMARY KEY, ride_id INT REFERENCES rides(id),
                rater_id BIGINT, ratee_id BIGINT,
                stars INT CHECK (stars BETWEEN 1 AND 5),
                created_at TIMESTAMPTZ DEFAULT NOW(),
                UNIQUE(ride_id, rater_id)
            );
            CREATE TABLE IF NOT EXISTS favorites (
                customer_id BIGINT, driver_id BIGINT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                UNIQUE(customer_id, driver_id)
            );
            CREATE TABLE IF NOT EXISTS groups_config (
                id SERIAL PRIMARY KEY, city TEXT, type TEXT, chat_id BIGINT
            );
            CREATE TABLE IF NOT EXISTS emergency_alerts (
                id SERIAL PRIMARY KEY, ride_id INT, user_id BIGINT,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
        """)
        # ضمان وجود عمود is_available
        await conn.execute("ALTER TABLE drivers ADD COLUMN IF NOT EXISTS is_available BOOLEAN DEFAULT TRUE")
    print("✅ قاعدة بيانات الراكب جاهزة.")

def haversine_km(lat1, lon1, lat2, lon2):
    if None in [lat1, lon1, lat2, lon2]: return None
    r = 6371
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def tier_is_active(driver_row):
    if not driver_row: return "free"
    tier = driver_row.get("subscription") or "free"
    until = driver_row.get("subscription_until")
    if tier in ("subscribed", "bronze", "silver", "gold") and until and until > datetime.now(timezone.utc):
        return tier
    return "free"

def driver_score(ride_data, driver_row):
    score = 0.0
    tier = tier_is_active(driver_row)
    if tier == "subscribed": score += 300
    dist = haversine_km(ride_data.get("pickup_lat"), ride_data.get("pickup_lon"),
                        driver_row.get("last_lat"), driver_row.get("last_lon"))
    if dist is not None:
        if dist <= 3: score += 200
        elif dist <= 7: score += 100
        elif dist <= 15: score += 30
        score -= min(dist, 25)
    pickup_area = (ride_data.get("pickup_area") or "").strip().lower()
    preferred = (driver_row.get("preferred_areas") or "").strip().lower()
    if pickup_area and preferred:
        parts = [x.strip() for x in preferred.replace("،", ",").split(",") if x.strip()]
        for p in parts:
            if p in pickup_area or pickup_area in p:
                score += 80
                break
    rating = float(driver_row.get("rating") or 5)
    score += rating * 10
    return score

async def get_ride_full(ride_id):
    async with pool.acquire() as conn:
        return await conn.fetchrow("""
            SELECT r.*, cu.full_name as cust_name, du.full_name as drv_name,
                   du.phone as drv_phone, d.car_model, d.plate_number, d.rating_avg
            FROM rides r
            JOIN users cu ON cu.tg_id = r.customer_id
            LEFT JOIN users du ON du.tg_id = r.driver_id
            LEFT JOIN drivers d ON d.tg_id = r.driver_id
            WHERE r.id = $1
        """, ride_id)

async def send_safe(chat_id, text, reply_markup=None):
    try: return await bot.send_message(chat_id, text, reply_markup=reply_markup)
    except Exception as e: print(f"send_safe error: {e}")

def main_menu(user_id):
    kb = [[KeyboardButton(text="🚕 طلب مشوار")]]
    kb.append([KeyboardButton(text="📍 مشاركة موقعي"), KeyboardButton(text="⭐ مفضلتي")])
    kb.append([KeyboardButton(text="🚨 طوارئ"), KeyboardButton(text="ℹ️ المساعدة")])
    if user_id in ADMIN_IDS:
        kb.append([KeyboardButton(text="📊 إحصائيات"), KeyboardButton(text="👑 إدارة القروبات")])
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)

class RideRequest(StatesGroup):
    pickup = State()
    dest = State()
    price = State()
    payment = State()

class SOSForm(StatesGroup):
    details = State()

@router.message(Command("start"))
async def start(msg: Message, state: FSMContext):
    await state.clear()
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO users (tg_id, full_name, username) VALUES ($1, $2, $3)
            ON CONFLICT (tg_id) DO UPDATE SET full_name=$2, username=$3
        """, msg.from_user.id, msg.from_user.full_name, msg.from_user.username)
    await msg.answer(f"👋 أهلاً بك في <b>{APP_NAME}</b>! اختر من القائمة.", reply_markup=main_menu(msg.from_user.id))

@router.message(F.text == "🚕 طلب مشوار")
async def ride_start(msg: Message, state: FSMContext):
    await state.set_state(RideRequest.pickup)
    await msg.answer("📍 أرسل موقعك الحالي أو اكتب اسم الحي:", reply_markup=ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="📍 إرسال موقعي", request_location=True)], [KeyboardButton(text="إلغاء")]],
        resize_keyboard=True
    ))

@router.message(RideRequest.pickup)
async def ride_pickup(msg: Message, state: FSMContext):
    if msg.text == "إلغاء": return await state.clear(), await msg.answer("تم الإلغاء.", reply_markup=main_menu(msg.from_user.id))
    if msg.location:
        await state.update_data(pickup=msg.text or "موقع", lat=msg.location.latitude, lon=msg.location.longitude)
    else:
        await state.update_data(pickup=msg.text, lat=None, lon=None)
    await state.set_state(RideRequest.dest)
    await msg.answer("🎯 أين وجهتك؟ أرسل الموقع أو اكتب اسم المكان:", reply_markup=ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="📍 إرسال موقع الوجهة", request_location=True)], [KeyboardButton(text="إلغاء")]],
        resize_keyboard=True
    ))

@router.message(RideRequest.dest)
async def ride_dest(msg: Message, state: FSMContext):
    if msg.text == "إلغاء": return await state.clear(), await msg.answer("تم الإلغاء.", reply_markup=main_menu(msg.from_user.id))
    if msg.location:
        await state.update_data(dest=msg.text or "موقع", dest_lat=msg.location.latitude, dest_lon=msg.location.longitude)
    else:
        await state.update_data(dest=msg.text, dest_lat=None, dest_lon=None)
    await state.set_state(RideRequest.price)
    await msg.answer("💰 كم السعر المقترح؟ (مثلاً: 50، أو حسب الاتفاق)", reply_markup=ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="حسب الاتفاق")], [KeyboardButton(text="إلغاء")]], resize_keyboard=True
    ))

@router.message(RideRequest.price)
async def ride_price(msg: Message, state: FSMContext):
    if msg.text == "إلغاء": return await state.clear(), await msg.answer("تم الإلغاء.", reply_markup=main_menu(msg.from_user.id))
    await state.update_data(price=msg.text)
    await state.set_state(RideRequest.payment)
    await msg.answer("💳 اختر طريقة الدفع:", reply_markup=ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="💵 كاش")], [KeyboardButton(text="🏦 تحويل")], [KeyboardButton(text="📱 STC Pay")], [KeyboardButton(text="إلغاء")]],
        resize_keyboard=True
    ))

@router.message(RideRequest.payment)
async def ride_payment(msg: Message, state: FSMContext):
    if msg.text == "إلغاء": return await state.clear(), await msg.answer("تم الإلغاء.", reply_markup=main_menu(msg.from_user.id))
    data = await state.get_data()
    async with pool.acquire() as conn:
        ride_id = await conn.fetchval("""
            INSERT INTO rides (customer_id, pickup_area, pickup_lat, pickup_lon, dest_area, dest_lat, dest_lon, price, payment_method)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id
        """, msg.from_user.id, data['pickup'], data.get('lat'), data.get('lon'), data['dest'], data.get('dest_lat'), data.get('dest_lon'), data['price'], msg.text)
    await state.clear()
    await msg.answer(f"✅ تم إرسال طلبك #{ride_id}. جارٍ البحث عن أفضل سائق...", reply_markup=main_menu(msg.from_user.id))
    asyncio.create_task(dispatch_ride(ride_id, data))

# ============================================================
# نظام التوزيع الذكي (يحترم is_available)
# ============================================================
async def dispatch_ride(ride_id, ride_data):
    city = "جدة"
    async with pool.acquire() as conn:
        drivers = await conn.fetch("""
            SELECT * FROM drivers 
            WHERE verified=TRUE AND city=$1 AND tg_id != $2
            AND is_available = TRUE
        """, city, ride_data.get('customer_id'))
    scored = []
    for d in drivers:
        tier = tier_is_active(d)
        if tier != "subscribed": continue
        s = driver_score(ride_data, d)
        scored.append((s, d))
    scored.sort(key=lambda x: x[0], reverse=True)
    for _, driver in scored[:3]:
        if not await ride_is_waiting(ride_id): return
        await send_offer_to_driver(driver, ride_id, ride_data)
        await asyncio.sleep(30)
        if not await ride_is_waiting(ride_id): return
    await notify_groups(ride_id, ride_data)

async def send_offer_to_driver(driver, ride_id, ride_data):
    text = (
        f"🚕 <b>طلب مشوار جديد #{ride_id}</b>\n\n"
        f"📍 <b>من:</b> {ride_data.get('pickup')}\n"
        f"🎯 <b>إلى:</b> {ride_data.get('dest')}\n"
        f"💰 <b>السعر:</b> {ride_data.get('price')}\n"
        f"💳 <b>الدفع:</b> {ride_data.get('payment_method', 'غير محدد')}\n\n"
        f"<b>هل يناسبك المشوار؟</b>"
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ قبول", callback_data=f"accept:{ride_id}"),
         InlineKeyboardButton(text="💬 عرض سعر", callback_data=f"counter:{ride_id}")]
    ])
    await send_safe(driver["tg_id"], text, markup)

async def notify_groups(ride_id, ride_data):
    async with pool.acquire() as conn:
        groups = await conn.fetch("SELECT chat_id FROM groups_config")
    text = (
        f"🚕 <b>مشوار متاح للجميع #{ride_id}</b>\n"
        f"📍 <b>من:</b> {ride_data.get('pickup')}\n"
        f"🎯 <b>إلى:</b> {ride_data.get('dest')}\n"
        f"💰 <b>السعر:</b> {ride_data.get('price')}\n\n"
        f"<b>اضغط لقبول الطلب:</b>"
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="✅ قبول", callback_data=f"accept:{ride_id}")]])
    for g in groups:
        try: await bot.send_message(g["chat_id"], text, reply_markup=markup)
        except: pass

async def ride_is_waiting(ride_id):
    async with pool.acquire() as conn:
        status = await conn.fetchval("SELECT status FROM rides WHERE id=$1", ride_id)
    return status == "waiting"

@router.callback_query(F.data.startswith("accept:"))
async def on_accept(cb: CallbackQuery):
    ride_id = int(cb.data.split(":")[1])
    driver = cb.from_user
    async with pool.acquire() as conn:
        updated = await conn.execute("UPDATE rides SET driver_id=$1, status='assigned', accepted_at=NOW() WHERE id=$2 AND status='waiting'", driver.id, ride_id)
    if updated == "UPDATE 0": return await cb.answer("❌ الطلب لم يعد متاحاً.", show_alert=True)
    await cb.answer("✅ تم تعيينك للسفرة!")
    ride = await get_ride_full(ride_id)
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ إنهاء المشوار", callback_data=f"complete:{ride_id}"),
         InlineKeyboardButton(text="🚨 طوارئ", callback_data=f"sos:{ride_id}")],
        [InlineKeyboardButton(text="⭐ إضافة للسائقين المفضلين", callback_data=f"addfav:{driver.id}")]
    ])
    await send_safe(ride["customer_id"], f"🎉 <b>وجدنا لك سائقاً!</b>\n\n<b>الاسم:</b> {ride['drv_name']}\n<b>السيارة:</b> {ride['car_model']} ({ride['plate_number']})\n<b>التقييم:</b> {ride['rating_avg']:.1f}⭐", markup)
    await cb.message.edit_text(cb.message.text + f"\n\n✅ <b>تم قبول المشوار من قِبلك</b>")

@router.callback_query(F.data.startswith("complete:"))
async def complete_ride(cb: CallbackQuery):
    ride_id = int(cb.data.split(":")[1])
    async with pool.acquire() as conn:
        await conn.execute("UPDATE rides SET status='completed', completed_at=NOW() WHERE id=$1 AND driver_id=$2", ride_id, cb.from_user.id)
        ride = await get_ride_full(ride_id)
    if not ride: return await cb.answer("خطأ.")
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"⭐ {i}", callback_data=f"rate:{ride_id}:{ride['driver_id']}:{i}") for i in range(1,6)]
    ])
    await send_safe(ride["customer_id"], "🌟 <b>تم إنهاء المشوار.</b> كيف تقيم السائق؟", markup)
    await send_safe(ride["driver_id"], "🌟 <b>تم إنهاء المشوار.</b> كيف تقيم الراكب؟", InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"⭐ {i}", callback_data=f"rate:{ride_id}:{ride['customer_id']}:{i}") for i in range(1,6)]
    ]))
    await cb.message.answer("✅ تم إنهاء المشوار بنجاح.", reply_markup=main_menu(cb.from_user.id))

@router.callback_query(F.data.startswith("rate:"))
async def rate_user(cb: CallbackQuery):
    _, ride_id, ratee_id, stars = cb.data.split(":")
    async with pool.acquire() as conn:
        await conn.execute("INSERT INTO ratings (ride_id, rater_id, ratee_id, stars) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING", int(ride_id), cb.from_user.id, int(ratee_id), int(stars))
        avg = await conn.fetchval("SELECT AVG(stars) FROM ratings WHERE ratee_id=$1", int(ratee_id))
        await conn.execute("UPDATE drivers SET rating_avg=$1, rating_count = rating_count + 1 WHERE tg_id=$2", avg, int(ratee_id))
    await cb.answer("✅ شكراً لتقييمك!")
    await cb.message.delete()

@router.callback_query(F.data.startswith("addfav:"))
async def add_favorite(cb: CallbackQuery):
    driver_id = int(cb.data.split(":")[1])
    async with pool.acquire() as conn:
        await conn.execute("INSERT INTO favorites (customer_id, driver_id) VALUES ($1,$2) ON CONFLICT DO NOTHING", cb.from_user.id, driver_id)
    await cb.answer("⭐ تمت إضافته لمفضلتك!")
    await cb.message.answer("⭐ أُضيف السائق إلى قائمتك المفضلة.")

# ✅ تم إصلاح دالة show_fav - جلب full_name من users بدلاً من drivers
@router.message(F.text == "⭐ مفضلتي")
async def show_fav(msg: Message):
    async with pool.acquire() as conn:
        favs = await conn.fetch("""
            SELECT d.tg_id, u.full_name, d.car_model, d.rating_avg 
            FROM favorites f
            JOIN drivers d ON d.tg_id = f.driver_id
            JOIN users u ON u.tg_id = d.tg_id
            WHERE f.customer_id = $1
        """, msg.from_user.id)
    if not favs: return await msg.answer("ليس لديك سائقون مفضلون بعد.")
    text = "⭐ <b>سائقوك المفضلون:</b>\n\n" + "\n".join([f"- {d['full_name']} ({d['car_model']}) - {d['rating_avg']:.1f}⭐" for d in favs])
    await msg.answer(text)

@router.message(F.text == "🚨 طوارئ")
async def sos_btn(msg: Message, state: FSMContext):
    await state.set_state(SOSForm.details)
    await msg.answer("🆘 أرسل تفاصيل حالتك الطارئة:", reply_markup=ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="إلغاء")]], resize_keyboard=True
    ))

@router.message(SOSForm.details)
async def sos_details(msg: Message, state: FSMContext):
    if msg.text == "إلغاء": return await state.clear(), await msg.answer("تم الإلغاء.", reply_markup=main_menu(msg.from_user.id))
    for admin_id in ADMIN_IDS:
        await send_safe(admin_id, f"🚨 <b>بلاغ طوارئ!</b>\nمن: {msg.from_user.full_name} (@{msg.from_user.username})\nالرسالة: {msg.text}")
    await state.clear()
    await msg.answer("🚨 تم إرسال بلاغك للإدارة. سنتواصل معك فوراً.", reply_markup=main_menu(msg.from_user.id))

@router.message(Command("addgroup"))
async def add_group(msg: Message):
    if msg.from_user.id not in ADMIN_IDS: return
    parts = msg.text.split()
    if len(parts) < 3: return await msg.reply("الاستخدام: /addgroup <اسم_المدينة> <نوع_القروب>")
    city, gtype = parts[1], parts[2]
    async with pool.acquire() as conn:
        await conn.execute("INSERT INTO groups_config (city, type, chat_id) VALUES ($1,$2,$3)", city, gtype, msg.chat.id)
    await msg.reply(f"✅ تم تسجيل المجموعة كقروب '{gtype}' لمدينة '{city}'.")

@router.message(F.text == "📊 إحصائيات")
async def admin_stats(msg: Message):
    if msg.from_user.id not in ADMIN_IDS: return
    async with pool.acquire() as conn:
        users = await conn.fetchval("SELECT count(*) FROM users")
        drivers = await conn.fetchval("SELECT count(*) FROM drivers")
        rides = await conn.fetchval("SELECT count(*) FROM rides WHERE status='completed'")
    await msg.answer(f"👥 المستخدمون: {users}\n🚗 السائقون: {drivers}\n✅ المشاوير المكتملة: {rides}")

@router.message(F.text == "💎 VIP")
async def vip_info(msg: Message):
    await msg.answer("💎 <b>قريباً!</b> افتح اشتراك VIP لتحصل على أولوية في الطلبات وسائقين مفضلين.")

@router.message(F.text == "ℹ️ المساعدة")
async def help_cmd(msg: Message):
    await msg.answer("ℹ️ <b>المساعدة:</b>\n🚕 اطلب مشوارك بسهولة، حدد السعر، واستمتع بخدمة آمنة وسريعة.")

async def run_driver_bot():
    import driver_bot.main as driver_module
    driver_module.pool = pool
    from driver_bot.main import bot as driver_bot, dp as driver_dp
    print("🚀 بوت السائق يعمل الآن...")
    await driver_dp.start_polling(driver_bot)

async def main():
    await create_pool()
    print("🚀 بوت الراكب يعمل الآن...")
    await asyncio.gather(
        dp.start_polling(bot),
        run_driver_bot()
    )

if __name__ == "__main__":
    asyncio.run(main())
