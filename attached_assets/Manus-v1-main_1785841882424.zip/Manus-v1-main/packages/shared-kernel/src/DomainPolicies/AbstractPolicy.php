<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\DomainPolicies;

abstract class AbstractPolicy implements Policy
{
    abstract public function name(): string;

    abstract public function appliesTo(mixed $context): bool;

    abstract public function execute(mixed $context): mixed;
}
