<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Domain\Strategies;

interface MatchingStrategy
{
    /**
     * @param array<int,array<string,mixed>> $providers
     *
     * @return array<string,mixed>|null
     */
    public function select(array $providers): ?array;
}
