# Wasl Platform Shared Kernel

Version: 1.0.0
Status: DRAFT

=========================================================
MISSION
=========================================================

The Shared Kernel contains every concept shared across all Engines.

It must remain stable.

It must remain lightweight.

It must never contain business logic.

=========================================================
MODULES
=========================================================

Identity

Common

Contracts

Events

Commands

Exceptions

Value Objects

Entities

State Machine

Event Bus

Clock

Geo

Money

Collections

Validation

Security

Utilities

Serialization

Configuration

=========================================================
VALUE OBJECTS
=========================================================

UUID

SessionId

OrderId

CustomerId

ProviderId

BookingId

VehicleId

PaymentId

NotificationId

MessageId

Money

Currency

GeoPoint

Route

Distance

Duration

ETA

Timestamp

DateRange

PhoneNumber

Email

Language

Timezone

Rating

Score

Percentage

FeatureFlag

IPAddress

UserAgent

=========================================================
BASE CLASSES
=========================================================

AggregateRoot

Entity

ValueObject

DomainEvent

DomainCommand

DomainException

Repository

Specification

Policy

Factory

DomainService

=========================================================
INTERFACES
=========================================================

EventBus

CommandBus

Clock

Logger

Queue

Cache

Database

Transaction

NotificationGateway

LocationProvider

RouteProvider

PaymentGateway

=========================================================
STATE MACHINE
=========================================================

State

Transition

Guard

Action

StateMachine

TransitionResult

=========================================================
EVENT FOUNDATION
=========================================================

BaseEvent

IntegrationEvent

DomainEvent

InternalEvent

ExternalEvent

=========================================================
COMMAND FOUNDATION
=========================================================

BaseCommand

InternalCommand

ExternalCommand

=========================================================
SECURITY
=========================================================

Hasher

Encrypter

Signer

Token

Permission

Role

=========================================================
COLLECTIONS
=========================================================

EventCollection

CommandCollection

AggregateCollection

=========================================================
RULES
=========================================================

No Infrastructure Code.

No Database Access.

No Framework Dependency.

No HTTP Dependency.

No Telegram Dependency.

No Business Logic.

Everything Immutable by Default.

Backward Compatibility Required.

Semantic Versioning Required.

