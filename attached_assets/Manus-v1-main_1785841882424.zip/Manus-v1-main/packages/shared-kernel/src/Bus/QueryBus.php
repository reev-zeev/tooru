<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Bus;

interface QueryBus
{
    public function ask(object $query): mixed;
}
