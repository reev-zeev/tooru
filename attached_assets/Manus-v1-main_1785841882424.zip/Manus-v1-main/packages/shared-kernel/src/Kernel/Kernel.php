<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Kernel;

use Wasl\SharedKernel\Bootstrap\Application;
use Wasl\SharedKernel\DependencyInjection\Container;

final readonly class Kernel
{
    public function __construct(
        private Application $application,
    ) {
    }

    public function boot(): void
    {
        $this->application->boot();
    }

    public function container(): Container
    {
        return $this->application->container();
    }

    public function app(): Application
    {
        return $this->application;
    }
}
