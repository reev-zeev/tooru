<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Handlers;

use Wasl\SessionEngine\Commands\CreateSessionCommand;
use Wasl\SessionEngine\Contracts\SessionRepository;
use Wasl\SessionEngine\Contracts\SessionUnitOfWork;
use Wasl\SessionEngine\Session\ServiceSession;
use Wasl\SessionEngine\ValueObjects\SessionId;

final readonly class CreateSessionHandler
{
    public function __construct(
        private SessionRepository $repository,
        private SessionUnitOfWork $unitOfWork,
    ) {
    }

    public function __invoke(CreateSessionCommand $command): ServiceSession
    {
        $session = new ServiceSession(
            SessionId::generate(),
            $command->customerId(),
            $command->serviceType(),
        );

        $session->startSearching();

        $this->repository->save($session);

        $this->unitOfWork->register($session);

        $this->unitOfWork->commit();

        return $session;
    }
}
