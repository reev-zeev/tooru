<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Application\DTOs;

use Wasl\SessionEngine\Domain\Aggregates\ServiceSession;

final readonly class SessionDto
{
    public function __construct(
        public string $id,
        public string $state,
    ) {
    }

    public static function fromAggregate(ServiceSession $session): self
    {
        return new self(
            id: $session->id()->toString(),
            state: $session->state()->value,
        );
    }

    /**
     * @return array<string,string>
     */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'state' => $this->state,
        ];
    }
}
