<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Application\Commands;

final readonly class CreateSessionCommand
{
    public function __construct(
        public string $customerId,
        public string $serviceType,
    ) {
    }
}
