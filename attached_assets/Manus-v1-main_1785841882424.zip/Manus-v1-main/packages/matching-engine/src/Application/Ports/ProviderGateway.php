<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Application\Ports;

final readonly class ProviderCandidate
{
    public function __construct(
        public string $id,
        public float $rating,
        public float $distance,
    ) {
    }
}

interface ProviderGateway
{
    /**
     * @return list<ProviderCandidate>
     */
    public function availableProviders(): array;
}
