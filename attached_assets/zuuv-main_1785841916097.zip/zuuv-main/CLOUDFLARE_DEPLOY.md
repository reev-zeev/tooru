# 🚖 دليل تشغيل المنصة من الصفر

## ⚡ تشغيل سريع (5 دقائق)

### 1) النشر
- اضغط **Publish** أعلى يسار محرر Lovable
- سيُنشر الموقع على رابط مثل: `https://project--<id>.lovable.app`
- (اختياري) أضف نطاقك المخصص من Project Settings → Domains

### 2) إنشاء حساب المشرف
- افتح `/auth` على رابط الموقع المنشور
- اضغط **"أنشئ حساب جديد"** وأدخل بريد + كلمة مرور
- **أول حساب يدخل اللوحة يحصل تلقائياً على دور admin** عند الضغط على زر "منحي صلاحية المشرف" في الشاشة الترحيبية
- بعدها أي حساب جديد ما يقدر يصير admin إلا لو رقّاه أحد المشرفين يدوياً

### 3) تشغيل البوتات (السائق + الراكب)
1. ادخل **/admin/settings**
2. تأكد أن الـ **Base URL** هو رابط الموقع المنشور (وليس preview)
3. اضغط **"تسجيل Webhooks الآن"**
4. ستحصل على رسالة نجاح ✓ — البوتات الآن تستقبل الرسائل

> ⚠️ مهم: لا بد إنك تكون رفعت الـ TELEGRAM_DRIVER_BOT_TOKEN و TELEGRAM_RIDER_BOT_TOKEN كأسرار. (مرفوعة فعلياً في مشروعك ✓)

### 4) فحص البوتات
- افتح بوت السائق في تيليجرام → ابعث `/start`
- لازم يرد عليك ويبدأ سؤالك عن البيانات
- نفس الشيء لبوت الراكب
- أي طلب راكب يصلك في **/admin/rides** و**/admin/live**

---

## 🗺 ميزات اللوحة

| الصفحة | الوظيفة |
|--------|---------|
| `/admin/live` | خريطة Mapbox حية للسائقين والرحلات (تحدث لحظياً) |
| `/admin/rides` | جميع الرحلات + حالاتها |
| `/admin/drivers` | السائقون: تفعيل اشتراك / إيقاف / حذف / تعليم |
| `/admin/broadcast` | بث رسائل جماعية لتيليجرام (حسب المدينة والجمهور) |
| `/admin/pricing` | تعديل السعر الأساسي، per_km، Surge، الذروة، الطقس، الأعياد |
| `/admin/suspicious` | المشبوهون: إزالة العلامة / إيقاف فوري |
| `/admin/ratings` | سجل تقييمات AI لكل رحلة |
| `/admin/cities` | إدارة مدن المملكة + قروبات تيليجرام لكل مدينة |
| `/admin/emergencies` | بلاغات الطوارئ |
| `/admin/support` | تذاكر الدعم + الرد على المستخدم عبر البوت |
| `/admin/settings` | تسجيل Webhooks + حدود التعليم التلقائي |

---

## 🧠 الذكاء الجبار

- **خرائط Mapbox** للمسافات والأوقات الحقيقية مع traffic + الجيوكودينج العربي
- **فرز جغرافي صارم** — لا يخلط جدة بمكة أبداً (radius_km لكل مدينة)
- **كشف ذروة ذكي** — يتعلم من سجل الرحلات (cron كل ساعة) ويتوقع الذروة قبل 30 دقيقة
- **تنبيهات استباقية** للسائقين قبل الذروة
- **تسعير ديناميكي** — Surge حسب الذروة + الطقس + الأعياد
- **تقويم هجري + أعياد** — رمضان، الإفطار، السحور، اليوم الوطني، التأسيس، عيدا الفطر والأضحى، الحج
- **AI Gateway** — تقييمات تلقائية لكل رحلة + كشف المشبوهين
- **نظام طوارئ** — تنبيه فوري لمجموعة الدعم
- **قروبات المدن** — أي طلب لا يأخذه مشترك يُرسل تلقائياً لقروب تيليجرام تابع للمدينة

---

## 🚀 النشر على Cloudflare (اختياري — للنشر المستقل)

### المتطلبات
```bash
npm install -g wrangler
wrangler login
```

### رفع الأسرار
```bash
wrangler secret put SUPABASE_URL
wrangler secret put SUPABASE_SERVICE_ROLE_KEY
wrangler secret put SUPABASE_PUBLISHABLE_KEY
wrangler secret put TELEGRAM_DRIVER_BOT_TOKEN
wrangler secret put TELEGRAM_RIDER_BOT_TOKEN
wrangler secret put TELEGRAM_SUPPORT_CHAT_ID
wrangler secret put LOVABLE_API_KEY
wrangler secret put MAPBOX_ACCESS_TOKEN
```

### البناء والنشر
```bash
bun install
bun run build
wrangler deploy
```

### بعد النشر على Cloudflare
1. حدّث جدولة المهام في قاعدة البيانات (`pg_cron`) لتشير إلى نطاقك
2. من **/admin/settings** أعد تسجيل Webhooks باستخدام نطاقك الجديد

---

## ❓ أسئلة شائعة

**س: ضغطت "تسجيل Webhooks" لكن البوت ما يرد؟**
- تأكد إن Base URL هو الرابط المنشور النهائي (مش `id-preview--...`)
- افتح [@BotFather](https://t.me/BotFather) → `/mybots` → اختر البوت → Bot Settings → تأكد إن "Group Privacy" مناسب
- جرّب يدوياً: `https://api.telegram.org/bot<TOKEN>/getWebhookInfo` ولاحظ `last_error_message`

**س: كيف أضيف admin ثاني؟**
- يسجّل الشخص حساب من `/auth`
- ثم من قاعدة البيانات: أضف صف في `user_roles` بقيمة `role='admin'` و `user_id` = آيدي الحساب الجديد

**س: كيف أضيف مدينة جديدة؟**
- `/admin/cities` → زر "+ إضافة مدينة" → أدخل الإحداثيات + chat_id القروب

**س: قروب تيليجرام للمدينة كيف أحطّه؟**
1. أنشئ قروب
2. أضف بوت السائق وأعطه صلاحية مشرف
3. ابعث رسالة في القروب ثم افتح `https://api.telegram.org/bot<DRIVER_TOKEN>/getUpdates` وانسخ `chat.id` (يبدأ بـ `-100...`)
4. الصق `chat_id` في صفحة المدينة بـ /admin/cities

**س: ليش أشوف "Forbidden: admin only"؟**
- حسابك ما يملك دور admin. اضغط زر "منحي صلاحية المشرف" في الشاشة الترحيبية (يعمل فقط لو ما فيه أي admin مسجّل).
