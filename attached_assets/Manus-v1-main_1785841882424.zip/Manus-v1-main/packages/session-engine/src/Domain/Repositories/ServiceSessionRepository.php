<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\Repositories;

use Wasl\SessionEngine\Domain\Aggregates\ServiceSession;
use Wasl\SharedKernel\ValueObjects\UUID;

interface ServiceSessionRepository
{
    public function save(ServiceSession $session): void;

    public function findById(UUID $id): ?ServiceSession;

    public function exists(UUID $id): bool;

    public function delete(UUID $id): void;
}
