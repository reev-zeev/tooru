<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Projection;

final class SessionView
{
    public function __construct(
        public readonly string $id,
        public readonly string $state,
        public readonly string $updatedAt,
    ) {
    }
}
