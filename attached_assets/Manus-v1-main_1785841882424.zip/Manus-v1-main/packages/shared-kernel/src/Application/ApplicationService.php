<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Application;

/**
 * Marker interface for Application Services.
 *
 * Application Services orchestrate use cases,
 * coordinate aggregates, repositories,
 * domain services and infrastructure.
 *
 * They DO NOT contain business rules.
 */
interface ApplicationService
{
}
