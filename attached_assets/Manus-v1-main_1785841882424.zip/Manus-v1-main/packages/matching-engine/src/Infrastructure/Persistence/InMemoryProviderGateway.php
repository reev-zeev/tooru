<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Infrastructure\Persistence;

use Wasl\MatchingEngine\Application\Ports\ProviderCandidate;
use Wasl\MatchingEngine\Application\Ports\ProviderGateway;

final class InMemoryProviderGateway implements ProviderGateway
{
    public function availableProviders(): array
    {
        return [
            new ProviderCandidate(
                id: 'provider-001',
                rating: 4.9,
                distance: 1.8,
            ),
            new ProviderCandidate(
                id: 'provider-002',
                rating: 4.7,
                distance: 2.4,
            ),
        ];
    }
}
