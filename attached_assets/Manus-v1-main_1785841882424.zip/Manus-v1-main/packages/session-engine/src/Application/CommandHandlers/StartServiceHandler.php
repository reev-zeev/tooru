<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Application\CommandHandlers;

use Wasl\SessionEngine\Application\Commands\StartServiceCommand;
use Wasl\SessionEngine\Domain\Repositories\ServiceSessionRepository;
use Wasl\SharedKernel\Exceptions\NotFoundException;

final readonly class StartServiceHandler
{
    public function __construct(
        private ServiceSessionRepository $repository,
    ) {
    }

    public function handle(StartServiceCommand $command): void
    {
        $session = $this->repository->findById($command->sessionId);

        if ($session === null) {
            throw new NotFoundException('Session not found.');
        }

        $session->startService();

        $this->repository->save($session);
    }
}
