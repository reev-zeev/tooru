<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Application\CommandHandlers;

use Wasl\SessionEngine\Application\Commands\ProviderArrivedCommand;
use Wasl\SessionEngine\Domain\Repositories\ServiceSessionRepository;
use Wasl\SharedKernel\Exceptions\NotFoundException;

final readonly class ProviderArrivedHandler
{
    public function __construct(
        private ServiceSessionRepository $repository,
    ) {
    }

    public function handle(ProviderArrivedCommand $command): void
    {
        $session = $this->repository->findById($command->sessionId);

        if ($session === null) {
            throw new NotFoundException('Session not found.');
        }

        $session->providerArrived();

        $this->repository->save($session);
    }
}
