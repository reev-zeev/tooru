// Emergency handler — uses driver's latest known location, falls back to pickup.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { sendMessage } from "@/lib/telegram/api.server";

export async function triggerEmergency(rideId: string) {
  const { data: ride } = await supabaseAdmin
    .from("rides")
    .select("*, riders(*), drivers(*)")
    .eq("id", rideId)
    .maybeSingle();
  if (!ride) return;

  const rider: any = ride.riders;
  const driver: any = ride.drivers;

  // Prefer driver's latest GPS location over the static pickup point.
  let lat = ride.pickup_lat;
  let lng = ride.pickup_lng;
  let locationLabel = "موقع الانطلاق (لا يوجد موقع حديث)";

  if (driver?.id) {
    const { data: loc } = await supabaseAdmin
      .from("driver_locations")
      .select("latitude, longitude, updated_at")
      .eq("driver_id", driver.id)
      .maybeSingle();
    if (loc) {
      lat = loc.latitude;
      lng = loc.longitude;
      const age = Math.round((Date.now() - new Date(loc.updated_at).getTime()) / 60000);
      locationLabel = `موقع السائق الحالي (منذ ${age} دقيقة)`;
    }
  }

  await supabaseAdmin.from("emergency_logs").insert({
    ride_id: rideId,
    rider_id: ride.rider_id,
    driver_id: ride.driver_id,
    location_lat: lat,
    location_lng: lng,
  });

  const supportChatId = process.env.TELEGRAM_SUPPORT_CHAT_ID;
  if (!supportChatId) {
    console.warn("[emergency] TELEGRAM_SUPPORT_CHAT_ID not set");
    return;
  }

  const mapsUrl = `https://maps.google.com/?q=${lat},${lng}`;
  const text = [
    "🚨 <b>تنبيه طوارئ!</b>",
    `🆔 الرحلة: <code>${rideId}</code>`,
    `🧍 الراكب: ${rider?.name ?? "—"} | ${rider?.phone ?? "—"} | TG:${rider?.telegram_id}`,
    `🚗 السائق: ${driver?.name ?? "—"} | ${driver?.phone ?? "—"} | ${driver?.car_type ?? ""} ${driver?.car_plate ?? ""}`,
    `📍 الموقع (${locationLabel}): ${mapsUrl}`,
  ].join("\n");

  try {
    await sendMessage("driver", supportChatId, text);
  } catch (e) {
    console.error("[emergency] failed to notify support", e);
  }
}
