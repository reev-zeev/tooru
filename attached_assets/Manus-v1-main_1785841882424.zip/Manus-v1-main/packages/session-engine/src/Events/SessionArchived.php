<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Events;

final class SessionArchived extends AbstractSessionEvent
{
    public function eventName(): string
    {
        return 'session.archived';
    }
}
