<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Support;

trait JsonSerializableTrait
{
    public function toJson(int $flags = JSON_THROW_ON_ERROR): string
    {
        return json_encode(
            $this->toArray(),
            $flags
        );
    }
}
