<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Serialization;

interface Serializable
{
    public function toArray(): array;

    public function toJson(int $flags = JSON_THROW_ON_ERROR): string;
}
