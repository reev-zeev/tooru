<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Locking;

interface LockManager
{
    public function acquire(string $key, int $ttl = 30): bool;

    public function release(string $key): void;

    public function isLocked(string $key): bool;
}
