# Wasl Platform Sequence Diagrams

Version: 1.0.0
Status: DRAFT

=========================================================
SEQUENCE DIAGRAM CATALOG
=========================================================

The following scenarios MUST have official sequence diagrams.

Every sequence diagram represents the source of truth.

=========================================================
CUSTOMER FLOWS
=========================================================

SEQ-001 Customer Registration

SEQ-002 Customer Login

SEQ-003 Request Taxi

SEQ-004 Request Delivery

SEQ-005 Scheduled Booking

SEQ-006 Recurring Booking

SEQ-007 Cancel Before Match

SEQ-008 Cancel After Match

SEQ-009 Change Destination

SEQ-010 Update Pickup

SEQ-011 Save Favorite Location

SEQ-012 Chat With Provider

SEQ-013 Rate Provider

=========================================================
PROVIDER FLOWS
=========================================================

SEQ-020 Provider Registration

SEQ-021 Verification

SEQ-022 Go Online

SEQ-023 Go Offline

SEQ-024 Receive Order

SEQ-025 Accept Order

SEQ-026 Reject Order

SEQ-027 Arrive Pickup

SEQ-028 Start Service

SEQ-029 Complete Service

SEQ-030 Cancel Service

SEQ-031 Provider Disconnect

SEQ-032 Provider Recovery

=========================================================
DISPATCH FLOWS
=========================================================

SEQ-040 Start Dispatch

SEQ-041 Candidate Selection

SEQ-042 Atomic Lock

SEQ-043 Multiple Accept Protection

SEQ-044 Dispatch Retry

SEQ-045 Group Fallback

SEQ-046 Dispatch Timeout

=========================================================
SESSION FLOWS
=========================================================

SEQ-050 Session Creation

SEQ-051 Session Recovery

SEQ-052 Session Pause

SEQ-053 Session Resume

SEQ-054 Session Completion

SEQ-055 Session Archive

=========================================================
PAYMENT FLOWS
=========================================================

SEQ-060 Create Payment

SEQ-061 Authorize Payment

SEQ-062 Capture Payment

SEQ-063 Refund Payment

SEQ-064 Payment Failure

=========================================================
NOTIFICATION FLOWS
=========================================================

SEQ-070 Queue Notification

SEQ-071 Telegram Delivery

SEQ-072 Retry Notification

SEQ-073 Dead Letter Queue

=========================================================
RECOVERY FLOWS
=========================================================

SEQ-080 Redis Failure

SEQ-081 Database Recovery

SEQ-082 Queue Recovery

SEQ-083 WebSocket Recovery

SEQ-084 Polling Fallback

SEQ-085 Server Restart

=========================================================
ADMIN FLOWS
=========================================================

SEQ-090 Suspend Provider

SEQ-091 Suspend Customer

SEQ-092 Manual Dispatch

SEQ-093 Force Close Session

SEQ-094 Broadcast Notification

=========================================================
SECURITY FLOWS
=========================================================

SEQ-100 Authentication

SEQ-101 Authorization

SEQ-102 Rate Limiting

SEQ-103 Replay Attack Prevention

SEQ-104 Idempotency Protection

SEQ-105 Fraud Detection

=========================================================
RULES
=========================================================

Every business process MUST have a sequence diagram.

Every sequence diagram references:

- Events
- Commands
- APIs
- State Machine
- Failure Cases

No feature is implemented before its sequence diagram is approved.

