<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Infrastructure\Projection;

use Wasl\SessionEngine\Domain\Events\ProviderAccepted;
use Wasl\SessionEngine\Domain\Events\ProviderMatched;
use Wasl\SessionEngine\Domain\Events\SessionCompleted;
use Wasl\SessionEngine\Domain\Events\SessionCreated;
use Wasl\SessionEngine\Projection\SessionProjection;
use Wasl\SharedKernel\Bootstrap\ServiceProvider;
use Wasl\SharedKernel\DependencyInjection\Container;
use Wasl\SharedKernel\DomainEvents\DomainEventPublisher;

final class SessionProjectionProvider implements ServiceProvider
{
    public function register(Container $container): void
    {
        $container->singleton(
            SessionProjection::class,
            fn () => new SessionProjection()
        );

        $container->singleton(
            SessionProjectionSubscriber::class,
            fn (Container $c) => new SessionProjectionSubscriber(
                $c->get(SessionProjection::class)
            )
        );
    }

    public function boot(Container $container): void
    {
        /** @var DomainEventPublisher $publisher */
        $publisher = $container->get(DomainEventPublisher::class);

        /** @var SessionProjectionSubscriber $subscriber */
        $subscriber = $container->get(SessionProjectionSubscriber::class);

        $publisher->subscribe(SessionCreated::class, [$subscriber, 'onSessionCreated']);
        $publisher->subscribe(ProviderMatched::class, [$subscriber, 'onProviderMatched']);
        $publisher->subscribe(ProviderAccepted::class, [$subscriber, 'onProviderAccepted']);
        $publisher->subscribe(SessionCompleted::class, [$subscriber, 'onSessionCompleted']);
    }
}
