<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Tests\Integration;

use PHPUnit\Framework\TestCase;
use Wasl\SessionEngine\Application\CommandHandlers\CreateSessionHandler;
use Wasl\SessionEngine\Application\Commands\CreateSessionCommand;
use Wasl\SessionEngine\Application\Queries\GetActiveSessionQuery;
use Wasl\SessionEngine\Application\SessionApplicationService;
use Wasl\SessionEngine\Domain\Factories\ServiceSessionFactory;
use Wasl\SessionEngine\Domain\StateMachine\SessionStateMachine;
use Wasl\SessionEngine\Infrastructure\Persistence\InMemorySessionRepository;
use Wasl\SharedKernel\Identity\UuidIdentityGenerator;

final class SessionApplicationServiceTest extends TestCase
{
    public function test_create_and_fetch_session(): void
    {
        $repository = new InMemorySessionRepository();

        $factory = new ServiceSessionFactory(
            new UuidIdentityGenerator(),
            new SessionStateMachine(),
        );

        $handler = new CreateSessionHandler(
            $factory,
            $repository,
        );

        $service = new SessionApplicationService(
            $handler,
            $repository,
        );

        $dto = $service->create(
            new CreateSessionCommand(
                customerId: 'customer-1',
                serviceType: 'taxi',
            )
        );

        self::assertSame('searching', $dto->state);

        $loaded = $service->get(
            new GetActiveSessionQuery(
                sessionId: $repository->findById(
                    \Wasl\SharedKernel\ValueObjects\UUID::fromString($dto->id)
                )->id()
            )
        );

        self::assertNotNull($loaded);
        self::assertSame($dto->id, $loaded->id);
        self::assertSame('searching', $loaded->state);
    }
}
