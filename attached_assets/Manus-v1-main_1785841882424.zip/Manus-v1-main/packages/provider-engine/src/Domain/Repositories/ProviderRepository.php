<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Domain\Repositories;

use Wasl\ProviderEngine\Domain\Aggregates\Provider;
use Wasl\SharedKernel\ValueObjects\UUID;

interface ProviderRepository
{
    public function save(Provider $provider): void;

    public function findById(UUID $id): ?Provider;

    /**
     * @return list<Provider>
     */
    public function findAvailable(): array;
}
