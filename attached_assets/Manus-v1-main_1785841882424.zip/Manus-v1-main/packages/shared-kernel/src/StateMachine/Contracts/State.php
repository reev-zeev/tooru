<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\StateMachine\Contracts;

interface State
{
    public function name(): string;

    public function isFinal(): bool;
}
