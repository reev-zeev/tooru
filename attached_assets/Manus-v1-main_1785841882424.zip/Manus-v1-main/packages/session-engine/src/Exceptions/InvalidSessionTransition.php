<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Exceptions;

use Wasl\SharedKernel\Exceptions\DomainException;

final class InvalidSessionTransition extends DomainException
{
}
