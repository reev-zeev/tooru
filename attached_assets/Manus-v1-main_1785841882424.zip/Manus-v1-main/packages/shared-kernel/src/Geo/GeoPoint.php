<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Geo;

use InvalidArgumentException;

final readonly class GeoPoint
{
    public function __construct(
        private float $latitude,
        private float $longitude
    ) {
        if ($latitude < -90 || $latitude > 90) {
            throw new InvalidArgumentException('Invalid latitude.');
        }

        if ($longitude < -180 || $longitude > 180) {
            throw new InvalidArgumentException('Invalid longitude.');
        }
    }

    public function latitude(): float
    {
        return $this->latitude;
    }

    public function longitude(): float
    {
        return $this->longitude;
    }

    public function equals(self $other): bool
    {
        return $this->latitude === $other->latitude()
            && $this->longitude === $other->longitude();
    }

    public function toArray(): array
    {
        return [
            'lat' => $this->latitude,
            'lng' => $this->longitude,
        ];
    }

    public function __toString(): string
    {
        return $this->latitude . ',' . $this->longitude;
    }
}
