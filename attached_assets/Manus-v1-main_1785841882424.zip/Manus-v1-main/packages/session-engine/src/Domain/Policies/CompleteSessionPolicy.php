<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\Policies;

use Wasl\SessionEngine\Domain\Aggregates\ServiceSession;
use Wasl\SessionEngine\Domain\Specifications\SessionCanBeCompletedSpecification;
use Wasl\SharedKernel\DomainPolicies\AbstractPolicy;

final class CompleteSessionPolicy extends AbstractPolicy
{
    public function name(): string
    {
        return 'session.complete';
    }

    public function appliesTo(mixed $context): bool
    {
        return $context instanceof ServiceSession;
    }

    public function execute(mixed $context): bool
    {
        return (new SessionCanBeCompletedSpecification())
            ->isSatisfiedBy($context);
    }
}
