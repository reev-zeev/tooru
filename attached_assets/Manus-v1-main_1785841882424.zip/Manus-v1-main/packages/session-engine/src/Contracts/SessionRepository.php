<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Contracts;

use Wasl\SessionEngine\Session\ServiceSession;
use Wasl\SessionEngine\ValueObjects\SessionId;

interface SessionRepository
{
    public function save(ServiceSession $session): void;

    public function find(SessionId $id): ?ServiceSession;
}
