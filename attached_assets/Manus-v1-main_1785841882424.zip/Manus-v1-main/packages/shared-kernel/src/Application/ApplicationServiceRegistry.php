<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Application;

final class ApplicationServiceRegistry
{
    /**
     * @var array<string, ApplicationService>
     */
    private array $services = [];

    public function register(
        string $name,
        ApplicationService $service
    ): void {
        $this->services[$name] = $service;
    }

    public function has(string $name): bool
    {
        return isset($this->services[$name]);
    }

    public function get(string $name): ApplicationService
    {
        return $this->services[$name];
    }

    /**
     * @return array<string, ApplicationService>
     */
    public function all(): array
    {
        return $this->services;
    }
}
