<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Configuration;

interface Configuration
{
    public function get(string $key, mixed $default = null): mixed;

    public function has(string $key): bool;
}
