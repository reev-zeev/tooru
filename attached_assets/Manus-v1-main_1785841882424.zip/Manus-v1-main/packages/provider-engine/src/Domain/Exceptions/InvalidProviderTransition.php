<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Domain\Exceptions;

use Wasl\ProviderEngine\Domain\States\ProviderState;
use Wasl\SharedKernel\Exceptions\DomainException;

final class InvalidProviderTransition extends DomainException
{
    public static function from(
        ProviderState $from,
        ProviderState $to,
    ): self {
        return new self(
            sprintf(
                'Invalid provider transition from [%s] to [%s].',
                $from->value,
                $to->value,
            )
        );
    }
}
