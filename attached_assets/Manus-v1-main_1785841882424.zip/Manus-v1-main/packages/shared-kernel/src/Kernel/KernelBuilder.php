<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Kernel;

use Wasl\SharedKernel\Bootstrap\Application;
use Wasl\SharedKernel\Bootstrap\ServiceProvider;
use Wasl\SharedKernel\DependencyInjection\Container;

final class KernelBuilder
{
    /**
     * @var ServiceProvider[]
     */
    private array $providers = [];

    public function __construct(
        private readonly Container $container,
    ) {
    }

    public function register(ServiceProvider $provider): self
    {
        $this->providers[] = $provider;

        return $this;
    }

    public function build(): Kernel
    {
        $application = new Application($this->container);

        foreach ($this->providers as $provider) {
            $application->register($provider);
        }

        return new Kernel($application);
    }
}
