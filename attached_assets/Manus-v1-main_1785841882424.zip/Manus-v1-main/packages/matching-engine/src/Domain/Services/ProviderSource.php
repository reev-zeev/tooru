<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Domain\Services;

interface ProviderSource
{
    /**
     * @return array<int,array<string,mixed>>
     */
    public function availableProviders(): array;
}
