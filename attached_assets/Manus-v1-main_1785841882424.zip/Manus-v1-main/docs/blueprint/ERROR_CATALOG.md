# Wasl Platform Error Catalog

Version: 1.0.0
Status: DRAFT

=========================================================
ERROR PRINCIPLES
=========================================================

Every error has:

- Error Code
- HTTP Status
- Message
- Category
- Recoverable
- Retryable
- Logged
- Audited

Errors are immutable.

Errors never expose internal implementation.

Every error is traceable.

=========================================================
ERROR CATEGORIES
=========================================================

VALIDATION

AUTHENTICATION

AUTHORIZATION

BUSINESS

SESSION

DISPATCH

PAYMENT

NOTIFICATION

CHAT

LOCATION

SYSTEM

DATABASE

CACHE

QUEUE

NETWORK

SECURITY

UNKNOWN

=========================================================
VALIDATION ERRORS
=========================================================

VAL-001 Invalid Request

VAL-002 Missing Field

VAL-003 Invalid Format

VAL-004 Invalid Location

VAL-005 Invalid State

VAL-006 Invalid Payload

=========================================================
AUTH ERRORS
=========================================================

AUTH-001 Unauthorized

AUTH-002 Invalid Token

AUTH-003 Token Expired

AUTH-004 Permission Denied

AUTH-005 Account Suspended

=========================================================
CUSTOMER ERRORS
=========================================================

CUS-001 Customer Not Found

CUS-002 Customer Blocked

CUS-003 Customer Busy

CUS-004 Too Many Requests

CUS-005 Cancellation Limit Reached

=========================================================
PROVIDER ERRORS
=========================================================

PRO-001 Provider Offline

PRO-002 Provider Busy

PRO-003 Provider Suspended

PRO-004 Provider Already Assigned

PRO-005 Provider Not Verified

=========================================================
ORDER ERRORS
=========================================================

ORD-001 Order Not Found

ORD-002 Order Closed

ORD-003 Order Already Accepted

ORD-004 Order Expired

ORD-005 Order Already Cancelled

=========================================================
SESSION ERRORS
=========================================================

SES-001 Session Not Found

SES-002 Invalid Transition

SES-003 Session Closed

SES-004 Session Archived

SES-005 Session Already Exists

=========================================================
DISPATCH ERRORS
=========================================================

DSP-001 No Provider Found

DSP-002 Dispatch Timeout

DSP-003 Candidate Rejected

DSP-004 Dispatch Locked

=========================================================
PAYMENT ERRORS
=========================================================

PAY-001 Payment Failed

PAY-002 Already Paid

PAY-003 Payment Cancelled

PAY-004 Refund Failed

=========================================================
LOCATION ERRORS
=========================================================

LOC-001 Invalid GPS

LOC-002 GPS Timeout

LOC-003 GPS Spoof Detected

LOC-004 Route Not Available

=========================================================
CHAT ERRORS
=========================================================

CHAT-001 Chat Closed

CHAT-002 Message Too Large

CHAT-003 Delivery Failed

=========================================================
NOTIFICATION ERRORS
=========================================================

NOT-001 Send Failed

NOT-002 Queue Overflow

NOT-003 Notification Expired

=========================================================
SYSTEM ERRORS
=========================================================

SYS-001 Database Offline

SYS-002 Redis Offline

SYS-003 Queue Offline

SYS-004 WebSocket Offline

SYS-005 Internal Error

SYS-006 Maintenance Mode

=========================================================
SECURITY ERRORS
=========================================================

SEC-001 Invalid Signature

SEC-002 Replay Attack

SEC-003 Rate Limit Exceeded

SEC-004 Suspicious Activity

=========================================================
ERROR RULES
=========================================================

Errors are versioned.

Errors are documented.

Errors are localized.

Errors are logged.

Errors are auditable.

Errors never expose stack traces.

Every error has a unique code.

