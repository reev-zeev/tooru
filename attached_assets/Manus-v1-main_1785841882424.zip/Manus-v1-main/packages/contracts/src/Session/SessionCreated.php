<?php

declare(strict_types=1);

namespace Wasl\Contracts\Session;

use DateTimeImmutable;
use Wasl\SharedKernel\Contracts\Events\DomainEvent;
use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class SessionCreated implements DomainEvent
{
    public function __construct(
        private UUID $sessionId,
        private UUID $eventId,
        private DateTimeImmutable $occurredAt,
        private array $payload = [],
    ) {
    }

    public function eventId(): UUID
    {
        return $this->eventId;
    }

    public function aggregateId(): UUID
    {
        return $this->sessionId;
    }

    public function eventName(): string
    {
        return 'session.created';
    }

    public function occurredAt(): DateTimeImmutable
    {
        return $this->occurredAt;
    }

    public function payload(): array
    {
        return $this->payload;
    }
}
