<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Idempotency;

interface IdempotencyStore
{
    public function exists(string $key): bool;

    public function store(string $key, mixed $result = null): void;

    public function result(string $key): mixed;

    public function forget(string $key): void;
}
