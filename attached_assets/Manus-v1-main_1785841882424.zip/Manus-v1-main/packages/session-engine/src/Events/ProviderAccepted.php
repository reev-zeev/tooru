<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Events;

use Wasl\SessionEngine\ValueObjects\ProviderId;

final class ProviderAccepted extends AbstractSessionEvent
{
    public function __construct(
        protected \Wasl\SessionEngine\ValueObjects\SessionId $sessionId,
        private readonly ProviderId $providerId
    ) {
        parent::__construct($sessionId);
    }

    public function eventName(): string
    {
        return 'provider.accepted';
    }

    public function payload(): array
    {
        return [
            'session_id' => (string) $this->sessionId,
            'provider_id' => (string) $this->providerId,
        ];
    }
}
