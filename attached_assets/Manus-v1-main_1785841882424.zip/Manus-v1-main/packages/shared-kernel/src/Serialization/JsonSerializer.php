<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Serialization;

use JsonException;
use RuntimeException;

final class JsonSerializer implements Serializer
{
    public function serialize(mixed $value): string
    {
        try {
            return json_encode(
                $value,
                JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            );
        } catch (JsonException $e) {
            throw new RuntimeException(
                'Unable to serialize payload.',
                previous: $e
            );
        }
    }

    public function deserialize(string $payload, string $class): mixed
    {
        try {
            return json_decode(
                $payload,
                true,
                512,
                JSON_THROW_ON_ERROR
            );
        } catch (JsonException $e) {
            throw new RuntimeException(
                'Unable to deserialize payload.',
                previous: $e
            );
        }
    }
}
