<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\States;

use Wasl\SharedKernel\StateMachine\Contracts\State;

enum SessionState: string implements State
{
    case Created = 'created';
    case Searching = 'searching';
    case Matched = 'matched';
    case ProviderAccepted = 'provider_accepted';
    case ProviderEnRoute = 'provider_en_route';
    case ProviderArrived = 'provider_arrived';
    case InService = 'in_service';
    case Completed = 'completed';
    case Cancelled = 'cancelled';
    case Archived = 'archived';

    public function name(): string
    {
        return $this->value;
    }

    public function isFinal(): bool
    {
        return match ($this) {
            self::Completed,
            self::Cancelled,
            self::Archived => true,
            default => false,
        };
    }
}
