<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Clock;

use Wasl\SharedKernel\ValueObjects\Timestamp;

final readonly class SystemClock implements Clock
{
    public function now(): Timestamp
    {
        return Timestamp::now();
    }
}
