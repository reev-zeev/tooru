<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Infrastructure\Bus;

use Wasl\MatchingEngine\Domain\Events\ProviderMatched;
use Wasl\SharedKernel\Bootstrap\ServiceProvider;
use Wasl\SharedKernel\DependencyInjection\Container;
use Wasl\SharedKernel\DomainEvents\DomainEventPublisher;

final class SessionEventSubscriberProvider implements ServiceProvider
{
    public function register(Container $container): void
    {
        $container->singleton(
            ProviderMatchedSubscriber::class,
            fn(Container $c) => new ProviderMatchedSubscriber(
                $c->get(\Wasl\SessionEngine\Application\CommandHandlers\MatchProviderHandler::class)
            )
        );
    }

    public function boot(Container $container): void
    {
        /** @var DomainEventPublisher $publisher */
        $publisher = $container->get(DomainEventPublisher::class);

        $publisher->subscribe(
            ProviderMatched::class,
            $container->get(ProviderMatchedSubscriber::class)
        );
    }
}
