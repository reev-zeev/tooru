<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Tests\Unit;

use PHPUnit\Framework\TestCase;
use Wasl\SessionEngine\Domain\Exceptions\InvalidSessionTransition;
use Wasl\SessionEngine\Domain\StateMachine\SessionStateMachine;
use Wasl\SessionEngine\Domain\States\SessionState;

final class SessionStateMachineTest extends TestCase
{
    public function test_valid_transition(): void
    {
        $machine = new SessionStateMachine();

        self::assertSame(
            SessionState::Searching,
            $machine->transition(
                SessionState::Created,
                SessionState::Searching
            )
        );
    }

    public function test_invalid_transition_throws_exception(): void
    {
        $this->expectException(InvalidSessionTransition::class);

        (new SessionStateMachine())->transition(
            SessionState::Created,
            SessionState::Completed
        );
    }
}
