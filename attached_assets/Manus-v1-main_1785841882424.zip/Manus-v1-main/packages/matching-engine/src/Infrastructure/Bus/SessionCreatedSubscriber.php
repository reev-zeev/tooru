<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Infrastructure\Bus;

use Wasl\MatchingEngine\Application\CommandHandlers\StartMatchingHandler;
use Wasl\MatchingEngine\Application\Commands\StartMatchingCommand;
use Wasl\SessionEngine\Domain\Events\SessionCreated;

final readonly class SessionCreatedSubscriber
{
    public function __construct(
        private StartMatchingHandler $handler,
    ) {
    }

    public function __invoke(SessionCreated $event): void
    {
        $this->handler->handle(
            new StartMatchingCommand(
                sessionId: $event->aggregateId(),
            )
        );
    }
}
