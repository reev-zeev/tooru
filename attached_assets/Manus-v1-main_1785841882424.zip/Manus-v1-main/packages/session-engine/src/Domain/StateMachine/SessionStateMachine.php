<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\StateMachine;

use Wasl\SessionEngine\Domain\Exceptions\InvalidSessionTransition;
use Wasl\SessionEngine\Domain\States\SessionState;

final class SessionStateMachine
{
    public function transition(
        SessionState $current,
        SessionState $next,
    ): SessionState {
        if (!$current->canTransitionTo($next)) {
            throw InvalidSessionTransition::from(
                $current,
                $next,
            );
        }

        return $next;
    }

    public function canTransition(
        SessionState $current,
        SessionState $next,
    ): bool {
        return $current->canTransitionTo($next);
    }

    public function isFinal(SessionState $state): bool
    {
        return $state->isFinal();
    }
}
