<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Interfaces;

use Wasl\SharedKernel\ValueObjects\UUID;

interface UuidGeneratorInterface
{
    public function generate(): UUID;
}
