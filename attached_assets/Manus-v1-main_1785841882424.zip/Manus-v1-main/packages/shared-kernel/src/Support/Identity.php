<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Support;

use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class Identity
{
    public function __construct(
        private UUID $uuid
    ) {
    }

    public static function new(): self
    {
        return new self(UUID::generate());
    }

    public function uuid(): UUID
    {
        return $this->uuid;
    }

    public function __toString(): string
    {
        return (string) $this->uuid;
    }
}
