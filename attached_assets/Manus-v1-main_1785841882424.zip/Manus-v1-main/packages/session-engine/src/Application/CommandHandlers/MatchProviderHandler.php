<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Application\CommandHandlers;

use Wasl\SessionEngine\Application\Commands\MatchProviderCommand;
use Wasl\SessionEngine\Domain\Repositories\ServiceSessionRepository;
use Wasl\SharedKernel\Exceptions\NotFoundException;

final readonly class MatchProviderHandler
{
    public function __construct(
        private ServiceSessionRepository $repository,
    ) {
    }

    public function handle(MatchProviderCommand $command): void
    {
        $session = $this->repository->findById($command->sessionId);

        if ($session === null) {
            throw new NotFoundException('Session not found.');
        }

        $session->matchProvider();

        $this->repository->save($session);
    }
}
