<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Contracts\Commands;

use Wasl\SharedKernel\ValueObjects\UUID;
use Wasl\SharedKernel\ValueObjects\Timestamp;

interface Command
{
    public function commandId(): UUID;

    public function occurredAt(): Timestamp;

    public function commandName(): string;

    public function version(): int;

    public function payload(): array;
}
