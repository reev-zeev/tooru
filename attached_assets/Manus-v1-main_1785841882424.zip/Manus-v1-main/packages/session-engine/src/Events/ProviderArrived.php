<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Events;

final class ProviderArrived extends AbstractSessionEvent
{
    public function eventName(): string
    {
        return 'provider.arrived';
    }
}
