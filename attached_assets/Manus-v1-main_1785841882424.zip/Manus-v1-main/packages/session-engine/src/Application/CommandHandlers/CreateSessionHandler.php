<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Application\CommandHandlers;

use Wasl\SessionEngine\Application\Commands\CreateSessionCommand;
use Wasl\SessionEngine\Domain\Aggregates\ServiceSession;
use Wasl\SessionEngine\Domain\Factories\ServiceSessionFactory;
use Wasl\SessionEngine\Domain\Repositories\ServiceSessionRepository;
use Wasl\SharedKernel\Application\AggregatePersistenceManager;

final readonly class CreateSessionHandler
{
    public function __construct(
        private ServiceSessionFactory $factory,
        private ServiceSessionRepository $repository,
        private AggregatePersistenceManager $persistence,
    ) {
    }

    public function handle(CreateSessionCommand $command): ServiceSession
    {
        $session = $this->factory->create();

        $session->startSearching();

        $this->persistence->save(
            $session,
            fn (ServiceSession $aggregate) => $this->repository->save($aggregate),
        );

        return $session;
    }
}
