"""
إعدادات منصة حجازي المركزية
Hijazi Ride - Central Configuration
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ============================================================
# 1. التوكنات والبوتات
# ============================================================
PASSENGER_BOT_TOKEN = os.getenv("PASSENGER_BOT_TOKEN", "")
DRIVER_BOT_TOKEN = os.getenv("DRIVER_BOT_TOKEN", "")

# ============================================================
# 2. قاعدة البيانات (Railway يوفر DATABASE_URL تلقائياً)
# ============================================================
DATABASE_URL = os.getenv("DATABASE_URL", "")

if not DATABASE_URL:
    raise RuntimeError("❌ DATABASE_URL غير موجود. أضف PostgreSQL في Railway.")

# ============================================================
# 3. الإدارة
# ============================================================
def parse_int_list(value: str) -> list:
    """تحويل نص مفصول بفواصل إلى قائمة أرقام"""
    result = []
    for item in (value or "").split(","):
        item = item.strip()
        if item and item.lstrip("-").isdigit():
            result.append(int(item))
    return result

ADMIN_IDS = parse_int_list(os.getenv("ADMIN_IDS", ""))
EMERGENCY_CHAT_ID = os.getenv("EMERGENCY_CHAT_ID", "")

# ============================================================
# 4. مجموعات السائقين (اختياري - للتوزيع الجماعي كمرحلة أخيرة)
# ============================================================
PAID_DRIVER_GROUP_ID = os.getenv("PAID_DRIVER_GROUP_ID", "")
PUBLIC_DRIVER_GROUP_ID = os.getenv("PUBLIC_DRIVER_GROUP_ID", "")

# ============================================================
# 5. نظام الاشتراك
# ============================================================
SUBSCRIPTION_PRICE_MONTHLY = 70       # ريال سعودي
SUBSCRIPTION_DISCOUNT_QUARTERLY = 0.9 # خصم 10% للاشتراك 3 شهور
SUBSCRIPTION_DISCOUNT_YEARLY = 0.8    # خصم 20% للاشتراك السنوي

FREE_DRIVER_DELAY_MINUTES = 10        # تأخير السائق المجاني بالدقائق

# ============================================================
# 6. طرق الدفع (تضاف يدوياً من قبلك في Railway Variables)
# ============================================================
WISE_PAYMENT_LINK = os.getenv("WISE_PAYMENT_LINK", "")
PAYPAL_ME_LINK = os.getenv("PAYPAL_ME_LINK", "")
STCPAY_NUMBER = os.getenv("STCPAY_NUMBER", "")
BANK_ACCOUNT_INFO = os.getenv("BANK_ACCOUNT_INFO", "")

# ============================================================
# 7. إعدادات التوزيع الذكي
# ============================================================
MAX_DRIVERS_NOTIFIED = 50             # أقصى عدد سائقين يصلهم إشعار الطلب
DRIVER_SEARCH_RADIUS_KM = 15          # نطاق البحث عن السائقين (كم)
STAGE_WAIT_SECONDS = 30               # مدة الانتظار بين مراحل التوزيع

# ============================================================
# 8. المدن المدعومة
# ============================================================
SUPPORTED_CITIES = [
    "جدة",
    "مكة",
    "الطائف",
    "المدينة",
    "الرياض",
]

# ============================================================
# 9. أنواع السيارات
# ============================================================
CAR_TYPES = [
    "سيارة صغيرة",
    "سيارة عائلية",
    "VIP",
    "دباب",
    "نقل عفش",
]

# ============================================================
# 10. إعدادات عامة
# ============================================================
APP_NAME = "حجازي"
DEFAULT_CITY = "جدة"
SUPPORT_PHONE = os.getenv("SUPPORT_PHONE", "")
AUTO_VERIFY_DRIVERS = os.getenv("AUTO_VERIFY_DRIVERS", "false").lower() == "true"

# ============================================================
# 11. التحقق من الإعدادات الأساسية
# ============================================================
def validate_config():
    """التحقق من وجود جميع الإعدادات الضرورية"""
    errors = []
    
    if not PASSENGER_BOT_TOKEN:
        errors.append("PASSENGER_BOT_TOKEN غير موجود")
    if not DRIVER_BOT_TOKEN:
        errors.append("DRIVER_BOT_TOKEN غير موجود")
    if not DATABASE_URL:
        errors.append("DATABASE_URL غير موجود")
    if not ADMIN_IDS:
        errors.append("ADMIN_IDS غير موجود - أضف على الأقل ID أدمن واحد")
    
    if errors:
        for error in errors:
            print(f"❌ خطأ في الإعدادات: {error}")
        return False
    
    print("✅ جميع الإعدادات الأساسية موجودة.")
    return True
