<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\Exceptions;

use Wasl\SessionEngine\Domain\States\SessionState;
use Wasl\SharedKernel\Exceptions\DomainException;

final class InvalidSessionTransition extends DomainException
{
    public static function from(
        SessionState $from,
        SessionState $to,
    ): self {
        return new self(
            sprintf(
                'Invalid session transition from [%s] to [%s].',
                $from->value,
                $to->value,
            )
        );
    }
}
