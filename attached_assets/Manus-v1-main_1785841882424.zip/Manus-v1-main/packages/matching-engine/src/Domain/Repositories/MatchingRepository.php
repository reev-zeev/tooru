<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Domain\Repositories;

use Wasl\MatchingEngine\Domain\Aggregates\MatchingProcess;
use Wasl\SharedKernel\ValueObjects\UUID;

interface MatchingRepository
{
    public function save(MatchingProcess $matching): void;

    public function findById(UUID $id): ?MatchingProcess;

    public function findBySessionId(UUID $sessionId): ?MatchingProcess;
}
