<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Tests\Unit;

use PHPUnit\Framework\TestCase;
use Wasl\SessionEngine\Domain\Aggregates\ServiceSession;
use Wasl\SessionEngine\Domain\StateMachine\SessionStateMachine;
use Wasl\SessionEngine\Domain\States\SessionState;
use Wasl\SharedKernel\ValueObjects\UUID;

final class ServiceSessionTest extends TestCase
{
    public function test_session_is_created_in_created_state(): void
    {
        $session = ServiceSession::create(
            UUID::generate(),
            new SessionStateMachine(),
        );

        self::assertSame(
            SessionState::Created,
            $session->state(),
        );
    }

    public function test_session_can_start_searching(): void
    {
        $session = ServiceSession::create(
            UUID::generate(),
            new SessionStateMachine(),
        );

        $session->startSearching();

        self::assertSame(
            SessionState::Searching,
            $session->state(),
        );
    }

    public function test_full_session_lifecycle(): void
    {
        $session = ServiceSession::create(
            UUID::generate(),
            new SessionStateMachine(),
        );

        $session->startSearching();
        $session->matchProvider();
        $session->acceptProvider();
        $session->providerEnRoute();
        $session->providerArrived();
        $session->startService();
        $session->complete();
        $session->archive();

        self::assertSame(
            SessionState::Archived,
            $session->state(),
        );
    }
}
