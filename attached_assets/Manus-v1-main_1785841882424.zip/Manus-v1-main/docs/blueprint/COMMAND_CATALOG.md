# Wasl Platform Command Catalog

Version: 1.0.0
Status: DRAFT

========================================
COMMAND MODEL
========================================

Every command MUST contain:

- command_id
- command_name
- command_version
- aggregate_id
- aggregate_type
- session_id
- correlation_id
- idempotency_key
- actor_id
- actor_type
- issued_at (UTC)
- payload
- metadata

========================================
CUSTOMER COMMANDS
========================================

RegisterCustomer

UpdateCustomerProfile

RequestService

CancelRequest

UpdatePickupLocation

UpdateDestination

SendCustomerMessage

RateProvider

SaveFavoriteLocation

DeleteFavoriteLocation

CreateBooking

CancelBooking

CreateRecurringBooking

CancelRecurringBooking

========================================
PROVIDER COMMANDS
========================================

RegisterProvider

VerifyProvider

GoOnline

GoOffline

AcceptOrder

RejectOrder

StartNavigation

ArriveAtPickup

StartService

CompleteService

CancelService

UpdateProviderLocation

SendProviderMessage

RateCustomer

ReportProblem

EmergencySOS

========================================
SESSION COMMANDS
========================================

CreateSession

RecoverSession

PauseSession

ResumeSession

ArchiveSession

CloseSession

========================================
DISPATCH COMMANDS
========================================

StartDispatch

SelectCandidates

SendOffer

RetryDispatch

ActivateFallback

StopDispatch

========================================
BOOKING COMMANDS
========================================

CreateBooking

ConfirmBooking

GenerateRecurringBooking

StartBooking

CompleteBooking

CancelBooking

========================================
PAYMENT COMMANDS
========================================

CreatePayment

AuthorizePayment

CapturePayment

RefundPayment

AdjustPayment

FailPayment

========================================
CHAT COMMANDS
========================================

OpenChat

SendMessage

MarkMessageDelivered

MarkMessageRead

CloseChat

========================================
NOTIFICATION COMMANDS
========================================

QueueNotification

SendNotification

RetryNotification

CancelNotification

========================================
POLICY COMMANDS
========================================

EvaluatePolicy

ApplyPenalty

GrantReward

FlagAccount

UpdateReliability

UpdateFraudScore

========================================
SYSTEM COMMANDS
========================================

StartRecovery

RefreshCache

ReconnectWebSocket

RunHealthCheck

RebuildReadModel

ArchiveOldSessions

RunScheduler

BackupDatabase

RestoreDatabase

========================================
ADMIN COMMANDS
========================================

CreateAdmin

UpdateSettings

CreateFeatureFlag

EnableFeatureFlag

DisableFeatureFlag

SuspendProvider

UnsuspendProvider

SuspendCustomer

UnsuspendCustomer

AssignRole

RevokeRole

ForceCloseSession

BroadcastNotification

========================================
COMMAND RULES
========================================

Commands express intent.

Commands are mutable until executed.

Commands may succeed or fail.

Commands produce one or more Events.

Commands must validate input.

Commands must be authenticated.

Commands must be authorized.

Commands must include Idempotency Key.

Commands never modify state directly.

Commands are handled by exactly one Engine.

