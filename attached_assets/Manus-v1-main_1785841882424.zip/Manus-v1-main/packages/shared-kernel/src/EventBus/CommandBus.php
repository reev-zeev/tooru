<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\EventBus;

use Wasl\SharedKernel\Contracts\Commands\Command;

interface CommandBus
{
    public function dispatch(Command $command): mixed;
}
