<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Infrastructure\Persistence;

use Wasl\SessionEngine\Domain\Aggregates\ServiceSession;
use Wasl\SessionEngine\Domain\Repositories\ServiceSessionRepository;
use Wasl\SharedKernel\Exceptions\ConcurrencyException;
use Wasl\SharedKernel\ValueObjects\UUID;

final class InMemorySessionRepository implements ServiceSessionRepository
{
    /**
     * @var array<string, ServiceSession>
     */
    private array $sessions = [];

    /**
     * @var array<string, int>
     */
    private array $versions = [];

    public function save(ServiceSession $session): void
    {
        $id = $session->id()->toString();
        $currentVersion = $session->version()->value();

        if (isset($this->versions[$id])) {
            if ($this->versions[$id] >= $currentVersion) {
                throw new ConcurrencyException(
                    sprintf(
                        'Concurrency conflict detected for session [%s].',
                        $id
                    )
                );
            }
        }

        $this->sessions[$id] = $session;
        $this->versions[$id] = $currentVersion;
    }

    public function findById(UUID $id): ?ServiceSession
    {
        return $this->sessions[$id->toString()] ?? null;
    }

    public function exists(UUID $id): bool
    {
        return isset($this->sessions[$id->toString()]);
    }

    public function delete(UUID $id): void
    {
        unset($this->sessions[$id->toString()], $this->versions[$id->toString()]);
    }
}
