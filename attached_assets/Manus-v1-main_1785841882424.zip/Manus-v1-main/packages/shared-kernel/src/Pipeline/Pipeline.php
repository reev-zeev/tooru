<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Pipeline;

interface Pipeline
{
    public function send(mixed $payload): self;

    public function through(array $pipes): self;

    public function then(callable $destination): mixed;
}
