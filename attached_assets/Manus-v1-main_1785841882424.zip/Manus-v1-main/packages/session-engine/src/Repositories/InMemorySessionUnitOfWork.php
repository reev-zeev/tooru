<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Repositories;

use Wasl\SessionEngine\Contracts\SessionUnitOfWork;
use Wasl\SessionEngine\Session\ServiceSession;
use Wasl\SharedKernel\EventBus\EventBus;

final class InMemorySessionUnitOfWork implements SessionUnitOfWork
{
    /**
     * @var ServiceSession[]
     */
    private array $tracked = [];

    public function __construct(
        private readonly EventBus $eventBus
    ) {
    }

    public function register(ServiceSession $session): void
    {
        $this->tracked[] = $session;
    }

    public function commit(): void
    {
        foreach ($this->tracked as $session) {
            $this->eventBus->publish(
                ...$session->releaseEvents()
            );
        }

        $this->tracked = [];
    }

    public function rollback(): void
    {
        $this->tracked = [];
    }
}
