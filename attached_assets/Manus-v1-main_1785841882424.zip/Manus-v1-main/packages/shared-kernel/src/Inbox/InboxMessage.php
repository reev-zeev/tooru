<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Inbox;

use Wasl\SharedKernel\Contracts\Events\DomainEvent;

final readonly class InboxMessage
{
    public function __construct(
        private string $messageId,
        private DomainEvent $event,
        private bool $processed = false,
    ) {
    }

    public function messageId(): string
    {
        return $this->messageId;
    }

    public function event(): DomainEvent
    {
        return $this->event;
    }

    public function processed(): bool
    {
        return $this->processed;
    }

    public function markProcessed(): self
    {
        return new self(
            messageId: $this->messageId,
            event: $this->event,
            processed: true,
        );
    }
}
