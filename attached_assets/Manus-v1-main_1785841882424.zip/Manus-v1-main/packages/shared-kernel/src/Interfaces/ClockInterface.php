<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Interfaces;

use Wasl\SharedKernel\ValueObjects\Timestamp;

interface ClockInterface
{
    public function now(): Timestamp;
}
