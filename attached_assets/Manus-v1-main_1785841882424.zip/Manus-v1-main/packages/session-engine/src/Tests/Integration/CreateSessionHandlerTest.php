<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Tests\Integration;

use PHPUnit\Framework\TestCase;
use Wasl\SessionEngine\Application\CommandHandlers\CreateSessionHandler;
use Wasl\SessionEngine\Application\Commands\CreateSessionCommand;
use Wasl\SessionEngine\Domain\Factories\ServiceSessionFactory;
use Wasl\SessionEngine\Domain\StateMachine\SessionStateMachine;
use Wasl\SessionEngine\Infrastructure\Persistence\InMemorySessionRepository;
use Wasl\SharedKernel\Identity\UuidIdentityGenerator;

final class CreateSessionHandlerTest extends TestCase
{
    public function test_create_session(): void
    {
        $repository = new InMemorySessionRepository();

        $factory = new ServiceSessionFactory(
            new UuidIdentityGenerator(),
            new SessionStateMachine(),
        );

        $handler = new CreateSessionHandler(
            $factory,
            $repository,
        );

        $session = $handler->handle(
            new CreateSessionCommand(
                customerId: 'customer-1',
                serviceType: 'taxi',
            )
        );

        self::assertTrue(
            $repository->exists($session->id())
        );
    }
}
