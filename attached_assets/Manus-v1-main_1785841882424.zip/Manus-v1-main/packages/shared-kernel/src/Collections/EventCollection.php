<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Collections;

use Wasl\SharedKernel\Contracts\Events\DomainEvent;

final class EventCollection extends Collection
{
    public function add(DomainEvent $event): void
    {
        $this->items[] = $event;
    }
}
