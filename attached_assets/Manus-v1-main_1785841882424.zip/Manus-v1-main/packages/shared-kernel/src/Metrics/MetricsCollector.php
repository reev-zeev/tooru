<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Metrics;

interface MetricsCollector
{
    public function increment(
        string $metric,
        int $value = 1,
        array $tags = []
    ): void;

    public function gauge(
        string $metric,
        int|float $value,
        array $tags = []
    ): void;

    public function timing(
        string $metric,
        float $milliseconds,
        array $tags = []
    ): void;
}
