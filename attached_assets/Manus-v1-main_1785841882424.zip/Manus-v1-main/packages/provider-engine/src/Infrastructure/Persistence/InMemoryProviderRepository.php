<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Infrastructure\Persistence;

use Wasl\ProviderEngine\Domain\Aggregates\Provider;
use Wasl\ProviderEngine\Domain\Repositories\ProviderRepository;
use Wasl\SharedKernel\ValueObjects\UUID;

final class InMemoryProviderRepository implements ProviderRepository
{
    /**
     * @var array<string, Provider>
     */
    private array $providers = [];

    public function save(Provider $provider): void
    {
        $this->providers[$provider->id()->toString()] = $provider;
    }

    public function findById(UUID $id): ?Provider
    {
        return $this->providers[$id->toString()] ?? null;
    }

    public function findAvailable(): array
    {
        return array_values(
            array_filter(
                $this->providers,
                static fn (Provider $provider): bool =>
                    $provider->state()->isAvailable()
            )
        );
    }
}
