<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Specifications;

final readonly class OrSpecification extends AbstractSpecification
{
    public function __construct(
        private Specification $left,
        private Specification $right,
    ) {
    }

    public function isSatisfiedBy(mixed $candidate): bool
    {
        return $this->left->isSatisfiedBy($candidate)
            || $this->right->isSatisfiedBy($candidate);
    }
}
