<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Infrastructure\Bus;

use Wasl\MatchingEngine\Application\CommandHandlers\StartMatchingHandler;
use Wasl\SharedKernel\Bootstrap\ServiceProvider;
use Wasl\SharedKernel\DependencyInjection\Container;
use Wasl\SharedKernel\DomainEvents\DomainEventPublisher;
use Wasl\SessionEngine\Domain\Events\SessionCreated;

final class MatchingEventProvider implements ServiceProvider
{
    public function register(Container $container): void
    {
        $container->singleton(
            SessionCreatedSubscriber::class,
            fn(Container $c) => new SessionCreatedSubscriber(
                $c->get(StartMatchingHandler::class)
            )
        );
    }

    public function boot(Container $container): void
    {
        /** @var DomainEventPublisher $publisher */
        $publisher = $container->get(DomainEventPublisher::class);

        $publisher->subscribe(
            SessionCreated::class,
            $container->get(SessionCreatedSubscriber::class)
        );
    }
}
