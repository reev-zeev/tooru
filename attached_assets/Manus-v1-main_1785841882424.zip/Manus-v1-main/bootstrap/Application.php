<?php

declare(strict_types=1);

namespace Wasl\Bootstrap;

use Wasl\ProviderEngine\Infrastructure\Bootstrap\ProviderServiceProvider;
use Wasl\SessionEngine\Infrastructure\Projection\SessionProjectionProvider;
use Wasl\SessionEngine\Infrastructure\Bus\SessionEventSubscriberProvider;
use Wasl\MatchingEngine\Infrastructure\Bus\MatchingEventProvider;
use Wasl\SharedKernel\DependencyInjection\Container;

final class Application
{
    private Container $container;

    public function __construct()
    {
        $this->container = new Container();

        $providers = [
            new ProviderServiceProvider(),
            new SessionProjectionProvider(),
            new SessionEventSubscriberProvider(),
            new MatchingEventProvider(),
        ];

        foreach ($providers as $provider) {
            $provider->register($this->container);
        }

        foreach ($providers as $provider) {
            $provider->boot($this->container);
        }
    }

    public function container(): Container
    {
        return $this->container;
    }
}
