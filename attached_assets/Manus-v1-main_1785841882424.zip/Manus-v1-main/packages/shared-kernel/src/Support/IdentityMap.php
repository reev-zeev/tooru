<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Support;

final class IdentityMap
{
    /**
     * @var array<string, object>
     */
    private array $items = [];

    public function has(string $id): bool
    {
        return isset($this->items[$id]);
    }

    public function get(string $id): ?object
    {
        return $this->items[$id] ?? null;
    }

    public function put(string $id, object $entity): void
    {
        $this->items[$id] = $entity;
    }

    public function remove(string $id): void
    {
        unset($this->items[$id]);
    }

    public function clear(): void
    {
        $this->items = [];
    }
}
