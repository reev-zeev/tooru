<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Bus;

use RuntimeException;
use Wasl\SharedKernel\Contracts\Commands\Command;

final class InMemoryCommandBus implements CommandBus
{
    /**
     * @var array<string, callable>
     */
    private array $handlers = [];

    public function register(string $commandClass, callable $handler): void
    {
        $this->handlers[$commandClass] = $handler;
    }

    public function dispatch(Command $command): mixed
    {
        $handler = $this->handlers[$command::class] ?? null;

        if ($handler === null) {
            throw new RuntimeException(
                sprintf('No handler registered for command [%s].', $command::class)
            );
        }

        return $handler($command);
    }
}
