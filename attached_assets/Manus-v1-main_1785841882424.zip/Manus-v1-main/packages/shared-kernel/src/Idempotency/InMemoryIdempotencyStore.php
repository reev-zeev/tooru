<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Idempotency;

final class InMemoryIdempotencyStore implements IdempotencyStore
{
    /**
     * @var array<string,mixed>
     */
    private array $storage = [];

    public function exists(string $key): bool
    {
        return array_key_exists($key, $this->storage);
    }

    public function store(string $key, mixed $result = null): void
    {
        $this->storage[$key] = $result;
    }

    public function result(string $key): mixed
    {
        return $this->storage[$key] ?? null;
    }

    public function forget(string $key): void
    {
        unset($this->storage[$key]);
    }
}
