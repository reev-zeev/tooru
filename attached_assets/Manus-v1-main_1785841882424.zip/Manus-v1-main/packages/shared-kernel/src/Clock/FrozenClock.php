<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Clock;

use Wasl\SharedKernel\ValueObjects\Timestamp;

final readonly class FrozenClock implements Clock
{
    public function __construct(
        private Timestamp $time
    ) {
    }

    public function now(): Timestamp
    {
        return $this->time;
    }
}
