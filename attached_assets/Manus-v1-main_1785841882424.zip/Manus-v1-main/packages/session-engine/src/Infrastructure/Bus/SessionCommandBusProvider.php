<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Infrastructure\Bus;

use Wasl\SessionEngine\Application\CommandHandlers\AcceptProviderHandler;
use Wasl\SessionEngine\Application\CommandHandlers\CancelSessionHandler;
use Wasl\SessionEngine\Application\CommandHandlers\CompleteSessionHandler;
use Wasl\SessionEngine\Application\CommandHandlers\CreateSessionHandler;
use Wasl\SessionEngine\Application\CommandHandlers\MatchProviderHandler;
use Wasl\SessionEngine\Application\CommandHandlers\ProviderArrivedHandler;
use Wasl\SessionEngine\Application\CommandHandlers\ProviderEnRouteHandler;
use Wasl\SessionEngine\Application\CommandHandlers\StartServiceHandler;
use Wasl\SessionEngine\Application\Commands\AcceptProviderCommand;
use Wasl\SessionEngine\Application\Commands\CancelSessionCommand;
use Wasl\SessionEngine\Application\Commands\CompleteSessionCommand;
use Wasl\SessionEngine\Application\Commands\CreateSessionCommand;
use Wasl\SessionEngine\Application\Commands\MatchProviderCommand;
use Wasl\SessionEngine\Application\Commands\ProviderArrivedCommand;
use Wasl\SessionEngine\Application\Commands\ProviderEnRouteCommand;
use Wasl\SessionEngine\Application\Commands\StartServiceCommand;
use Wasl\SharedKernel\Bootstrap\ServiceProvider;
use Wasl\SharedKernel\Bus\CommandBus;
use Wasl\SharedKernel\DependencyInjection\Container;

final class SessionCommandBusProvider implements ServiceProvider
{
    public function register(Container $container): void
    {
    }

    public function boot(Container $container): void
    {
        /** @var CommandBus $bus */
        $bus = $container->get(CommandBus::class);

        $bus->register(CreateSessionCommand::class, CreateSessionHandler::class);
        $bus->register(MatchProviderCommand::class, MatchProviderHandler::class);
        $bus->register(AcceptProviderCommand::class, AcceptProviderHandler::class);
        $bus->register(ProviderEnRouteCommand::class, ProviderEnRouteHandler::class);
        $bus->register(ProviderArrivedCommand::class, ProviderArrivedHandler::class);
        $bus->register(StartServiceCommand::class, StartServiceHandler::class);
        $bus->register(CompleteSessionCommand::class, CompleteSessionHandler::class);
        $bus->register(CancelSessionCommand::class, CancelSessionHandler::class);
    }
}
