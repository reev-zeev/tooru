<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Infrastructure\Bus;

use Wasl\MatchingEngine\Domain\Events\ProviderMatched;
use Wasl\SessionEngine\Application\CommandHandlers\MatchProviderHandler;
use Wasl\SessionEngine\Application\Commands\MatchProviderCommand;

final readonly class ProviderMatchedSubscriber
{
    public function __construct(
        private MatchProviderHandler $handler,
    ) {
    }

    public function __invoke(ProviderMatched $event): void
    {
        $this->handler->handle(
            new MatchProviderCommand(
                sessionId: $event->sessionId(),
                providerId: $event->providerId(),
            )
        );
    }
}
