<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\ValueObjects;

use DateTimeImmutable;
use DateTimeZone;

final readonly class Timestamp
{
    private DateTimeImmutable $value;

    public function __construct(DateTimeImmutable|string $value = 'now')
    {
        if ($value instanceof DateTimeImmutable) {
            $this->value = $value->setTimezone(new DateTimeZone('UTC'));
            return;
        }

        $this->value = new DateTimeImmutable($value, new DateTimeZone('UTC'));
    }

    public static function now(): self
    {
        return new self();
    }

    public static function fromString(string $value): self
    {
        return new self($value);
    }

    public function value(): DateTimeImmutable
    {
        return $this->value;
    }

    public function toIso8601(): string
    {
        return $this->value->format(DATE_ATOM);
    }

    public function equals(self $other): bool
    {
        return $this->value == $other->value;
    }

    public function isBefore(self $other): bool
    {
        return $this->value < $other->value;
    }

    public function isAfter(self $other): bool
    {
        return $this->value > $other->value;
    }

    public function __toString(): string
    {
        return $this->toIso8601();
    }
}
