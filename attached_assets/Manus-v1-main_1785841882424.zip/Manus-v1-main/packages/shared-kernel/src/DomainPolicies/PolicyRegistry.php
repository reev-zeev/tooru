<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\DomainPolicies;

final class PolicyRegistry
{
    /**
     * @var array<string, Policy>
     */
    private array $policies = [];

    public function register(Policy $policy): void
    {
        $this->policies[$policy->name()] = $policy;
    }

    public function has(string $name): bool
    {
        return isset($this->policies[$name]);
    }

    public function get(string $name): ?Policy
    {
        return $this->policies[$name] ?? null;
    }

    /**
     * @return Policy[]
     */
    public function all(): array
    {
        return array_values($this->policies);
    }
}
