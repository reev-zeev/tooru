<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Outbox;

use Wasl\SharedKernel\Contracts\Events\DomainEvent;

final readonly class OutboxMessage
{
    public function __construct(
        private DomainEvent $event,
        private bool $published = false,
    ) {
    }

    public function event(): DomainEvent
    {
        return $this->event;
    }

    public function published(): bool
    {
        return $this->published;
    }

    public function markPublished(): self
    {
        return new self(
            event: $this->event,
            published: true,
        );
    }
}
