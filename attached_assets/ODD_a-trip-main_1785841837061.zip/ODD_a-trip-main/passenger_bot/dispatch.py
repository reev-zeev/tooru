"""
🚖 نظام التوزيع الذكي لمنصة حجازي
Smart Dispatch System - Hijazi Ride
"""

import asyncio
import math
from datetime import datetime, timezone

# ============================================================
# 1. دوال المسافات والتسعير (من أكوادك السابقة)
# ============================================================
def haversine_km(lat1, lon1, lat2, lon2):
    """حساب المسافة بين نقطتين بالكيلومتر"""
    if None in [lat1, lon1, lat2, lon2]:
        return None
    r = 6371
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def tier_is_active(driver_row):
    """هل اشتراك السائق ما زال ساريًا؟"""
    tier = driver_row.get("subscription") or "free"
    until = driver_row.get("subscription_until")
    if tier in ("subscribed", "bronze", "silver", "gold") and until and until > datetime.now(timezone.utc):
        return tier
    return "free"

def driver_score(ride_data, driver_row):
    """
    تقييم السائق لترتيب المرشحين (مزيج من الذكاء والمنطق)
    يجمع بين: الاشتراك + القرب + تفضيلات المنطقة + التقييم
    """
    score = 0

    # 1. وزن الاشتراك
    tier = tier_is_active(driver_row)
    if tier == "subscribed":
        score += 300
    elif tier == "free":
        score += 0

    # 2. وزن المسافة
    dist = haversine_km(
        ride_data.get("pickup_lat"), ride_data.get("pickup_lon"),
        driver_row.get("last_lat"), driver_row.get("last_lon")
    )
    if dist is not None:
        if dist <= 3:
            score += 200
        elif dist <= 7:
            score += 150
        elif dist <= 15:
            score += 50
        score -= min(dist, 25)

    # 3. وزن تفضيلات السائق (مناطق عمله المفضلة)
    pickup_area = (ride_data.get("pickup_area") or "").strip().lower()
    preferred = (driver_row.get("preferred_areas") or "").strip().lower()
    if pickup_area and preferred:
        parts = [x.strip() for x in preferred.replace("،", ",").split(",") if x.strip()]
        for p in parts:
            if p in pickup_area or pickup_area in p:
                score += 80
                break

    # 4. وزن التقييم
    rating = float(driver_row.get("rating") or 5)
    score += rating * 10

    return score

# ============================================================
# 2. البحث عن السائقين المناسبين
# ============================================================
async def fetch_candidates(pool, ride_data):
    """
    البحث عن سائقين نشطين ومفعلين في نفس مدينة الطلب
    """
    city = ride_data["city"]
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT d.*, u.tg_id, u.username, u.full_name, u.phone
            FROM drivers d
            JOIN users u ON u.tg_id = d.tg_id
            WHERE d.verified = TRUE
              AND d.city = $1
              AND d.tg_id != $2
            """,
            city,
            ride_data["customer_id"]
        )
    return rows

async def get_best_drivers(pool, ride_data):
    """
    ترتيب المرشحين حسب الأفضلية وإرجاع أفضل 3 فقط
    """
    candidates = await fetch_candidates(pool, ride_data)
    scored = []
    for d in candidates:
        score = driver_score(ride_data, d)
        scored.append((score, d))
    # ترتيب تنازلي حسب النتيجة
    scored.sort(key=lambda x: x[0], reverse=True)
    # إرجاع أفضل 3 سائقين
    return [d for score, d in scored[:3]]

# ============================================================
# 3. إرسال الطلب للسائقين (المرحلة الأولى: الخاص)
# ============================================================
async def notify_driver(bot, driver_row, ride_data, ride_id):
    """
    إرسال الطلب إلى سائق واحد في الخاص مع زر القبول
    """
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

    pickup = ride_data.get("pickup_area", "غير محدد")
    dest = ride_data.get("dest_area", "غير محدد")
    price = ride_data.get("price", "غير محدد")
    payment = ride_data.get("payment_method", "كاش")
    notes = ride_data.get("notes", "لا يوجد")

    text = (
        f"🚕 <b>طلب مشوار جديد #{ride_id}</b>\n\n"
        f"📍 <b>من:</b> {pickup}\n"
        f"🎯 <b>إلى:</b> {dest}\n"
        f"💰 <b>السعر:</b> {price}\n"
        f"💳 <b>الدفع:</b> {payment}\n"
        f"📝 <b>ملاحظات:</b> {notes}\n\n"
        f"<b>هل يناسبك المشوار؟</b>"
    )

    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ قبول الطلب", callback_data=f"accept_{ride_id}"),
            InlineKeyboardButton(text="💬 عرض سعر مختلف", callback_data=f"counter_{ride_id}")
        ]
    ])

    try:
        await bot.send_message(driver_row["tg_id"], text, reply_markup=markup)
        return True
    except Exception as e:
        print(f"فشل الإرسال للسائق {driver_row['tg_id']}: {e}")
        return False

# ============================================================
# 4. متابعة حالة الطلب (هل ما زال Waiting؟)
# ============================================================
async def ride_is_waiting(pool, ride_id):
    async with pool.acquire() as conn:
        status = await conn.fetchval("SELECT status FROM rides WHERE id = $1", ride_id)
    return status == "waiting"

# ============================================================
# 5. التوزيع على القروبات (المرحلة الأخيرة)
# ============================================================
async def notify_groups(bot, pool, ride_data, ride_id):
    """
    إرسال الطلب إلى قروبات السائقين المسجلة
    """
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

    city = ride_data.get("city", "جدة")
    async with pool.acquire() as conn:
        groups = await conn.fetch(
            "SELECT chat_id, type FROM groups_config WHERE city = $1",
            city
        )

    pickup = ride_data.get("pickup_area", "غير محدد")
    dest = ride_data.get("dest_area", "غير محدد")
    price = ride_data.get("price", "غير محدد")

    text = (
        f"🚕 <b>طلب مشوار متاح للجميع #{ride_id}</b>\n\n"
        f"📍 <b>من:</b> {pickup}\n"
        f"🎯 <b>إلى:</b> {dest}\n"
        f"💰 <b>السعر:</b> {price}\n\n"
        f"<b>اضغط لقبول الطلب:</b>"
    )

    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ قبول الطلب", callback_data=f"accept_{ride_id}")]
    ])

    for group in groups:
        try:
            await bot.send_message(group["chat_id"], text, reply_markup=markup)
            await asyncio.sleep(0.5)  # تجنب حظر تيليجرام
        except Exception as e:
            print(f"فشل الإرسال للقروب {group['chat_id']}: {e}")

# ============================================================
# 6. محرك التوزيع الرئيسي (يتم استدعاؤه بعد تأكيد الطلب)
# ============================================================
async def dispatch_ride(bot, pool, ride_data, ride_id):
    """
    المحرك الرئيسي لتوزيع الطلب:
    1. يبحث عن أفضل 3 سائقين مشتركين
    2. يرسل لهم في الخاص
    3. ينتظر 30 ثانية بين كل واحد
    4. إذا لم يقبل أحد، يرسل إلى القروبات
    """
    await asyncio.sleep(0.5)  # انتظار قصير لتأكيد الحفظ

    # المرحلة 1: أفضل السائقين في الخاص
    best_drivers = await get_best_drivers(pool, ride_data)
    for driver in best_drivers:
        if not await ride_is_waiting(pool, ride_id):
            return  # تم قبول الطلب من قبل سائق آخر
        await notify_driver(bot, driver, ride_data, ride_id)
        # انتظار 30 ثانية قبل إرسال الطلب للسائق التالي
        await asyncio.sleep(30)

    # المرحلة 2: القروبات (بعد فشل السائقين المباشرين)
    if not await ride_is_waiting(pool, ride_id):
        return  # تم قبول الطلب من قبل سائق آخر
    await notify_groups(bot, pool, ride_data, ride_id)
