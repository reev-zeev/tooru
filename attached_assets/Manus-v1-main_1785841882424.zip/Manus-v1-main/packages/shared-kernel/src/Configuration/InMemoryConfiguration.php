<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Configuration;

final class InMemoryConfiguration implements Configuration
{
    /**
     * @param array<string,mixed> $values
     */
    public function __construct(
        private array $values = []
    ) {
    }

    public function get(string $key, mixed $default = null): mixed
    {
        return $this->values[$key] ?? $default;
    }

    public function has(string $key): bool
    {
        return array_key_exists($key, $this->values);
    }

    public function set(string $key, mixed $value): void
    {
        $this->values[$key] = $value;
    }
}
