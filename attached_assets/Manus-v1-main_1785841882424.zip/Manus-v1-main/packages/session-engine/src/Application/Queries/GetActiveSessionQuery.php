<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Application\Queries;

use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class GetActiveSessionQuery
{
    public function __construct(
        public UUID $sessionId,
    ) {
    }
}
