<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Bus;

use Wasl\SharedKernel\Contracts\Events\DomainEvent;

interface EventBus
{
    public function publish(DomainEvent ...$events): void;
}
