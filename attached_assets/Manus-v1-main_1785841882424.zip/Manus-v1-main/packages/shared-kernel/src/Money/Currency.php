<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Money;

use InvalidArgumentException;

final readonly class Currency
{
    public function __construct(
        private string $code
    ) {
        $this->code = strtoupper(trim($this->code));

        if (!preg_match('/^[A-Z]{3}$/', $this->code)) {
            throw new InvalidArgumentException('Invalid currency code.');
        }
    }

    public function code(): string
    {
        return $this->code;
    }

    public function equals(self $other): bool
    {
        return $this->code === $other->code();
    }

    public function __toString(): string
    {
        return $this->code;
    }
}
