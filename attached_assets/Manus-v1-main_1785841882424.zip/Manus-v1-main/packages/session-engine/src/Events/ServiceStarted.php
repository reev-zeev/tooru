<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Events;

final class ServiceStarted extends AbstractSessionEvent
{
    public function eventName(): string
    {
        return 'service.started';
    }
}
