<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Events;

final class SessionMatched extends AbstractSessionEvent
{
    public function eventName(): string
    {
        return 'session.matched';
    }
}
