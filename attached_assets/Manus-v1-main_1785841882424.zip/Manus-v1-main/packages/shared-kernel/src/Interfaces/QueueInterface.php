<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Interfaces;

interface QueueInterface
{
    public function dispatch(object $job): void;
}
