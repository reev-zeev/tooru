<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Domain\StateMachine;

use Wasl\MatchingEngine\Domain\Exceptions\InvalidMatchingTransition;
use Wasl\MatchingEngine\Domain\States\MatchingState;

final class MatchingStateMachine
{
    public function transition(
        MatchingState $current,
        MatchingState $next,
    ): MatchingState {
        if (!$current->canTransitionTo($next)) {
            throw InvalidMatchingTransition::from($current, $next);
        }

        return $next;
    }

    public function canTransition(
        MatchingState $current,
        MatchingState $next,
    ): bool {
        return $current->canTransitionTo($next);
    }
}
