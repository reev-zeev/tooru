<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Infrastructure\Persistence;

use Wasl\MatchingEngine\Domain\Services\ProviderSource;

final class InMemoryProviderSource implements ProviderSource
{
    public function availableProviders(): array
    {
        return [
            [
                'id' => 'provider-001',
                'rating' => 4.9,
                'distance' => 1.8,
            ],
            [
                'id' => 'provider-002',
                'rating' => 4.7,
                'distance' => 2.4,
            ],
        ];
    }
}
