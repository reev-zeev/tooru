<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Domain\States;

enum MatchingState: string
{
    case Created = 'created';

    case Searching = 'searching';

    case CandidateFound = 'candidate_found';

    case OfferSent = 'offer_sent';

    case ProviderAccepted = 'provider_accepted';

    case ProviderRejected = 'provider_rejected';

    case Exhausted = 'exhausted';

    case Completed = 'completed';

    case Cancelled = 'cancelled';

    public function isFinal(): bool
    {
        return match ($this) {
            self::Completed,
            self::Cancelled,
            self::Exhausted => true,

            default => false,
        };
    }

    public function canTransitionTo(self $next): bool
    {
        return match ($this) {
            self::Created =>
                $next === self::Searching,

            self::Searching =>
                in_array($next, [
                    self::CandidateFound,
                    self::Exhausted,
                    self::Cancelled,
                ], true),

            self::CandidateFound =>
                in_array($next, [
                    self::OfferSent,
                    self::Searching,
                ], true),

            self::OfferSent =>
                in_array($next, [
                    self::ProviderAccepted,
                    self::ProviderRejected,
                    self::Cancelled,
                ], true),

            self::ProviderRejected =>
                $next === self::Searching,

            self::ProviderAccepted =>
                $next === self::Completed,

            self::Completed,
            self::Cancelled,
            self::Exhausted => false,
        };
    }
}
