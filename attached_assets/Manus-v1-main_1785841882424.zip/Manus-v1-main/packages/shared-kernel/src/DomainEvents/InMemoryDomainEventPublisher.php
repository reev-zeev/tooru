<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\DomainEvents;

use Wasl\SharedKernel\Bus\EventBus;
use Wasl\SharedKernel\Contracts\Events\DomainEvent;

final readonly class InMemoryDomainEventPublisher implements DomainEventPublisher
{
    public function __construct(
        private EventBus $eventBus,
    ) {
    }

    public function publish(DomainEvent ...$events): void
    {
        $this->eventBus->publish(...$events);
    }
}
