<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Identity;

use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class UuidIdentityGenerator implements IdentityGenerator
{
    public function generate(): UUID
    {
        return UUID::generate();
    }
}
