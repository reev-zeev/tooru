<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Retry;

use Throwable;

final readonly class ExponentialBackoffRetryPolicy implements RetryPolicy
{
    public function __construct(
        private int $maxAttempts = 3,
        private int $initialDelayMs = 100,
        private float $multiplier = 2.0,
    ) {
    }

    public function execute(callable $operation): mixed
    {
        $attempt = 0;
        $delay = $this->initialDelayMs;

        beginning:

        try {
            ++$attempt;

            return $operation();
        } catch (Throwable $e) {
            if ($attempt >= $this->maxAttempts) {
                throw $e;
            }

            usleep($delay * 1000);

            $delay = (int) ($delay * $this->multiplier);

            goto beginning;
        }
    }
}
