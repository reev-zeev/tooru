import math
from datetime import datetime, timezone

def haversine_km(lat1, lon1, lat2, lon2):
    if None in [lat1, lon1, lat2, lon2]:
        return None
    r = 6371
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def tier_is_active(driver_row):
    if not driver_row:
        return "free"
    tier = driver_row.get("subscription") or "free"
    until = driver_row.get("subscription_until")
    if tier in ("subscribed", "bronze", "silver", "gold") and until and until > datetime.now(timezone.utc):
        return tier
    return "free"

def driver_score(ride_data, driver_row):
    score = 0.0
    tier = tier_is_active(driver_row)
    if tier == "subscribed":
        score += 300
    dist = haversine_km(
        ride_data.get("pickup_lat"), ride_data.get("pickup_lon"),
        driver_row.get("last_lat"), driver_row.get("last_lon")
    )
    if dist is not None:
        if dist <= 3: score += 200
        elif dist <= 7: score += 100
        elif dist <= 15: score += 30
        score -= min(dist, 25)
    pickup_area = (ride_data.get("pickup_area") or "").strip().lower()
    preferred = (driver_row.get("preferred_areas") or "").strip().lower()
    if pickup_area and preferred:
        parts = [x.strip() for x in preferred.replace("،", ",").split(",") if x.strip()]
        for p in parts:
            if p in pickup_area or pickup_area in p:
                score += 80
                break
    rating = float(driver_row.get("rating") or 5)
    score += rating * 10
    return score
