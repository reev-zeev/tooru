<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\ValueObjects;

use Wasl\SharedKernel\ValueObjects\Identifier;

final class ProviderId extends Identifier
{
}
