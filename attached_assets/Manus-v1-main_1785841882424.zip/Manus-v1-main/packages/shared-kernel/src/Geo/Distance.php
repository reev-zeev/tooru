<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Geo;

use InvalidArgumentException;

final readonly class Distance
{
    public function __construct(
        private int $meters
    ) {
        if ($meters < 0) {
            throw new InvalidArgumentException('Distance cannot be negative.');
        }
    }

    public static function fromMeters(int $meters): self
    {
        return new self($meters);
    }

    public static function fromKilometers(float $km): self
    {
        return new self((int) round($km * 1000));
    }

    public function meters(): int
    {
        return $this->meters;
    }

    public function kilometers(): float
    {
        return $this->meters / 1000;
    }

    public function equals(self $other): bool
    {
        return $this->meters === $other->meters();
    }

    public function __toString(): string
    {
        return $this->kilometers() . ' km';
    }
}
