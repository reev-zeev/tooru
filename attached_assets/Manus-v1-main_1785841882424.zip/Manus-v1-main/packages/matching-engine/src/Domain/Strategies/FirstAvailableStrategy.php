<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Domain\Strategies;

final class FirstAvailableStrategy implements MatchingStrategy
{
    public function select(array $providers): ?array
    {
        return $providers[0] ?? null;
    }
}
