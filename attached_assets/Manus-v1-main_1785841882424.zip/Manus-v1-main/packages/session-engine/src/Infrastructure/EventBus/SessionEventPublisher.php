<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Infrastructure\EventBus;

use Wasl\SharedKernel\Contracts\Events\DomainEvent;
use Wasl\SharedKernel\DomainEvents\DomainEventPublisher;

final readonly class SessionEventPublisher
{
    public function __construct(
        private DomainEventPublisher $publisher,
    ) {
    }

    public function publish(DomainEvent ...$events): void
    {
        $this->publisher->publish(...$events);
    }
}
