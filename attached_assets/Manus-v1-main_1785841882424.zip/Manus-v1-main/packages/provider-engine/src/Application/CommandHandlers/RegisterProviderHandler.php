<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Application\CommandHandlers;

use Wasl\ProviderEngine\Application\Commands\RegisterProviderCommand;
use Wasl\ProviderEngine\Domain\Aggregates\Provider;
use Wasl\ProviderEngine\Domain\Repositories\ProviderRepository;
use Wasl\ProviderEngine\Domain\StateMachine\ProviderStateMachine;
use Wasl\SharedKernel\Application\AggregatePersistenceManager;

final readonly class RegisterProviderHandler
{
    public function __construct(
        private ProviderRepository $repository,
        private ProviderStateMachine $stateMachine,
        private AggregatePersistenceManager $persistence,
    ) {
    }

    public function handle(RegisterProviderCommand $command): Provider
    {
        $provider = Provider::register(
            $command->providerId,
            $this->stateMachine,
        );

        $this->persistence->save(
            $provider,
            fn (Provider $aggregate) => $this->repository->save($aggregate),
        );

        return $provider;
    }
}
