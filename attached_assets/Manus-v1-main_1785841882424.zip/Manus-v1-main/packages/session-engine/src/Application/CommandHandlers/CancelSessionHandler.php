<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Application\CommandHandlers;

use Wasl\SessionEngine\Application\Commands\CancelSessionCommand;
use Wasl\SessionEngine\Domain\Repositories\ServiceSessionRepository;
use Wasl\SharedKernel\Exceptions\NotFoundException;

final readonly class CancelSessionHandler
{
    public function __construct(
        private ServiceSessionRepository $repository,
    ) {
    }

    public function handle(CancelSessionCommand $command): void
    {
        $session = $this->repository->findById($command->sessionId);

        if ($session === null) {
            throw new NotFoundException('Session not found.');
        }

        $session->cancel();

        $this->repository->save($session);
    }
}
