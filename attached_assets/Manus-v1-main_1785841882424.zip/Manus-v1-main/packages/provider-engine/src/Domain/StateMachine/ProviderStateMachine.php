<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Domain\StateMachine;

use Wasl\ProviderEngine\Domain\Exceptions\InvalidProviderTransition;
use Wasl\ProviderEngine\Domain\States\ProviderState;

final class ProviderStateMachine
{
    public function transition(
        ProviderState $current,
        ProviderState $next,
    ): ProviderState {
        if (!$current->canTransitionTo($next)) {
            throw InvalidProviderTransition::from($current, $next);
        }

        return $next;
    }

    public function canTransition(
        ProviderState $current,
        ProviderState $next,
    ): bool {
        return $current->canTransitionTo($next);
    }
}
