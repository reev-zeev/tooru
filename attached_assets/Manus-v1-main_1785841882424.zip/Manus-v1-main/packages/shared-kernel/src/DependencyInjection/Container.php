<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\DependencyInjection;

interface Container
{
    public function bind(string $abstract, callable $factory): void;

    public function singleton(string $abstract, callable $factory): void;

    public function instance(string $abstract, object $instance): void;

    public function has(string $abstract): bool;

    public function get(string $abstract): object;
}
