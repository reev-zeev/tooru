<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Infrastructure\Persistence;

use Wasl\MatchingEngine\Domain\Aggregates\MatchingProcess;
use Wasl\MatchingEngine\Domain\Repositories\MatchingRepository;
use Wasl\SharedKernel\ValueObjects\UUID;

final class InMemoryMatchingRepository implements MatchingRepository
{
    /**
     * @var array<string, MatchingProcess>
     */
    private array $items = [];

    public function save(MatchingProcess $matching): void
    {
        $this->items[$matching->id()->toString()] = $matching;
    }

    public function findById(UUID $id): ?MatchingProcess
    {
        return $this->items[$id->toString()] ?? null;
    }

    public function findBySessionId(UUID $sessionId): ?MatchingProcess
    {
        foreach ($this->items as $matching) {
            if ($matching->sessionId()->equals($sessionId)) {
                return $matching;
            }
        }

        return null;
    }
}
