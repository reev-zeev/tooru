# Wasl Platform Domain Model

Version: 1.0.0
Status: DRAFT

=========================================================
DOMAIN PRINCIPLES
=========================================================

Business logic belongs to Domains.

Domains never depend on each other directly.

Communication occurs only through Events and Commands.

Each Domain owns its Aggregates.

Each Aggregate owns its State Machine.

Each Domain owns its Repository interfaces.

=========================================================
PLATFORM DOMAINS
=========================================================

Identity Domain

Customer Domain

Provider Domain

Vehicle Domain

Order Domain

Session Domain

Dispatch Domain

Booking Domain

Payment Domain

Pricing Domain

Notification Domain

Chat Domain

Location Domain

Policy Domain

Fraud Domain

Loyalty Domain

Support Domain

Analytics Domain

Audit Domain

Recovery Domain

Scheduler Domain

=========================================================
AGGREGATES
=========================================================

Customer

Provider

Vehicle

Order

ServiceSession

Booking

Payment

ChatRoom

SupportTicket

Notification

=========================================================
VALUE OBJECTS
=========================================================

Money

Currency

GeoPoint

Distance

Duration

ETA

Route

Address

PhoneNumber

Email

Rating

Score

UUID

SessionId

OrderId

ProviderId

CustomerId

BookingId

PaymentId

Timestamp

Language

Timezone

FeatureFlag

=========================================================
ENTITIES
=========================================================

Customer

Provider

Vehicle

Order

Session

Payment

Booking

Notification

Message

SupportTicket

=========================================================
DOMAIN SERVICES
=========================================================

Dispatch Service

Pricing Service

Matching Service

Fraud Detection Service

Policy Evaluation Service

Recovery Service

Booking Scheduler

Notification Service

Chat Service

Location Service

=========================================================
REPOSITORIES
=========================================================

Customer Repository

Provider Repository

Vehicle Repository

Order Repository

Session Repository

Payment Repository

Booking Repository

Notification Repository

Support Repository

=========================================================
DOMAIN EVENTS
=========================================================

Every Domain publishes Events.

Every Domain consumes Events.

Domains never call each other directly.

=========================================================
DOMAIN RULES
=========================================================

No Shared Database Logic.

No Business Logic inside Controllers.

No Business Logic inside Bots.

No Business Logic inside API Layer.

No Infrastructure inside Domains.

Domains depend only on Shared Kernel.

