<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Application;

use Wasl\SharedKernel\Aggregate\AggregateRoot;
use Wasl\SharedKernel\Outbox\OutboxMessage;
use Wasl\SharedKernel\Outbox\OutboxRepository;

final readonly class AggregatePersistenceManager
{
    public function __construct(
        private OutboxRepository $outbox,
    ) {
    }

    /**
     * @param callable(AggregateRoot):void $persist
     */
    public function save(
        AggregateRoot $aggregate,
        callable $persist,
    ): void {
        $persist($aggregate);

        foreach ($aggregate->releaseEvents() as $event) {
            $this->outbox->add(
                new OutboxMessage($event)
            );
        }
    }
}
