<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\StateMachine\Contracts;

interface Transition
{
    public function from(): string;

    public function to(): string;

    public function name(): string;
}
