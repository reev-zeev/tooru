<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Application\Commands;

use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class CompleteSessionCommand
{
    public function __construct(
        public UUID $sessionId,
    ) {
    }
}
