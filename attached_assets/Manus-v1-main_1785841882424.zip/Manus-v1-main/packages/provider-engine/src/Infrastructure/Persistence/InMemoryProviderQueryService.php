<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Infrastructure\Persistence;

use Wasl\ProviderEngine\Application\Queries\ProviderQueryService;
use Wasl\ProviderEngine\Application\Queries\ProviderView;
use Wasl\ProviderEngine\Domain\Repositories\ProviderRepository;

final readonly class InMemoryProviderQueryService implements ProviderQueryService
{
    public function __construct(
        private ProviderRepository $repository,
    ) {
    }

    public function availableProviders(): array
    {
        $providers = [];

        if (!method_exists($this->repository, 'findAvailable')) {
            return [];
        }

        foreach ($this->repository->findAvailable() as $provider) {
            $providers[] = new ProviderView(
                id: $provider->id()->toString(),
                rating: 5.0,      // مؤقتًا
                distance: 0.0,    // مؤقتًا
                available: true,
            );
        }

        return $providers;
    }
}
