<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Collections;

use ArrayIterator;
use Countable;
use IteratorAggregate;
use Traversable;
use InvalidArgumentException;

/**
 * @template T
 */
abstract class TypedCollection implements IteratorAggregate, Countable
{
    /**
     * @var array<int, mixed>
     */
    protected array $items = [];

    final public function __construct(iterable $items = [])
    {
        foreach ($items as $item) {
            $this->add($item);
        }
    }

    abstract protected function type(): string;

    final public function add(mixed $item): void
    {
        $type = $this->type();

        if (!$item instanceof $type) {
            throw new InvalidArgumentException(
                sprintf(
                    'Collection accepts only instances of [%s], [%s] given.',
                    $type,
                    get_debug_type($item)
                )
            );
        }

        $this->items[] = $item;
    }

    final public function all(): array
    {
        return $this->items;
    }

    final public function isEmpty(): bool
    {
        return $this->items === [];
    }

    final public function count(): int
    {
        return count($this->items);
    }

    final public function getIterator(): Traversable
    {
        return new ArrayIterator($this->items);
    }
}
