<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Contracts\Events;

use Wasl\SharedKernel\ValueObjects\UUID;
use Wasl\SharedKernel\ValueObjects\Timestamp;

interface DomainEvent
{
    public function eventId(): UUID;

    public function occurredAt(): Timestamp;

    public function eventName(): string;

    public function version(): int;

    public function payload(): array;
}
