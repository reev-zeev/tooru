<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Support;

abstract class Enum
{
    final private function __construct()
    {
    }

    final public static function values(): array
    {
        return array_values((new \ReflectionClass(static::class))->getConstants());
    }

    final public static function exists(string|int $value): bool
    {
        return in_array($value, static::values(), true);
    }
}
