<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Messaging;

use RuntimeException;

final class InMemoryMessageBus implements MessageBus
{
    /**
     * @var array<string, callable>
     */
    private array $handlers = [];

    public function register(string $messageClass, callable $handler): void
    {
        $this->handlers[$messageClass] = $handler;
    }

    public function dispatch(Message $message): mixed
    {
        $handler = $this->handlers[$message::class] ?? null;

        if ($handler === null) {
            throw new RuntimeException(
                sprintf(
                    'No handler registered for message [%s].',
                    $message::class
                )
            );
        }

        return $handler($message);
    }
}
