<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Metrics;

final class InMemoryMetricsCollector implements MetricsCollector
{
    /**
     * @var array<string,mixed>
     */
    private array $metrics = [];

    public function increment(
        string $metric,
        int $value = 1,
        array $tags = []
    ): void {
        $this->metrics[$metric] = ($this->metrics[$metric] ?? 0) + $value;
    }

    public function gauge(
        string $metric,
        int|float $value,
        array $tags = []
    ): void {
        $this->metrics[$metric] = $value;
    }

    public function timing(
        string $metric,
        float $milliseconds,
        array $tags = []
    ): void {
        $this->metrics[$metric] = $milliseconds;
    }

    public function all(): array
    {
        return $this->metrics;
    }
}
