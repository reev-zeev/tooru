<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Events;

use Wasl\SessionEngine\ValueObjects\SessionId;
use Wasl\SharedKernel\Events\BaseDomainEvent;

abstract readonly class AbstractSessionEvent extends BaseDomainEvent
{
    public function __construct(
        protected SessionId $sessionId
    ) {
        parent::__construct();
    }

    final public function aggregateId(): SessionId
    {
        return $this->sessionId;
    }

    public function payload(): array
    {
        return [
            'session_id' => (string) $this->sessionId,
        ];
    }
}
