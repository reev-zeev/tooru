<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Cache;

final class InMemoryCache implements Cache
{
    /**
     * @var array<string,mixed>
     */
    private array $storage = [];

    public function get(string $key, mixed $default = null): mixed
    {
        return $this->storage[$key] ?? $default;
    }

    public function put(string $key, mixed $value, ?int $ttl = null): void
    {
        $this->storage[$key] = $value;
    }

    public function has(string $key): bool
    {
        return array_key_exists($key, $this->storage);
    }

    public function forget(string $key): void
    {
        unset($this->storage[$key]);
    }

    public function clear(): void
    {
        $this->storage = [];
    }
}
