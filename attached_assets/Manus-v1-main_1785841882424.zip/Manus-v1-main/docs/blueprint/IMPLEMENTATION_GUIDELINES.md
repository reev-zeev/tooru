# Wasl Platform Implementation Guidelines

Version: 1.0.0
Status: OFFICIAL

=========================================================
PURPOSE
=========================================================

This document defines the mandatory implementation rules.

These rules are binding.

No implementation may violate them.

=========================================================
IMPLEMENTATION ORDER
=========================================================

1. Shared Kernel

2. Domain

3. Application

4. Engine

5. Infrastructure

6. API

7. Telegram

8. Admin Panel

Never reverse this order.

=========================================================
DEPENDENCY RULE
=========================================================

Presentation

↓

Application

↓

Domain

↓

Shared Kernel

Infrastructure depends on Domain.

Domain never depends on Infrastructure.

=========================================================
ENGINE IMPLEMENTATION
=========================================================

Every Engine must contain:

Application

Domain

Infrastructure

Contracts

Events

Commands

Handlers

Policies

README

Tests

=========================================================
DIRECTORY TEMPLATE
=========================================================

Engine/

├── Application/
├── Domain/
├── Infrastructure/
├── Contracts/
├── Commands/
├── Events/
├── Handlers/
├── Policies/
├── Tests/
└── README.md

=========================================================
APPLICATION LAYER
=========================================================

Contains

Use Cases

Command Handlers

Query Handlers

Application Services

Transactions

Nothing else.

=========================================================
DOMAIN LAYER
=========================================================

Contains

Aggregates

Entities

Value Objects

Policies

Specifications

Repositories (Interfaces)

Factories

Domain Events

=========================================================
INFRASTRUCTURE
=========================================================

Contains

Repositories

Redis

Queue

HTTP

Database

Telegram

External APIs

Logging

Caching

=========================================================
API LAYER
=========================================================

Contains

Controllers

DTO

Validation

Authentication

Authorization

OpenAPI

No Business Logic.

=========================================================
BOT LAYER
=========================================================

Contains

Conversations

Menus

Buttons

Localization

Formatting

No Business Logic.

=========================================================
DATABASE RULES
=========================================================

UUID Primary Keys

Foreign Keys

Indexes

Soft Delete

Created At

Updated At

Optimistic Lock where needed

Transactions Required

=========================================================
EVENT RULES
=========================================================

Events describe facts.

Never execute logic.

Never query database.

Never call APIs.

=========================================================
COMMAND RULES
=========================================================

Commands express intent.

Exactly one Handler.

Validation before execution.

Idempotency required.

=========================================================
TEST RULES
=========================================================

Every Aggregate

Unit Test

Every Use Case

Application Test

Every API

Contract Test

Every Engine

Integration Test

Critical Flows

E2E Test

Recovery

Chaos Test

=========================================================
QUALITY GATES
=========================================================

Build Success

Tests Pass

Static Analysis Pass

Formatting Pass

Architecture Rules Pass

Documentation Updated

=========================================================
DEFINITION OF DONE
=========================================================

Feature Implemented

Tests Added

Documentation Updated

Events Updated

Commands Updated

Contracts Updated

ADR Updated (if needed)

Reviewed

Approved

Merged

