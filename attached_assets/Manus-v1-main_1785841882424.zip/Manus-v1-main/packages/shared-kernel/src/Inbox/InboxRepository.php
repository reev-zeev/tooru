<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Inbox;

interface InboxRepository
{
    public function add(InboxMessage $message): void;

    public function exists(string $messageId): bool;

    public function save(InboxMessage $message): void;
}
