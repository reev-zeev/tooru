<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\StateMachine\Contracts;

interface Guard
{
    public function allows(
        State $current,
        Transition $transition
    ): bool;
}
