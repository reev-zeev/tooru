<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\Policies;

use Wasl\SessionEngine\Domain\Aggregates\ServiceSession;
use Wasl\SessionEngine\Domain\Specifications\SessionCanBeCancelledSpecification;
use Wasl\SharedKernel\DomainPolicies\AbstractPolicy;

final class CancelSessionPolicy extends AbstractPolicy
{
    public function name(): string
    {
        return 'session.cancel';
    }

    public function appliesTo(mixed $context): bool
    {
        return $context instanceof ServiceSession;
    }

    public function execute(mixed $context): bool
    {
        return (new SessionCanBeCancelledSpecification())
            ->isSatisfiedBy($context);
    }
}
