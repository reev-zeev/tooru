<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Collections;

use Wasl\SharedKernel\Contracts\Commands\Command;

final class CommandCollection extends Collection
{
    public function add(Command $command): void
    {
        $this->items[] = $command;
    }
}
