<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Repositories;

use Wasl\SharedKernel\Entities\AggregateRoot;
use Wasl\SharedKernel\ValueObjects\Identifier;

interface Repository
{
    public function save(AggregateRoot $aggregate): void;

    public function findById(Identifier $id): ?AggregateRoot;

    public function delete(AggregateRoot $aggregate): void;
}
