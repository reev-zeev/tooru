<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Domain\Exceptions;

use Wasl\MatchingEngine\Domain\States\MatchingState;
use Wasl\SharedKernel\Exceptions\DomainException;

final class InvalidMatchingTransition extends DomainException
{
    public static function from(
        MatchingState $from,
        MatchingState $to,
    ): self {
        return new self(
            sprintf(
                'Invalid matching transition from [%s] to [%s].',
                $from->value,
                $to->value,
            )
        );
    }
}
