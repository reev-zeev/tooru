<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Factories;

final class FactoryRegistry
{
    /**
     * @var array<string, Factory>
     */
    private array $factories = [];

    public function register(string $name, Factory $factory): void
    {
        $this->factories[$name] = $factory;
    }

    public function has(string $name): bool
    {
        return isset($this->factories[$name]);
    }

    public function get(string $name): Factory
    {
        return $this->factories[$name];
    }

    /**
     * @return array<string, Factory>
     */
    public function all(): array
    {
        return $this->factories;
    }
}
