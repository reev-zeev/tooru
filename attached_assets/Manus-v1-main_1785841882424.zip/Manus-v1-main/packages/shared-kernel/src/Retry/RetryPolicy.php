<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Retry;

interface RetryPolicy
{
    public function execute(callable $operation): mixed;
}
