<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Infrastructure\Projection;

use Wasl\SessionEngine\Domain\Events\ProviderAccepted;
use Wasl\SessionEngine\Domain\Events\ProviderMatched;
use Wasl\SessionEngine\Domain\Events\SessionCompleted;
use Wasl\SessionEngine\Domain\Events\SessionCreated;
use Wasl\SessionEngine\Projection\SessionProjection;

final readonly class SessionProjectionSubscriber
{
    public function __construct(
        private SessionProjection $projection,
    ) {
    }

    public function onSessionCreated(SessionCreated $event): void
    {
        $this->projection->onSessionCreated($event);
    }

    public function onProviderMatched(ProviderMatched $event): void
    {
        $this->projection->onProviderMatched($event);
    }

    public function onProviderAccepted(ProviderAccepted $event): void
    {
        $this->projection->onProviderAccepted($event);
    }

    public function onSessionCompleted(SessionCompleted $event): void
    {
        $this->projection->onSessionCompleted($event);
    }
}
