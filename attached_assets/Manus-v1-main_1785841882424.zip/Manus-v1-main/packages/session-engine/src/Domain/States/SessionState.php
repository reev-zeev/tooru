<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\States;

enum SessionState: string
{
    case Created = 'created';

    case Searching = 'searching';

    case Matched = 'matched';

    case ProviderAccepted = 'provider_accepted';

    case ProviderEnRoute = 'provider_en_route';

    case ProviderArrived = 'provider_arrived';

    case InService = 'in_service';

    case Completed = 'completed';

    case Cancelled = 'cancelled';

    case Archived = 'archived';

    public function isFinal(): bool
    {
        return match ($this) {
            self::Completed,
            self::Cancelled,
            self::Archived => true,

            default => false,
        };
    }

    public function canTransitionTo(self $next): bool
    {
        return match ($this) {
            self::Created =>
                $next === self::Searching,

            self::Searching =>
                in_array($next, [
                    self::Matched,
                    self::Cancelled,
                ], true),

            self::Matched =>
                in_array($next, [
                    self::ProviderAccepted,
                    self::Cancelled,
                ], true),

            self::ProviderAccepted =>
                in_array($next, [
                    self::ProviderEnRoute,
                    self::Cancelled,
                ], true),

            self::ProviderEnRoute =>
                in_array($next, [
                    self::ProviderArrived,
                    self::Cancelled,
                ], true),

            self::ProviderArrived =>
                in_array($next, [
                    self::InService,
                    self::Cancelled,
                ], true),

            self::InService =>
                $next === self::Completed,

            self::Completed =>
                $next === self::Archived,

            self::Cancelled,
            self::Archived => false,
        };
    }
}
