<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Application;

use Wasl\SessionEngine\Application\Commands\CreateSessionCommand;
use Wasl\SessionEngine\Application\CommandHandlers\CreateSessionHandler;
use Wasl\SessionEngine\Application\DTOs\SessionDto;
use Wasl\SessionEngine\Application\Queries\GetActiveSessionQuery;
use Wasl\SessionEngine\Domain\Repositories\ServiceSessionRepository;

final readonly class SessionApplicationService
{
    public function __construct(
        private CreateSessionHandler $createSessionHandler,
        private ServiceSessionRepository $repository,
    ) {
    }

    public function create(
        CreateSessionCommand $command
    ): SessionDto {
        $session = $this->createSessionHandler->handle($command);

        return SessionDto::fromAggregate($session);
    }

    public function get(
        GetActiveSessionQuery $query
    ): ?SessionDto {
        $session = $this->repository->findById(
            $query->sessionId
        );

        if ($session === null) {
            return null;
        }

        return SessionDto::fromAggregate($session);
    }
}
