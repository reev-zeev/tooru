<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\Aggregates;

use Wasl\SessionEngine\Domain\Events\SessionCreated;
use Wasl\SessionEngine\Domain\Events\ProviderMatched;
use Wasl\SessionEngine\Domain\Events\ProviderAccepted;
use Wasl\SessionEngine\Domain\Events\SessionCompleted;
use Wasl\SessionEngine\Domain\Exceptions\InvalidSessionTransition;
use Wasl\SessionEngine\Domain\StateMachine\SessionStateMachine;
use Wasl\SessionEngine\Domain\Policies\CancelSessionPolicy;
use Wasl\SessionEngine\Domain\Policies\CompleteSessionPolicy;
use Wasl\SessionEngine\Domain\Exceptions\SessionPolicyViolation;
use Wasl\SessionEngine\Domain\States\SessionState;
use Wasl\SharedKernel\Aggregate\AggregateRoot;
use Wasl\SharedKernel\ValueObjects\UUID;

final class ServiceSession extends AggregateRoot
{
    private SessionState $state;

    private function __construct(
        private readonly UUID $id,
        private readonly SessionStateMachine $stateMachine,
    ) {
        $this->state = SessionState::Created;
    }

    public static function create(
        UUID $id,
        SessionStateMachine $stateMachine,
    ): self {
        $session = new self($id, $stateMachine);

        $session->recordEvent(
            new SessionCreated($id)
        );

        return $session;
    }

    public function id(): UUID
    {
        return $this->id;
    }

    public function state(): SessionState
    {
        return $this->state;
    }

    public function startSearching(): void
    {
        $this->transition(SessionState::Searching);
    }

    public function matchProvider(): void
    {
        $this->transition(SessionState::Matched);
        $this->recordEvent(new ProviderMatched($this->id));
    }

    public function acceptProvider(): void
    {
        $this->transition(SessionState::ProviderAccepted);
        $this->recordEvent(new ProviderAccepted($this->id));
    }

    public function providerEnRoute(): void
    {
        $this->transition(SessionState::ProviderEnRoute);
    }

    public function providerArrived(): void
    {
        $this->transition(SessionState::ProviderArrived);
    }

    public function startService(): void
    {
        $this->transition(SessionState::InService);
    }

    public function complete(): void
    {
        if (!(new CompleteSessionPolicy())->execute($this)) {
            throw new SessionPolicyViolation("Session cannot be completed.");
        }

        $this->transition(SessionState::Completed);
        $this->recordEvent(new SessionCompleted($this->id));
    }

    public function archive(): void
    {
        $this->transition(SessionState::Archived);
    }

    public function cancel(): void
    {
        if (!(new CancelSessionPolicy())->execute($this)) {
            throw new SessionPolicyViolation("Session cannot be cancelled.");
        }

        $this->transition(SessionState::Cancelled);
    }

    private function transition(SessionState $next): void
    {
        $this->state = $this->stateMachine->transition(
            $this->state,
            $next
        );
    }
}
