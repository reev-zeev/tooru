<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Geo;

use InvalidArgumentException;

final readonly class Duration
{
    public function __construct(
        private int $seconds
    ) {
        if ($seconds < 0) {
            throw new InvalidArgumentException('Duration cannot be negative.');
        }
    }

    public static function fromSeconds(int $seconds): self
    {
        return new self($seconds);
    }

    public static function fromMinutes(int $minutes): self
    {
        return new self($minutes * 60);
    }

    public function seconds(): int
    {
        return $this->seconds;
    }

    public function minutes(): float
    {
        return $this->seconds / 60;
    }

    public function equals(self $other): bool
    {
        return $this->seconds === $other->seconds();
    }

    public function __toString(): string
    {
        return $this->seconds . ' sec';
    }
}
