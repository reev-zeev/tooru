<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Outbox;

use Wasl\SharedKernel\DomainEvents\DomainEventPublisher;

final readonly class OutboxProcessor
{
    public function __construct(
        private OutboxRepository $repository,
        private DomainEventPublisher $publisher,
    ) {
    }

    public function process(): void
    {
        foreach ($this->repository->pending() as $message) {
            $this->publisher->publish(
                $message->event()
            );

            $this->repository->save(
                $message->markPublished()
            );
        }
    }
}
