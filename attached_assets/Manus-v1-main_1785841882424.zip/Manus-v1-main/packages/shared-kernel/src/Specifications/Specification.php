<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Specifications;

interface Specification
{
    public function isSatisfiedBy(mixed $candidate): bool;

    public function and(self $specification): Specification;

    public function or(self $specification): Specification;

    public function not(): Specification;
}
