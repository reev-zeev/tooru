<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Inbox;

final class InMemoryInboxRepository implements InboxRepository
{
    /**
     * @var array<string,InboxMessage>
     */
    private array $messages = [];

    public function add(InboxMessage $message): void
    {
        $this->messages[$message->messageId()] = $message;
    }

    public function exists(string $messageId): bool
    {
        return isset($this->messages[$messageId]);
    }

    public function save(InboxMessage $message): void
    {
        $this->messages[$message->messageId()] = $message;
    }
}
