<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Session;

use Wasl\SharedKernel\Entities\AggregateRoot;
use Wasl\SessionEngine\Events\SessionArchived;
use Wasl\SessionEngine\Events\SessionCancelled;
use Wasl\SessionEngine\Events\SessionCompleted;
use Wasl\SessionEngine\Events\SessionCreated;
use Wasl\SessionEngine\Events\SessionMatched;
use Wasl\SessionEngine\Events\ProviderAccepted;
use Wasl\SessionEngine\Events\ProviderArrived;
use Wasl\SessionEngine\Events\ProviderEnRoute;
use Wasl\SessionEngine\Events\ServiceStarted;
use Wasl\SessionEngine\Events\SessionSearchingStarted;
use Wasl\SessionEngine\Exceptions\InvalidSessionTransition;
use Wasl\SessionEngine\States\SessionState;
use Wasl\SessionEngine\ValueObjects\CustomerId;
use Wasl\SessionEngine\ValueObjects\ProviderId;
use Wasl\SessionEngine\ValueObjects\ServiceType;
use Wasl\SessionEngine\ValueObjects\SessionId;

final class ServiceSession extends AggregateRoot
{
    private ?ProviderId $providerId = null;

    private SessionState $state;

    public function __construct(
        private readonly SessionId $sessionId,
        private readonly CustomerId $customerId,
        private readonly ServiceType $serviceType,
    ) {
        $this->state = SessionState::Created;

        $this->record(new SessionCreated($sessionId));
    }

    public function id(): SessionId
    {
        return $this->sessionId;
    }

    public function state(): SessionState
    {
        return $this->state;
    }

    public function customerId(): CustomerId
    {
        return $this->customerId;
    }

    public function providerId(): ?ProviderId
    {
        return $this->providerId;
    }

    public function serviceType(): ServiceType
    {
        return $this->serviceType;
    }

    public function startSearching(): void
    {
        $this->ensure(SessionState::Created);

        $this->transition(SessionState::Searching);

        $this->record(new SessionSearchingStarted($this->sessionId));
    }

    public function markMatched(): void
    {
        $this->ensure(SessionState::Searching);

        $this->transition(SessionState::Matched);

        $this->record(new SessionMatched($this->sessionId));
    }

    public function acceptProvider(ProviderId $providerId): void
    {
        $this->ensure(SessionState::Matched);

        if ($this->providerId !== null) {
            throw new InvalidSessionTransition(
                'Provider already assigned.'
            );
        }

        $this->providerId = $providerId;

        $this->transition(SessionState::ProviderAccepted);

        $this->record(
            new ProviderAccepted(
                $this->sessionId,
                $providerId
            )
        );
    }

    public function providerEnRoute(): void
    {
        $this->ensure(SessionState::ProviderAccepted);

        $this->transition(SessionState::ProviderEnRoute);

        $this->record(
            new ProviderEnRoute($this->sessionId)
        );
    }

    public function providerArrived(): void
    {
        $this->ensure(SessionState::ProviderEnRoute);

        $this->transition(SessionState::ProviderArrived);

        $this->record(
            new ProviderArrived($this->sessionId)
        );
    }

    public function startService(): void
    {
        $this->ensure(SessionState::ProviderArrived);

        $this->transition(SessionState::InService);

        $this->record(
            new ServiceStarted($this->sessionId)
        );
    }

    public function complete(): void
    {
        $this->ensure(SessionState::InService);

        $this->transition(SessionState::Completed);

        $this->record(
            new SessionCompleted($this->sessionId)
        );
    }

    public function cancel(): void
    {
        if ($this->state->isFinal()) {
            throw new InvalidSessionTransition(
                'Session already finished.'
            );
        }

        $this->transition(SessionState::Cancelled);

        $this->record(
            new SessionCancelled($this->sessionId)
        );
    }

    public function archive(): void
    {
        $this->ensure(SessionState::Completed);

        $this->transition(SessionState::Archived);

        $this->record(
            new SessionArchived($this->sessionId)
        );
    }

    private function ensure(SessionState $expected): void
    {
        if ($this->state !== $expected) {
            throw new InvalidSessionTransition(
                sprintf(
                    'Expected [%s], current [%s].',
                    $expected->value,
                    $this->state->value
                )
            );
        }
    }

    private function transition(SessionState $state): void
    {
        $this->state = $state;
    }
}
