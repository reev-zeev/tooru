/*
# Production Hardening — Business Logic Safety Constraints

## Changes Summary

1. **Prevent duplicate active rides per rider**
   - Adds a partial unique index on `rides(rider_id)` where status IN ('searching','accepted','in_progress')
   - Ensures a rider can never have two concurrent active rides, even under race conditions

2. **Atomic patch_bot_context RPC**
   - Replaces the read-then-write patchContext with a server-side atomic JSONB merge
   - Eliminates the TOCTOU race condition in state.server.ts

3. **Expire stale ride_offers automatically**
   - Adds a DB function + cron-style trigger that marks offers as 'expired' when expires_at has passed
   - Prevents ghost pending offers accumulating forever

4. **total_rides incremented via DB trigger on ride completion**
   - Moves total_rides increment out of AI evaluate (which can be skipped) into a reliable DB trigger
   - Fires on rides.status changing to 'completed' — increments both driver and rider counters atomically

5. **Notify rider when ride completes (DB trigger)**
   - total_cancellations incremented when a ride is cancelled

## Notes
- All operations are idempotent (IF NOT EXISTS / DROP POLICY IF EXISTS)
- No data is dropped or modified
*/

-- 1. Partial unique index: one active ride per rider at a time
CREATE UNIQUE INDEX IF NOT EXISTS rides_rider_one_active
  ON rides (rider_id)
  WHERE status IN ('searching', 'accepted', 'in_progress');

-- 2. Atomic JSONB context patch RPC (eliminates read-then-write race)
CREATE OR REPLACE FUNCTION patch_bot_context(
  p_telegram_id bigint,
  p_role        text,
  p_patch       jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO bot_states (telegram_id, bot_role, state, context, updated_at)
  VALUES (p_telegram_id, p_role, 'idle', p_patch, now())
  ON CONFLICT (telegram_id, bot_role)
  DO UPDATE SET
    context    = bot_states.context || p_patch,
    updated_at = now();
END;
$$;

-- 3. Function to expire stale pending offers
CREATE OR REPLACE FUNCTION expire_stale_offers()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE ride_offers
  SET status = 'expired'
  WHERE status = 'pending'
    AND expires_at IS NOT NULL
    AND expires_at < now();
END;
$$;

-- 4. Trigger: increment total_rides + total_cancellations atomically on ride status change
CREATE OR REPLACE FUNCTION on_ride_status_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Ride completed → increment total_rides for both driver and rider
  IF NEW.status = 'completed' AND OLD.status IS DISTINCT FROM 'completed' THEN
    IF NEW.driver_id IS NOT NULL THEN
      UPDATE drivers SET total_rides = COALESCE(total_rides, 0) + 1 WHERE id = NEW.driver_id;
    END IF;
    IF NEW.rider_id IS NOT NULL THEN
      UPDATE riders  SET total_rides = COALESCE(total_rides, 0) + 1 WHERE id = NEW.rider_id;
    END IF;
  END IF;

  -- Ride cancelled → increment total_cancellations for the cancelling party
  IF NEW.status = 'cancelled' AND OLD.status IS DISTINCT FROM 'cancelled' THEN
    IF NEW.cancelled_by = 'rider' AND NEW.rider_id IS NOT NULL THEN
      UPDATE riders  SET total_cancellations = COALESCE(total_cancellations, 0) + 1 WHERE id = NEW.rider_id;
    END IF;
    IF NEW.cancelled_by = 'driver' AND NEW.driver_id IS NOT NULL THEN
      UPDATE drivers SET total_cancellations = COALESCE(total_cancellations, 0) + 1 WHERE id = NEW.driver_id;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_ride_status_change ON rides;
CREATE TRIGGER trg_ride_status_change
  AFTER UPDATE OF status ON rides
  FOR EACH ROW
  EXECUTE FUNCTION on_ride_status_change();
