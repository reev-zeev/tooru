<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\ValueObjects;

abstract readonly class Identifier
{
    protected UUID $uuid;

    final public function __construct(UUID|string $value)
    {
        $this->uuid = $value instanceof UUID
            ? $value
            : UUID::fromString($value);
    }

    final public static function generate(): static
    {
        return new static(UUID::generate());
    }

    final public static function fromString(string $value): static
    {
        return new static(UUID::fromString($value));
    }

    final public function equals(self $other): bool
    {
        return static::class === $other::class
            && $this->uuid->equals($other->uuid);
    }

    final public function value(): string
    {
        return $this->uuid->value();
    }

    final public function uuid(): UUID
    {
        return $this->uuid;
    }

    final public function __toString(): string
    {
        return $this->uuid->value();
    }
}
