<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Outbox;

final class InMemoryOutboxRepository implements OutboxRepository
{
    /**
     * @var OutboxMessage[]
     */
    private array $messages = [];

    public function add(OutboxMessage $message): void
    {
        $this->messages[] = $message;
    }

    public function pending(): array
    {
        return array_values(
            array_filter(
                $this->messages,
                fn (OutboxMessage $message) => !$message->published()
            )
        );
    }

    public function save(OutboxMessage $message): void
    {
        foreach ($this->messages as $index => $stored) {
            if ($stored->event()->eventId()->equals($message->event()->eventId())) {
                $this->messages[$index] = $message;
                return;
            }
        }
    }
}
