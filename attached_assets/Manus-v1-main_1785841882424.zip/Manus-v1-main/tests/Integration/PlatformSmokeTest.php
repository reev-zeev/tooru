<?php

declare(strict_types=1);

use Wasl\Bootstrap\Application;
use Wasl\SessionEngine\Application\CommandHandlers\CreateSessionHandler;
use Wasl\SessionEngine\Application\Commands\CreateSessionCommand;
use Wasl\SharedKernel\ValueObjects\UUID;

require_once __DIR__ . '/../../vendor/autoload.php';

$app = new Application();

$container = $app->container();

/** @var CreateSessionHandler $handler */
$handler = $container->get(CreateSessionHandler::class);

$session = $handler->handle(
    new CreateSessionCommand(
        sessionId: UUID::generate(),
        customerId: UUID::generate(),
    )
);

echo "Session ID : {$session->id()->toString()}\n";
echo "State      : {$session->state()->value}\n";
echo "✅ Platform booted successfully.\n";
