<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Cache;

interface Cache
{
    public function get(string $key, mixed $default = null): mixed;

    public function put(string $key, mixed $value, ?int $ttl = null): void;

    public function has(string $key): bool;

    public function forget(string $key): void;

    public function clear(): void;
}
