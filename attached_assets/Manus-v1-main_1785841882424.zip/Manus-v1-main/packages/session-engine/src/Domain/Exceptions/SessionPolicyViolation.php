<?php

declare(strict_types=1);

namespace Wasl\SessionEngine\Domain\Exceptions;

use Wasl\SharedKernel\Exceptions\DomainException;

final class SessionPolicyViolation extends DomainException
{
}
