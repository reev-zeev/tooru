<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\ValueObjects;

final readonly class PaymentId extends Identifier
{
}
