<?php

declare(strict_types=1);

namespace Wasl\SharedKernel\Factories;

/**
 * Marker interface for all factories.
 */
interface Factory
{
}
