<?php

declare(strict_types=1);

namespace Wasl\MatchingEngine\Domain\Events;

use DateTimeImmutable;
use Wasl\SharedKernel\Contracts\Events\DomainEvent;
use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class MatchingStarted implements DomainEvent
{
    public function __construct(
        private UUID $matchingId,
        private UUID $sessionId,
        private ?DateTimeImmutable $occurredAt = null,
    ) {
    }

    public function eventId(): UUID
    {
        return UUID::generate();
    }

    public function aggregateId(): UUID
    {
        return $this->matchingId;
    }

    public function eventName(): string
    {
        return 'matching.started';
    }

    public function occurredAt(): DateTimeImmutable
    {
        return $this->occurredAt ?? new DateTimeImmutable();
    }

    public function payload(): array
    {
        return [
            'matching_id' => $this->matchingId->toString(),
            'session_id' => $this->sessionId->toString(),
        ];
    }
}
