<?php

declare(strict_types=1);

namespace Wasl\Contracts\Matching;

use DateTimeImmutable;
use Wasl\SharedKernel\Contracts\Events\DomainEvent;
use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class ProviderMatched implements DomainEvent
{
    public function __construct(
        private UUID $matchingId,
        private UUID $sessionId,
        private string $providerId,
        private UUID $eventId,
        private DateTimeImmutable $occurredAt,
    ) {
    }

    public function eventId(): UUID
    {
        return $this->eventId;
    }

    public function aggregateId(): UUID
    {
        return $this->matchingId;
    }

    public function sessionId(): UUID
    {
        return $this->sessionId;
    }

    public function providerId(): string
    {
        return $this->providerId;
    }

    public function eventName(): string
    {
        return 'matching.provider_matched';
    }

    public function occurredAt(): DateTimeImmutable
    {
        return $this->occurredAt;
    }

    public function payload(): array
    {
        return [
            'matching_id' => $this->matchingId->toString(),
            'session_id' => $this->sessionId->toString(),
            'provider_id' => $this->providerId,
        ];
    }
}
