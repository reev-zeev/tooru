<?php

declare(strict_types=1);

namespace Wasl\ProviderEngine\Domain\Events;

use DateTimeImmutable;
use Wasl\ProviderEngine\Domain\States\ProviderState;
use Wasl\SharedKernel\Contracts\Events\DomainEvent;
use Wasl\SharedKernel\ValueObjects\UUID;

final readonly class ProviderAvailabilityChanged implements DomainEvent
{
    public function __construct(
        private UUID $providerId,
        private ProviderState $state,
        private ?DateTimeImmutable $occurredAt = null,
    ) {
    }

    public function eventId(): UUID
    {
        return UUID::generate();
    }

    public function aggregateId(): UUID
    {
        return $this->providerId;
    }

    public function eventName(): string
    {
        return 'provider.availability_changed';
    }

    public function occurredAt(): DateTimeImmutable
    {
        return $this->occurredAt ?? new DateTimeImmutable();
    }

    public function payload(): array
    {
        return [
            'provider_id' => $this->providerId->toString(),
            'state' => $this->state->value,
        ];
    }
}
